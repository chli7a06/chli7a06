print('^3[XR-MDT DEBUG]^7 cl_armory.lua LOADING...')

local isArmoryOpen     = false
local currentArmoryJob = nil
local lastArmorySrc    = nil

local function GetLocale(path)
    if not path then return nil end
    local keys = {}
    for key in path:gmatch("([^%.]+)") do
        table.insert(keys, key)
    end

    local current = Locales[Config.Language] or Locales['en']
    if not current then return nil end
    for _, key in ipairs(keys) do
        if current and current[key] then
            current = current[key]
        else
            return nil
        end
    end
    return current
end




CreateThread(function()
    if Config.Debug then print('^3[XR-MDT DEBUG]^7 cl_armory.lua Target Thread Started') end
    Wait(1500)
    if Config.Debug then print('^3[XR-MDT DEBUG]^7 cl_armory.lua Registration Loop Starting...') end

    if not Config.Armory or not Config.Armory.Jobs then
        if Config.Debug then print('^1[XR-MDT ARMORY]^7 Config.Armory not found. Check config.armory.lua') end
        return
    end

    for jobName, armoryConfig in pairs(Config.Armory.Jobs) do
        local t = armoryConfig.Target
        if not t or not t.Coords then
            if Config.Debug then
                print(string.format('^3[XR-MDT ARMORY]^7 No Target.Coords for job "%s" — skipping', jobName))
            end
            goto skipJob
        end

        local coords   = t.Coords
        local size     = t.Size or vector3(0.5, 1.0, 2.0)
        local rot      = t.Rotation or 0.0

        local zoneName = 'armory_zone_' .. jobName

        Bridge.AddBoxZone({
            name = zoneName,
            coords = coords,
            size = size,
            rotation = rot,
            debug = t.Debug or false,
            options = {
                {
                    label    = GetLocale("nui.common.interact.open_armory") or "Open Armory",
                    icon     = 'fa-solid fa-gun',
                    groups   = { [jobName] = 0 },
                    event    = 'xr-mdt:armory:client:requestOpen',
                    distance = 2.5
                },
                {
                    label    = GetLocale("nui.common.interact.return_equipment") or "Return Equipment",
                    icon     = 'fa-solid fa-rotate-left',
                    groups   = { [jobName] = 0 },
                    event    = 'xr-mdt:armory:client:openStash',
                    distance = 2.5
                },
                {
                    label    = GetLocale("nui.common.interact.my_kits") or "My Kits",
                    icon     = 'fa-solid fa-briefcase',
                    groups   = { [jobName] = 0 },
                    event    = 'xr-mdt:armory:client:getKits',
                    distance = 2.5
                }
            }
        })

        if Config.Debug then
            print(string.format('^2[XR-MDT ARMORY]^7 Registered target zone for job "%s"', jobName))
        end

        ::skipJob::
    end
end)




RegisterNetEvent('xr-mdt:armory:client:requestOpen', function()
    if IsPauseMenuActive() then return end

    local pd = Bridge.GetPlayerData()
    if not pd or not pd.job then
        Bridge.Notify('Brak danych gracza.', 'error')
        return
    end

    TriggerServerEvent('xr-mdt:armory:requestOpen')
end)




RegisterNetEvent('xr-mdt:armory:client:openStash', function()
    if IsPauseMenuActive() then return end
    TriggerServerEvent('xr-mdt:armory:openStash')
end)




RegisterNetEvent('xr-mdt:armory:client:getKits', function()
    if IsPauseMenuActive() then return end
    TriggerServerEvent('xr-mdt:armory:getKits')
end)




RegisterNetEvent('xr-mdt:armory:open', function(data)
    if not data then return end

    isArmoryOpen = true
    currentArmoryJob = data.job

    SendNUIMessage({
        action  = 'openArmory',
        data    = data,
        locales = Locales[Config.Language] or Locales['en']
    })
    SetNuiFocus(true, true)

    if Config.Debug then
        print(string.format('[XR-MDT ARMORY CLIENT] Opening NUI for job "%s" (mode: %s)', data.job, data.mode))
    end
end)





RegisterNetEvent('xr-mdt:armory:doDump', function(data)
    if not data then return end


    local confirm = lib.alertDialog({
        header = GetLocale("nui.armory.return_title") or 'Return Equipment',
        content = string.format(
            GetLocale("nui.armory.return_desc") or 'Are you sure you want to return equipment for %s?',
            string.upper(data.job)
        ),
        centered = true,
        cancel = true,
    })

    if confirm == 'confirm' then
        TriggerServerEvent('xr-mdt:armory:dump', { job = data.job })
    end
end)




RegisterNetEvent('xr-mdt:armory:collectDone', function()
    isArmoryOpen = false
    currentArmoryJob = nil
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'closeArmory' })
end)




RegisterNetEvent('xr-mdt:armory:showKits', function(payload)
    if not payload or not payload.kits then return end

    local kits    = payload.kits
    local jobName = payload.job
    local options = {}

    if #kits == 0 then
        table.insert(options, {
            title       = GetLocale("nui.armory.no_kits") or 'No saved kits',
            description = GetLocale("nui.armory.no_kits_desc") or 'Open the armory and click "Create Kit"',
            disabled    = true,
        })
    else
        for _, kit in ipairs(kits) do
            local itemCount = #(kit.items or {})
            local preview = ''
            for i, it in ipairs(kit.items or {}) do
                if i > 3 then
                    preview = preview .. '...'; break
                end
                preview = preview .. (it.label or it.item) .. ' x' .. (it.amount or 1)
                if i < math.min(#kit.items, 3) then preview = preview .. ', ' end
            end


            table.insert(options, {
                title       = '🎒 ' .. kit.name,
                description = string.format(GetLocale("nui.armory.kit_collect_desc") or '%d items: %s', itemCount,
                    preview),
                icon        = 'fa-solid fa-box-open',
                onSelect    = function()
                    TriggerServerEvent('xr-mdt:armory:collectKit', kit.id)
                end
            })


            table.insert(options, {
                title       = '🗑️  ' .. GetLocale("nui.armory.kit_delete") .. ': ' .. kit.name,
                description = GetLocale("nui.armory.kit_delete_desc") or 'Kliknij aby trwale usunąć ten zestaw.',
                icon        = 'fa-solid fa-trash',
                iconColor   = '#ef4444',
                onSelect    = function()
                    TriggerServerEvent('xr-mdt:armory:deleteKit', kit.id)
                end
            })
        end
    end

    lib.registerContext({
        id      = 'armory_kits_menu',
        title   = '📋 ' .. GetLocale("nui.armory.kits_title") .. ' — ' .. string.upper(jobName),
        options = options,
    })
    lib.showContext('armory_kits_menu')
end)




RegisterNetEvent('xr-mdt:armory:kitsUpdated', function(kits)
    if isArmoryOpen then
        SendNUIMessage({
            action = 'armoryKitsUpdated',
            data   = { kits = kits }
        })
    end
end)






RegisterNUICallback('armory:close', function(_, cb)
    isArmoryOpen = false
    currentArmoryJob = nil
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'closeArmory' })
    cb('ok')
end)


RegisterNUICallback('armory:collect', function(data, cb)
    if not data or not data.items or not currentArmoryJob then
        cb('error')
        return
    end

    TriggerServerEvent('xr-mdt:armory:collect', {
        job   = currentArmoryJob,
        items = data.items,
    })
    cb('ok')
end)


RegisterNUICallback('armory:saveKit', function(data, cb)
    if not data or not data.items or not data.name or not currentArmoryJob then
        cb('error')
        return
    end

    TriggerServerEvent('xr-mdt:armory:saveKit', {
        job   = currentArmoryJob,
        name  = data.name,
        items = data.items,
    })

    cb('ok')
end)


RegisterNUICallback('armory:getKits', function(_, cb)
    if not currentArmoryJob then
        cb('error'); return
    end


    SetNuiFocus(false, false)

    CreateThread(function()
        Wait(100)
        TriggerServerEvent('xr-mdt:armory:getKits')
    end)

    cb('ok')
end)


RegisterNUICallback('armory:syncStock', function(data, cb)
    if data and data.job then
        TriggerServerEvent('xr-mdt:armory:syncStock', data.job)
    end
    cb('ok')
end)




if GetResourceState('ox_inventory') == 'started' then
    AddEventHandler('ox_inventory:closedInventory', function()
        if currentArmoryJob then
            local armoryConfig = Config.Armory and Config.Armory.Jobs and Config.Armory.Jobs[currentArmoryJob]
            if armoryConfig and armoryConfig.Mode == 'limited' then
                TriggerServerEvent('xr-mdt:armory:syncStock', currentArmoryJob)
            end
        end
    end)
end

if Config.Debug then
    print('^2[XR-MDT]^7 Armory Client Module Loaded.')
end







if Config.Debug then
    local ARMORY_DEV_SAMPLE = {
        categories = {
            { id = 'weapons', label = 'Bron Palna',  icon = 'fa-solid fa-gun' },
            { id = 'ammo',    label = 'Amunicja',    icon = 'fa-solid fa-box' },
            { id = 'gear',    label = 'Wyposazenie', icon = 'fa-solid fa-shield-halved' },
            { id = 'medical', label = 'Medyczny',    icon = 'fa-solid fa-kit-medical' },
        },
        items = {
            { category = 'weapons', item = 'weapon_combatpistol', label = 'Pistolet Bojowy',    amount = 1,  minGrade = 0 },
            { category = 'weapons', item = 'weapon_pistol50',     label = 'Pistolet .50',       amount = 1,  minGrade = 3 },
            { category = 'weapons', item = 'weapon_stungun',      label = 'Taser',              amount = 1,  minGrade = 1 },
            { category = 'weapons', item = 'weapon_pumpshotgun',  label = 'Strzelba',           amount = 1,  minGrade = 4 },
            { category = 'weapons', item = 'weapon_carbinerifle', label = 'Karabin Bojowy',     amount = 1,  minGrade = 6 },
            { category = 'weapons', item = 'weapon_sniperrifle',  label = 'Karabin Snajperski', amount = 1,  minGrade = 10 },
            { category = 'ammo',    item = 'ammo-9',              label = 'Amunicja 9mm x50',   amount = 50, minGrade = 0 },
            { category = 'ammo',    item = 'ammo-rifle',          label = 'Amunicja 5.56 x30',  amount = 30, minGrade = 4 },
            { category = 'ammo',    item = 'ammo-shotgun',        label = 'Srut x15',           amount = 15, minGrade = 4 },
            { category = 'gear',    item = 'armor',               label = 'Kamizelka Kulood.',  amount = 1,  minGrade = 0 },
            { category = 'gear',    item = 'handcuffs',           label = 'Kajdanki',           amount = 1,  minGrade = 0 },
            { category = 'gear',    item = 'police_radio',        label = 'Radio Policyjne',    amount = 1,  minGrade = 0 },
            { category = 'gear',    item = 'spike_strip',         label = 'Kolce Drogowe',      amount = 2,  minGrade = 3 },
            { category = 'gear',    item = 'breachingcharge',     label = 'Ladunek Wywalajacy', amount = 1,  minGrade = 8 },
            { category = 'medical', item = 'bandage',             label = 'Opatrunek x3',       amount = 3,  minGrade = 0 },
            { category = 'medical', item = 'firstaid',            label = 'Apteczka',           amount = 1,  minGrade = 2 },
            { category = 'medical', item = 'adrenaline',          label = 'Adrenalina',         amount = 1,  minGrade = 5 },
        },
        kits = {
            {
                id = 1,
                name = 'Patrol Standardowy',
                items = {
                    { item = 'weapon_combatpistol', amount = 1,  label = 'Pistolet Bojowy' },
                    { item = 'ammo-9',              amount = 50, label = 'Amunicja 9mm x50' },
                    { item = 'armor',               amount = 1,  label = 'Kamizelka Kulood.' },
                    { item = 'handcuffs',           amount = 1,  label = 'Kajdanki' },
                }
            },
            {
                id = 2,
                name = 'Zestaw Taktyczny',
                items = {
                    { item = 'weapon_combatpistol', amount = 1, label = 'Pistolet Bojowy' },
                    { item = 'weapon_stungun',      amount = 1, label = 'Taser' },
                    { item = 'armor',               amount = 1, label = 'Kamizelka' },
                    { item = 'bandage',             amount = 3, label = 'Opatrunek x3' },
                }
            },
        },
    }

    local function OpenArmoryDev(jobArg, gradeArg)
        if IsPauseMenuActive() then return end
        jobArg             = jobArg or 'police'
        gradeArg           = gradeArg or 3

        local armoryConfig = Config.Armory and Config.Armory.Jobs and Config.Armory.Jobs[jobArg]
        local payload

        if armoryConfig then
            local realItems = {}
            for _, item in ipairs(armoryConfig.Items or {}) do
                local minG = (item.minGrade == 'all') and 0 or (tonumber(item.minGrade) or 0)
                table.insert(realItems, {
                    category   = item.category,
                    item       = item.item,
                    label      = item.label,
                    amount     = item.amount,
                    minGrade   = item.minGrade,
                    accessible = (gradeArg >= minG),
                })
            end
            local fakeStock = {}
            if armoryConfig.Mode == 'limited' then
                for _, item in ipairs(armoryConfig.Items or {}) do
                    fakeStock[item.item] = math.random(0, 25)
                end
            end
            payload = {
                job         = jobArg,
                mode        = armoryConfig.Mode or 'unlimited',
                categories  = armoryConfig.Categories or ARMORY_DEV_SAMPLE.categories,
                items       = realItems,
                stock       = fakeStock,
                playerGrade = gradeArg,
                kits        = ARMORY_DEV_SAMPLE.kits,
                _devMode    = true,
            }
        else
            local sampleItems = {}
            for _, item in ipairs(ARMORY_DEV_SAMPLE.items) do
                local minG = tonumber(item.minGrade) or 0
                local copy = {}
                for k, v in pairs(item) do copy[k] = v end
                copy.accessible = (gradeArg >= minG)
                table.insert(sampleItems, copy)
            end
            payload = {
                job         = jobArg,
                mode        = 'unlimited',
                categories  = ARMORY_DEV_SAMPLE.categories,
                items       = sampleItems,
                stock       = {},
                playerGrade = gradeArg,
                kits        = ARMORY_DEV_SAMPLE.kits,
                _devMode    = true,
            }
        end

        isArmoryOpen     = true
        currentArmoryJob = jobArg

        SendNUIMessage({ action = 'openArmory', data = payload })
        SetNuiFocus(true, true)

        print(string.format('^2[XR-MDT ARMORY DEV]^7 Preview: job=^3%s^7 grade=^3%d^7 mode=^3%s^7',
            jobArg, gradeArg, payload.mode))
    end

    RegisterCommand('armory_dev', function(_, args)
        OpenArmoryDev(args[1], tonumber(args[2]))
    end, false)

    CreateThread(function()
        Wait(2000)
        RegisterKeyMapping('armory_dev', '[DEV] Zbrojownia - podglad', 'keyboard', 'F9')
    end)

    print('^3[XR-MDT ARMORY DEV]^7 /armory_dev [job] [grade] | F9')
end
