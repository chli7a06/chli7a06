Config = Config or {}

Config.EMS = {
    -- General Settings
    -- Job name
    JobName = 'ambulance',
    -- Command
    TabletCommand = 'emdt',
    -- Key to open tablet
    OpenKey = 'INSERT',
    -- Red
    BlipColor = 1,

    -- Permissions
    Grades = {
        ['0'] = {
            label = 'Trainee',
            permissions = {
                dashboard_view = true,
                profiles_view = true,
                profiles_edit = false,
                reports_view = true,
                reports_create = true,
                reports_delete = false,
                employees_view = true,
                employees_manage = false,
                dispatch_view = true
            }
        },
        ['1'] = {
            label = 'Paramedic',
            permissions = {
                dashboard_view = true,
                profiles_view = true,
                profiles_edit = true,
                reports_view = true,
                reports_create = true,
                reports_delete = false,
                employees_view = true,
                employees_manage = false,
                dispatch_view = true
            }
        },
        ['2'] = {
            label = 'Doctor',
            permissions = {
                dashboard_view = true,
                profiles_view = true,
                profiles_edit = true,
                reports_view = true,
                reports_create = true,
                reports_delete = true,
                employees_view = true,
                employees_manage = false,
                dispatch_view = true
            }
        },
        ['3'] = {
            label = 'Head of Department',
            permissions = {
                dashboard_view = true,
                profiles_view = true,
                profiles_edit = true,
                reports_view = true,
                reports_create = true,
                reports_delete = true,
                employees_view = true,
                employees_manage = true,
                dispatch_view = true,
                admin = true
            }
        },
        ['4'] = {
            label = 'Director',
            permissions = {
                dashboard_view = true,
                profiles_view = true,
                profiles_edit = true,
                reports_view = true,
                reports_create = true,
                reports_delete = true,
                employees_view = true,
                employees_manage = true,
                dispatch_view = true,
                admin = true
            }
        }
    },

    -- Radio Codes / Statuses
    RadioCodes = {
        { code = '10-8',     label = 'Available' },
        { code = '10-7',     label = 'Out of Service' },
        { code = '10-6',     label = 'Busy' },
        { code = '10-20',    label = 'Location Request' },
        { code = '10-4',     label = 'Received / Copy' },
        { code = 'Status 1', label = 'Starting Duty' },
        { code = 'Status 5', label = 'On Scene' },
        { code = 'Status 7', label = 'En Route to Hospital' }
    },

    -- Documents / Procedures
    Documents = {
        { title = 'Medical Procedures', url = 'https://docs.google.com/document/d/1exampleid/preview' },
        { title = 'Price List',         url = 'https://docs.google.com/document/d/2exampleid/preview' },
        { title = 'Medications Guide',  url = 'https://docs.google.com/document/d/3exampleid/preview' }
    },

    -- Medical Price List (Categories)
    Tariff = {
        visits = {
            label = 'Visits & Transport',
            options = {
                { name = 'onSite',         label = 'On-site Visit',                 cost = 100 },
                { name = 'transportLocal', label = 'Medical Transport (up to 5km)', cost = 200 },
                { name = 'transportLong',  label = 'Medical Transport (over 5km)',  cost = 400 },
                { name = 'heliTransport',  label = 'Air Transport (LifeFlight)',    cost = 1500 },
                { name = 'falseCall',      label = 'False Emergency Call',          cost = 1000 }
            }
        },
        treatment = {
            label = 'Basic Treatment',
            options = {
                { name = 'bandage',       label = 'Simple Bandaging',    cost = 50 },
                { name = 'stitch',        label = 'Suturing Wounds',     cost = 300 },
                { name = 'resuscitation', label = 'Resuscitation (CPR)', cost = 500 },
                { name = 'detox',         label = 'Detoxification',      cost = 400 },
                { name = 'stabilization', label = 'Stabilization',       cost = 300 },
                { name = 'plaster',       label = 'Casting',             cost = 400 }
            }
        },
        surgeries = {
            label = 'Surgeries & Procedures',
            options = {
                { name = 'bulletRemoval',  label = 'Bullet Removal',   cost = 1500 },
                { name = 'surgerySmall',   label = 'Minor Surgery',    cost = 2000 },
                { name = 'surgeryComplex', label = 'Major Surgery',    cost = 5000 },
                { name = 'transplant',     label = 'Organ Transplant', cost = 10000 },
                { name = 'plasticSurgery', label = 'Plastic Surgery',  cost = 8000 }
            }
        },
        exams = {
            label = 'Examinations',
            options = {
                { name = 'bloodTest', label = 'Blood Test',     cost = 100 },
                { name = 'xray',      label = 'X-Ray',          cost = 200 },
                { name = 'mri',       label = 'MRI Scan',       cost = 500 },
                { name = 'drugTest',  label = 'Drug Screening', cost = 150 }
            }
        }
    },

    -- List of medications available in system
    Medications = {
        'Morphine',
        'Adrenaline',
        'Bandage',
        'Antibiotic'
    },

    Vehicles = {
        { model = 'dlamb',        label = 'Ambulance (Standard)', price = 45000,  category = 'ambulance' },
        { model = 'emsnspeedo',   label = 'Ambulance (Speedo)',   price = 55000,  category = 'ambulance' },
        { model = 'dlissiamb',    label = 'Weeny Issi Med',       price = 25000,  category = 'car' },
        { model = 'dlgranger',    label = 'Declasse Granger',     price = 45000,  category = 'car' },
        { model = 'dlbuffalo',    label = 'Bravado Buffalo',      price = 55000,  category = 'car' },
        { model = 'dlemsb',       label = 'Rescue Motorcycle',    price = 20000,  category = 'bike' },
        { model = 'dlswift',      label = 'Swift Helicopter',     price = 150000, category = 'heli' },
        { model = 'dlwheelchair', label = 'Wheelchair',           price = 1000,   category = 'other' }
    },

    VehicleCategories = {
        ['ambulance'] = 'Ambulances',
        ['car'] = 'Cars',
        ['bike'] = 'Bikes',
        ['heli'] = 'Aviation',
        ['other'] = 'Other'
    }
}
