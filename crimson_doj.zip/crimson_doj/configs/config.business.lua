Config = Config or {}

Config.Business = {
    -- General Settings
    -- Command to open the BizPad
    TabletCommand = 'bizpad',
    OpenKey = 'DELETE',

    -- List of jobs allowed to use the BizPad system.
    -- If your server uses separate jobs per business, add them here.
    AllowedJobs = {
        'mechanic',
        'cardealer',
        'realestate',
        'taxi',
        'burgershot',
        'uwucafe',
        'bus',
        'mm3_mecano',
    },

    -- ============================================================
    -- PER-BUSINESS BRANDING (Optional)
    -- Customize the appearance of each business in the BizPad UI.
    -- Key = job name (must match AllowedJobs entry and framework job)
    -- If a job is NOT listed here, it uses default framework label + no logo.
    -- Supported image formats: .png, .webp, .jpg
    -- ============================================================
    JobSettings = {
        ['bus'] = {
            DisplayName = 'BUS',
            -- place file in web/dist/
            LogoFile    = 'images/biz_bus.png',
            Colors      = {
                -- main accent color
                primary     = '#f97316',
                primaryDark = '#c2410c',
                bg          = 'rgba(249, 115, 22, 0.1)'
            },
        },
        ['mechanic'] = {
            DisplayName = 'Los Santos Customs',
            -- place file in web/dist/
            LogoFile    = 'images/biz_mechanic.webp',
            Colors      = {
                -- main accent color
                primary     = '#f97316',
                primaryDark = '#c2410c',
                bg          = 'rgba(249, 115, 22, 0.1)'
            },
        },
        ['cardealer'] = {
            DisplayName = 'Premium Deluxe Motorsport',
            LogoFile    = 'images/biz_cardealer.webp',
        },
        ['burgershot'] = {
            DisplayName = 'Burger Shot',
            LogoFile    = 'images/biz_burgershot.png',
            Colors      = {
                primary     = '#ef4444',
                primaryDark = '#b91c1c',
                bg          = 'rgba(239, 68, 68, 0.1)'
            },
        },
        ['catcafe'] = {
            DisplayName = 'UwU Café',
            LogoFile    = 'images/biz_uwucafe.webp',
            Colors      = {
                primary     = '#ec4899',
                primaryDark = '#be185d',
                bg          = 'rgba(236, 72, 153, 0.1)'
            },
        },
        -- Add more businesses as needed:
        -- ['taxi'] = {
        --     DisplayName = 'Downtown Cab Co.',
        --     LogoFile    = 'images/biz_taxi.jpg',
        -- },
    },

    -- Permissions
    -- Define 'default' for all businesses, then override per-job (e.g. 'mechanic')
    Grades = {
        ['default'] = {
            -- Employee
            ['0'] = {
                permissions = {
                    dashboard_view = true,
                    employees_view = true,
                    employees_manage = false,
                    invoices_create = true,
                    invoices_view = true,
                    invoice_custom = false,
                    tariff_view = true,
                    tariff_manage = false
                }
            },
            -- Experienced
            ['1'] = {
                permissions = {
                    dashboard_view = true,
                    employees_view = true,
                    employees_manage = false,
                    invoices_create = true,
                    invoices_view = true,
                    invoice_custom = false,
                    tariff_view = true,
                    tariff_manage = false
                }
            },
            -- Manager
            ['2'] = {
                permissions = {
                    dashboard_view = true,
                    employees_view = true,
                    employees_manage = true,
                    invoices_create = true,
                    invoices_view = true,
                    invoice_custom = true,
                    tariff_view = true,
                    tariff_manage = true,
                    admin = true
                }
            },
            -- Owner
            ['3'] = {
                permissions = {
                    dashboard_view = true,
                    employees_view = true,
                    employees_manage = true,
                    invoices_create = true,
                    invoices_view = true,
                    invoice_custom = true,
                    tariff_view = true,
                    tariff_manage = true,
                    admin = true
                }
            },
            -- Owner+
            ['4'] = {
                permissions = {
                    dashboard_view = true,
                    employees_view = true,
                    employees_manage = true,
                    invoices_create = true,
                    invoices_view = true,
                    invoice_custom = true,
                    tariff_view = true,
                    tariff_manage = true,
                    admin = true
                }
            }
        },
        -- Example: Mechanic (custom override)
        ['mechanic'] = {
            ['0'] = {
                label = 'Trainee',
                permissions = { dashboard_view = true, invoices_create = true, invoice_custom = false, invoices_view = true, tariff_view = true, employees_view = true, tariff_manage = false }
            },
            ['1'] = {
                label = 'Mechanic',
                permissions = { dashboard_view = true, invoices_create = true, invoice_custom = false, invoices_view = true, tariff_view = true, employees_view = true, tariff_manage = false }
            },
            ['2'] = {
                label = 'Specialist',
                permissions = { dashboard_view = true, invoices_create = true, invoice_custom = true, invoices_view = true, tariff_view = true, employees_view = true, tariff_manage = false }
            },
            ['3'] = {
                label = 'Manager',
                permissions = { dashboard_view = true, invoices_create = true, invoice_custom = true, invoices_view = true, tariff_view = true, employees_view = true, tariff_manage = true }
            },
            ['4'] = {
                label = 'Boss',
                permissions = { dashboard_view = true, employees_view = true, employees_manage = true, invoices_create = true, invoice_custom = true, invoices_view = true, tariff_view = true, tariff_manage = true, admin = true }
            }
        },
        ['uwucafe'] = {
            ['0'] = { label = 'Trial Kitten', permissions = { dashboard_view = true, invoices_create = true, invoices_view = true, tariff_view = true, employees_view = true, employees_manage = false, tariff_manage = false, admin = false } },
            ['1'] = { label = 'Junior Waiter', permissions = { dashboard_view = true, invoices_create = true, invoices_view = true, tariff_view = true, employees_view = true, employees_manage = false, tariff_manage = false, admin = false } },
            ['2'] = { label = 'Waiter', permissions = { dashboard_view = true, invoices_create = true, invoices_view = true, tariff_view = true, employees_view = true, employees_manage = false, tariff_manage = false, admin = false } },
            ['3'] = { label = 'Barista', permissions = { dashboard_view = true, invoices_create = true, invoices_view = true, tariff_view = true, employees_view = true, employees_manage = false, tariff_manage = false, admin = false } },
            ['4'] = { label = 'Senior Barista', permissions = { dashboard_view = true, invoices_create = true, invoices_view = true, tariff_view = true, employees_view = true, employees_manage = false, tariff_manage = false, admin = false } },
            ['5'] = { label = 'Dessert Chef', permissions = { dashboard_view = true, invoices_create = true, invoices_view = true, tariff_view = true, employees_view = true, employees_manage = false, tariff_manage = false, admin = false } },
            ['6'] = { label = 'Sweetness Specialist', permissions = { dashboard_view = true, invoices_create = true, invoices_view = true, tariff_view = true, employees_view = true, employees_manage = false, tariff_manage = false, admin = false } },
            ['7'] = { label = 'Floor Manager', permissions = { dashboard_view = true, invoices_create = true, invoices_view = true, tariff_view = true, employees_view = true, employees_manage = true, tariff_manage = true, admin = false } },
            ['8'] = { label = 'Manager', permissions = { dashboard_view = true, invoices_create = true, invoices_view = true, tariff_view = true, employees_view = true, employees_manage = true, tariff_manage = true, admin = true } },
            ['9'] = { label = 'Deputy Owner', permissions = { dashboard_view = true, invoices_create = true, invoices_view = true, tariff_view = true, employees_view = true, employees_manage = true, tariff_manage = true, admin = true } },
            ['10'] = { label = 'UwU Owner', permissions = { dashboard_view = true, invoices_create = true, invoices_view = true, tariff_view = true, employees_view = true, employees_manage = true, tariff_manage = true, admin = true } },
        },
        ['bus'] = {
            ['0'] = { label = 'Owner', permissions = { dashboard_view = true, employees_view = true, employees_manage = true, invoices_create = true, invoices_view = true, invoice_custom = true, tariff_view = true, tariff_manage = true, admin = true } },
        },
    },

    -- Limits
    MaxInvoicesPerDay = 50,
    MaxBonusAmount = 10000
}
