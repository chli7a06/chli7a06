Config = Config or {}

-- Master switch for debugging (true/false)
Config.Debug = false

EditTable = {
    Events = {},
    Business = { Events = {}, Queries = {}, ClientEvents = {} },
    LSPD = { Events = {}, Queries = {}, ClientEvents = {} },
    EMS = { Events = {}, Queries = {}, ClientEvents = {} },
    DOJ = { Events = {}, Queries = {}, ClientEvents = {} },
}

Config.EnableLSPD = false
Config.EnableEMS = false
Config.EnableDOJ = true
Config.EnableBusiness = true
Config.EnableDispatch = false
-- Set to false for OX/QB if you want to use manual exports/events
Config.InventoryAutoRegister = true

Config.Items = {
    bodycam = 'bodycam',
    gps = 'gps',
    document = 'document',
    tracking_band = 'tracking_band'
}

Config.WeaponSerialization = {
    Enabled = true,
    -- Serial Number Prefix
    Prefix = 'SN',
    -- X = random alphanumeric
    Format = 'XXXX-XXXX-XXXX',
}

Config.Tablet = {
    Command = 'dojmdt',
    -- Default key to open MDT
    Key = 'F12'
}

Config.Framework = 'qbox'
-- 'en' / 'pl'
Config.Language = 'en'

if Config.Framework == 'auto' then
    local qbState = GetResourceState('qb-core')
    local esxState = GetResourceState('es_extended')
    local qboxState = GetResourceState('qbx_core')
    if qboxState == 'missing' then qboxState = GetResourceState('qbx-core') end


    if qboxState == 'started' or qboxState == 'starting' then
        Config.Framework = 'qbox'
    elseif qbState == 'started' or qbState == 'starting' then
        Config.Framework = 'qb'
    elseif esxState == 'started' or esxState == 'starting' then
        Config.Framework = 'esx'
    else
        Config.Framework = 'qb'
    end
end

-- --- Job Helpers ---
function Config.IsEnforcementJob(jobName)
    -- Default legacy check
    if jobName == 'fbi' or jobName == 'fbi' then return true end
    if Config.EnablePoliceJobs then
        for _, name in ipairs(Config.EnablePoliceJobs) do
            if name == jobName then return true end
        end
    end
    -- Also check if it's in Config.PoliceJobs keys
    if Config.PoliceJobs and Config.PoliceJobs[jobName] then return true end
    return false
end

function Config.IsMedicalJob(jobName)
    if jobName == 'ambulance' then return true end
    if Config.EMS and Config.EMS.JobName == jobName then return true end
    return false
end

-- Enables custom duty system for ESX (QB/Qbox have it native)
Config.ESXDuty = true
-- Change if your phone script uses a different column in 'users' table or metadata key
Config.ESXPhoneNumberColumn = 'phoneNumber'

Config.Notify = {
    Type = 'qb',
    Duration = 5000
}

Config.Blips = {
}

Config.HeliSpawns = {
    LSPD = {
        PedCoords = vector4(441.7479, -982.4587, 43.6913, 267.5688),
        PedModel = 's_m_y_cop_01',
        SpawnCoords = vector4(449.2901, -981.1782, 43.6913, 86.4242),
        MinGrade = 10,
        VehicleModel = 'polmav',
        Livery = 0,
        Job = 'fbi'
    },
    EMS = {
        PedCoords = vector4(97.1774, -410.5634, 84.4043, 334.1735),
        PedModel = 's_m_m_paramedic_01',
        SpawnCoords = vector4(94.9258, -421.5803, 86.3002, 159.1965),
        MinGrade = 4,
        VehicleModel = 'polmav',
        Livery = 1,
        Job = 'ambulance'
    }
}
Config.Printers = {
    {
        -- LSPD Printer
        Coords = vector3(-446.52178955078, -1036.7786865234, 24.166234970093),
        Label = 'LSPD MRPD Printer',
        Distance = 20.0
    },
    {
        -- Example DOJ Printer
        Coords = vector3(-578.5267, -218.7574, 39.1078),
        Label = 'Court Printer',
        Distance = 20.0
    },
    {
        -- Example EMS Printer
        Coords = vector3(2054.33, 2616.63, 54.44),
        Label = 'Border Printer',
        Distance = 20.0
    }
}

-- ============================================================
-- Document Archive (Kartoteka) System
-- ============================================================
Config.Archives = {
    {
        -- LSPD MRPD Archive Room
        Coords = vector3(-448.54064941406, -1047.98046875, 25.333799362183),
        Label = "Police Archive",
        Distance = 2.0,
        Job = "fbi",
        Permissions = {
            -- Minimum grade to browse
            view = 0,
            -- Minimum grade to store a document
            add = 1,
            -- Minimum grade to take a document out
            remove = 5
        }
    },
    {
        -- DOJ Court Archive
        Coords = vector3(-586.48, -203.49, 38.23),
        Label = "Court Archive",
        Distance = 2.0,
        Job = "doj",
        Permissions = {
            view = 0,
            add = 0,
            remove = 3
        }
    }
}

-- ============================================================
-- Bodycam Usable Item System
-- ============================================================
Config.Bodycam = {
    -- Jobs that are allowed to USE (equip) a bodycam item
    AllowedJobs = { "fbi", "pd", "ambulance" },

    -- ============================================================
    -- Grupy uprawnień do komendy /bodycampos (admin drag mode)
    -- Działa dla QB/QBox (player.PlayerData.group) i ESX (xPlayer.getGroup())
    -- Dodatkowo obsługuje FiveM ACE: add_ace identifier xr-mdt.bodycampos allow
    -- ============================================================
    AdminGroups = { "admin", "superadmin", "god" },

    -- ============================================================
    -- Bodycam HUD position on screen (domyślna, nadpisywana przez /bodycampos)
    -- ============================================================
    -- Anchor: 'top-right' | 'top-left' | 'top-center'
    --         'bottom-right' | 'bottom-left' | 'bottom-center'
    Position = {
        Anchor = 'top-right',
        -- Offset from screen edge in pixels
        OffsetX = 200,
        OffsetY = 18,
    },
}



-- GPS Tracking Band System Configuration
Config.TrackingBands = {
    BypassMinigameGrades = {
        ['fbi'] = 5,
        ['pd'] = 5,
        ['sheriff'] = 3,
        ['bcso'] = 2,
    },
    MinigameType = 'ox_lib',
}
