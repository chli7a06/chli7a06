Config                  = Config or {}

-- ============================================================
-- MULTI-FACTION POLICE CONFIG
-- Each police faction has its own settings.
-- Table key = job name in the framework (e.g., 'police', 'sheriff', 'bcso')
-- ============================================================

Config.PoliceJobs       = {

    -- ========================================================
    -- LSPD — Los Santos Police Department
    -- ========================================================
    ['fbi2'] = {
        -- Displayed data
        DisplayName         = 'Los Santos Federal Bureau Of Investigation',
        -- file in web/dist/
        LogoFile            = 'images/lspd.webp',
        -- NUI theme CSS class
        Theme               = 'FBI',
        -- overwrites NUI colors regardless of Theme
        Colors              = {
            primary = '#38bdf8',
            primaryDark = '#0284c7',
            bg = 'rgba(56, 189, 248, 0.1)'
        },

        -- Commands / keys
        TabletCommand       = 'dojmdt',
        OpenKey             = 'F12',

        -- Bodycam number prefix: POLICE-XXXXXXXXX
        CamPrefix           = 'DOJ',

        -- Plate generator prefix
        PlatePrefix         = 'FBI',

        -- GPS Blip Color (ID FiveM)
        -- Blue
        BlipColor           = 3,

        -- Status codes (threat level)
        Codes               = {
            { id = 'green',  label = 'CODE GREEN',  color = '#22c55e', description = 'Stable situation. Patrol normally.' },
            { id = 'yellow', label = 'CODE ORANGE', color = '#f97316', description = 'Elevated risk. Increased vigilance.' },
            { id = 'red',    label = 'CODE RED',    color = '#ef4444', description = 'Emergency. Severe security threat.' },
            { id = 'black',  label = 'CODE BLACK',  color = '#0f172a', description = 'Critical state. City lockdown.' },
        },

        -- Documents / procedures visible in the tab
        Documents           = {
            { title = 'FBI Rules',    url = 'https://docs.google.com/document/d/19knGU3RuuLBLhk7PHFMLaTVcy9DKerMHgcK_MVPUpio/edit?usp=sharing' },
            { title = 'FBI Database', url = 'https://docs.google.com/spreadsheets/d/example-lspd' },
        },

        -- Permissions per grade (key = grade level as string)
        Grades              = {
            ['0']  = { label = 'FBI Academy Trainee', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = false, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = false, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = false, admin = false, code_change = false, custom_fine = false, custom_sentence = false, weapons_view = true, units_view = true, units_manage = false } },
            ['1']  = { label = 'Junior Special Agent', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = true, admin = false, code_change = false, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = false } },
            ['2']  = { label = 'Special Agent', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = true, admin = false, code_change = false, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = false } },
            ['3']  = { label = 'Senior Special Agent', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = true, admin = false, code_change = false, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = false } },
            ['4']  = { label = 'Assistant Special Agent in Charge', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = true, admin = false, code_change = false, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = false } },
            ['5']  = { label = 'Special Agent in Charge', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = true, admin = false, code_change = true, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = true } },
            ['6']  = { label = 'Deputy Director', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, dispatch_view = true, cameras_view = true, admin = true, code_change = true, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = true } },
            ['7']  = { label = 'Director of the FBI', permissions = { dashboard_view = true, profiles_view = true, profiles_create = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, dispatch_view = true, cameras_view = true, admin = true, code_change = true, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = true } },
        },

        -- Vehicles available for this faction in MDT Garage
        Vehicles            = {
            { model = 'pdstanier',    label = 'Vapid Stanier',           price = 45000,  category = 'patrol' },
            { model = 'pdfugitive',   label = 'Cheval Fugitive',         price = 50000,  category = 'patrol' },
            { model = 'pdjackal',     label = 'Ocelot Jackal',           price = 55000,  category = 'patrol' },
            { model = 'pdschafter',   label = 'Benefactor Schafter',     price = 60000,  category = 'patrol' },
            { model = 'pdbuffalo2',   label = 'Bravado Buffalo S',       price = 60000,  category = 'patrol' },
            { model = 'pdbuffalostx', label = 'Bravado Buffalo STX',     price = 70000,  category = 'patrol' },
            { model = 'pdgranger2',   label = 'Declasse Granger 3600LX', price = 75000,  category = 'suv' },
            { model = 'pdballer4',    label = 'Gallivanter Baller LE',   price = 75000,  category = 'suv' },
            { model = 'pdrebla',      label = 'Ubermacht Rebla GTS',     price = 85000,  category = 'suv' },
            { model = 'pdscout',      label = 'Vapid Scout',             price = 80000,  category = 'suv' },
            { model = 'pdtoros',      label = 'Pegassi Toros',           price = 90000,  category = 'suv' },
            { model = 'pdcoquette',   label = 'Invetero Coquette',       price = 95000,  category = 'sport' },
            { model = 'pddominator3', label = 'Vapid Dominator GTX',     price = 100000, category = 'sport' },
            { model = 'pdgauntlet',   label = 'Bravado Gauntlet',        price = 95000,  category = 'sport' },
            { model = 'pdmanchez2',   label = 'Maibatsu Manchez Scout',  price = 35000,  category = 'bike' },
            { model = 'pddouble',     label = 'Western Powersurge',      price = 45000,  category = 'bike' },
            { model = 'pdrbike',      label = 'Western Police Bike',     price = 40000,  category = 'bike' },
            { model = 'pdscorcher',   label = 'Police Mountain Bike',    price = 5000,   category = 'other' },
        },

        VehicleCategories   = {
            ['patrol'] = 'Patrol',
            ['sport']  = 'Interceptors',
            ['suv']    = 'SUV / Offroad',
            ['bike']   = 'Bikes',
            ['other']  = 'Other',
        },

        -- Penal code (only for LSPD, can be disabled for others)
        -- Custom Vehicle Images (for non-GTA cars)
        -- Key = vehicle model, Value = image link (.png, .webp, .jpg)
        CustomVehicleImages = {
            -- ['model_auta'] = 'https://link.do/zdjecia.png',
        },

        PenalCode = {
    traffic = {
        label = "Infractions Routières & Transports",
        options = {
            { name = 'boat_coast', label = "Stationnement d'un bateau sur la côte hors d'un port", jail = 0, fine = 450 },
            { name = 'plane_land', label = "Atterrissage d'un avion/hélico sur site inapproprié", jail = 0, fine = 450 },
            { name = 'plane_fly', label = "Survol d'un avion/hélico sur site inapproprié", jail = 0, fine = 135 },
            { name = 'dangerous_driving', label = "Conduite dangereuse (aérien, maritime, terrestre)", jail = 0, fine = 2700 },
            { name = 'speeding_radar', label = "Excès de vitesse (contrôle radar)", jail = 0, fine = 1800 },
            { name = 'big_speeding_radar', label = "Grand excès de vitesse (contrôle radar >50km/h)", jail = 0, fine = 3000 },
            { name = 'parking_obstacle', label = "Stationnement Gênant", jail = 0, fine = 270 },
            { name = 'horn_abuse', label = "Usage abusif du Klaxon", jail = 0, fine = 450 },
            { name = 'wrong_way', label = "Conduite en contresens", jail = 0, fine = 2700 },
            { name = 'no_plate', label = "Défaut de plaque d'immatriculation", jail = 0, fine = 1750 },
            { name = 'no_license', label = "Conduite sans permis", jail = 15, fine = 1350 },
            { name = 'hit_and_run', label = "Délit de fuite", jail = 15, fine = 1350 },
            { name = 'refusal_comply', label = "Refus d'obtempérer", jail = 15, fine = 900 },
            { name = 'fake_plate', label = "Possession ou utilisation d'une fausse plaque", jail = 5, fine = 120 },
            { name = 'airspace_obstacle', label = "Entrave espaces aériens", jail = 10, fine = 900 },
            { name = 'illegal_street_race', label = "Course de rue illégale", jail = 10, fine = 1350 },
        }
    },
    civil_order = {
        label = "Ordre Public & Civilité",
        options = {
            { name = 'indecency', label = "Atteinte à la pudeur", jail = 0, fine = 450 },
            { name = 'face_concealment', label = "Dissimulation du visage", jail = 0, fine = 540 },
            { name = 'civil_insult', label = "Insulte envers un civil", jail = 0, fine = 270 },
            { name = 'drunk_public', label = "Ivresse ou consommation de stupéfiants sur VP", jail = 0, fine = 270 },
            { name = 'begging_public', label = "Mendicité en lieu public", jail = 0, fine = 1350 },
            { name = 'no_papers', label = "Non présentation des papiers d'identité", jail = 0, fine = 450 },
            { name = 'illegal_manifestation', label = "Participation à une manifestation illégale", jail = 0, fine = 135 },
            { name = 'night_disturbance', label = "Tapage nocturne", jail = 0, fine = 360 },
            { name = 'fake_calls', label = "Faux Appels (Canulars)", jail = 0, fine = 405 },
            { name = 'public_disturbance', label = "Troubles à l'ordre public", jail = 15, fine = 1350 },
            { name = 'illegal_manifestation_org', label = "Organisateur d'une manifestation illégale", jail = 15, fine = 4100 },
            { name = 'state_emergency_violation', label = "Non respect des consignes de l'État d'Urgence", jail = 30, fine = 4500 },
            { name = 'prostitution_incitement', label = "Sollicitation ou incitation à la prostitution", jail = 60, fine = 9000 },
            { name = 'discrimination', label = "Discrimination", jail = 20, fine = 7200 },
            { name = 'harassment', label = "Harcèlement", jail = 20, fine = 15000 },
            { name = 'defamation', label = "Diffamation", jail = 15, fine = 3500 },
        }
    },
    robberies_vandalism = {
        label = "Vols, Cambriolages & Dégradations",
        options = {
            { name = 'property_damage', label = "Dégradations de biens publics/privés/matériels", jail = 0, fine = 1100 },
            { name = 'lockpick_flagrant', label = "Possession ou flagrant délit de crochetage", jail = 0, fine = 225 },
            { name = 'stolen_car_driving', label = "Conduite d'un véhicule volé", jail = 15, fine = 1350 },
            { name = 'store_robbery', label = "Braquage de Supérette", jail = 20, fine = 2250 },
            { name = 'atm_robbery', label = "Braquage d'ATM / Piratage d'ATM", jail = 15, fine = 2250 },
            { name = 'burglary', label = "Cambriolage", jail = 15, fine = 1350 },
            { name = 'theft', label = "Vol", jail = 15, fine = 1350 },
            { name = 'company_equipment_theft', label = "Vol d'équipements d'entreprise", jail = 10, fine = 450 },
            { name = 'company_product_theft', label = "Vol de produits d'entreprise", jail = 10, fine = 45 },
            { name = 'vehicle_theft', label = "Vol de véhicule", jail = 10, fine = 2000 },
            { name = 'stolen_vehicle_handling', label = "Recel de véhicule volé", jail = 10, fine = 2025 },
            { name = 'stolen_goods_handling', label = "Recel de vol (objets + armes légales)", jail = 10, fine = 50 },
            { name = 'property_trespassing', label = "Violation propriété privée (Entreprise/logement)", jail = 15, fine = 1800 },
            { name = 'company_robbery', label = "Braquage de Société", jail = 30, fine = 44000 },
            { name = 'brinks_attack', label = "Attaque convoi de fonds (Brinks, Convoi SAMP)", jail = 45, fine = 8500 },
            { name = 'armory_robbery', label = "Braquage d'armurerie", jail = 25, fine = 7200 },
            { name = 'jewelry_robbery', label = "Braquage à main armée bijouterie/supermarché", jail = 30, fine = 9000 },
            { name = 'pacific_bank', label = "Braquage de banque centrale (Pacifique banque)", jail = 60, fine = 25000 },
            { name = 'human_labs', label = "Braquage Du Human Labs", jail = 60, fine = 18000 },
            { name = 'fleeca_bank', label = "Braquage de banque (fleeca, Pine Banque Roxwood)", jail = 25, fine = 15000 },
            { name = 'armed_robbery', label = "Vol à main armée", jail = 30, fine = 5000 },
            { name = 'large_scale_robbery', label = "Braquage organisé de grande envergure", jail = 30, fine = 22500 },
        }
    },
    weapons_combat = {
        label = "Armes, Équipements & Violences",
        options = {
            { name = 'illegal_holster', label = "Holster interdit", jail = 0, fine = 1350 },
            { name = 'handgun_exhibition', label = "Exhibition d'armes de poing", jail = 15, fine = 1350 },
            { name = 'heavy_weapon_exhibition', label = "Exhibition d'armes lourdes/automatique", jail = 30, fine = 4500 },
            { name = 'weapon_discharge', label = "Utilisation d'une arme à feu", jail = 15, fine = 1350 },
            { name = 'illegal_weapon_use', label = "Utilisation illégale d'une arme légale", jail = 10, fine = 1500 },
            { name = 'non_compliant_hunting_weapon', label = "Port d'arme de chasse non réglementaire", jail = 10, fine = 1350 },
            { name = 'weapon_barrel_possession', label = "Possession de Canon d'arme", jail = 10, fine = 2000 },
            { name = 'weapon_acc_possession', label = "Possession d'accessoires d'armes (silencieux...)", jail = 20, fine = 10000 },
            { name = 'weapon_sale_illegal', label = "Vente illégale d'armes", jail = 30, fine = 12500 },
            { name = 'weapon_traffic_large', label = "Trafic d'armes à grande échelle", jail = 60, fine = 27000 },
            { name = 'weapon_buy_illegal', label = "Achat d'armes illégales", jail = 30, fine = 12500 },
            { name = 'weapon_storage_illegal', label = "Entreposage d'armes illégales", jail = 30, fine = 9000 },
            { name = 'kevlar_possession', label = "Port de Kevlar / Gilet par Balle", jail = 15, fine = 5000 },
            { name = 'kevlar_item_possession', label = "Possession de Gilet par balle", jail = 25, fine = 15000 },
            { name = 'handcuffs_illegal_use', label = "Utilisation illégale de menottes/serflex", jail = 5, fine = 120 },
            { name = 'shootout_participation', label = "Participation à une fusillade", jail = 30, fine = 3500 },
            { name = 'explosive_attack', label = "Attaque à l'explosif", jail = 30, fine = 7500 },
            -- Blanches / Contondantes
            { name = 'melee_machete', label = "Possession de Machette", jail = 10, fine = 2000 },
            { name = 'melee_fork', label = "Possession de Fourchette Tordue", jail = 10, fine = 2000 },
            { name = 'melee_knife', label = "Possession de Couteau Artisanal", jail = 10, fine = 2000 },
            { name = 'melee_bottle', label = "Possession de tesson de bouteille", jail = 10, fine = 2000 },
            { name = 'melee_axe', label = "Possession de Hache", jail = 10, fine = 2000 },
            { name = 'melee_war_axe', label = "Possession de Hache de GUERRE", jail = 10, fine = 2000 },
            { name = 'melee_dagger', label = "Possession de Dague antique", jail = 10, fine = 2000 },
            -- Armes de poing (Pistolets)
            { name = 'pos_pistol_17', label = "Possession de Pistolet 17", jail = 10, fine = 15000 },
            { name = 'pos_pistol_compact', label = "Possession de Pistolet Compact", jail = 10, fine = 15000 },
            { name = 'pos_pistol_craft', label = "Possession de Pistolet Artisanal", jail = 10, fine = 15000 },
            { name = 'pos_pistol', label = "Possession de Pistolet", jail = 20, fine = 15000 },
            { name = 'pos_pistol_mxp45', label = "Possession de Pistolet MXP45", jail = 20, fine = 15000 },
            { name = 'pos_pistol_50', label = "Possession de Pistolet Calibre 50", jail = 20, fine = 15000 },
            { name = 'pos_pistol_mk2', label = "Possession de Pistolet MKII", jail = 20, fine = 15000 },
            { name = 'pos_pistol_combat', label = "Possession de Pistolet combat", jail = 20, fine = 15000 },
            { name = 'pos_pistol_ceramic', label = "Possession de Pistolet en céramique", jail = 20, fine = 15000 },
            { name = 'pos_pistol_heavy', label = "Possession de Pistolet Lourd", jail = 20, fine = 15000 },
            { name = 'pos_taser', label = "Possession de Pistolet Paralysant (Taser)", jail = 20, fine = 13500 },
            { name = 'pos_pistol_perforating', label = "Possession de Pistolet perforant", jail = 20, fine = 15000 },
            { name = 'pos_pistol_sns', label = "Possession de Pistolet SNS", jail = 20, fine = 11700 },
            { name = 'pos_sns_pico', label = "Possession de SNS Pico", jail = 20, fine = 11700 },
            { name = 'pos_pistol_petoire', label = "Possession de Pétoire Event", jail = 20, fine = 15000 },
            { name = 'pos_revolver_heavy', label = "Possession de Revolver Lourd", jail = 20, fine = 15000 },
            { name = 'pos_revolver_heavy_mk2', label = "Possession de Revolver Lourd MKII", jail = 20, fine = 15000 },
            { name = 'pos_pistol_auto', label = "Possession de Pistolet automatique", jail = 25, fine = 20000 },
            -- Armes de moyenne & grande taille (SMG / Fusils d'assaut / Pompes)
            { name = 'pos_weapon_vesper9', label = "Possession de Vesper 9", jail = 25, fine = 20000 },
            { name = 'pos_weapon_vortex', label = "Possession de Vortex", jail = 25, fine = 20000 },
            { name = 'pos_weapon_tactical_smg', label = "Possession de Tactical SMG", jail = 25, fine = 22500 },
            { name = 'pos_weapon_adp', label = "Possession de ADP de Combat", jail = 25, fine = 25000 },
            { name = 'pos_weapon_smg', label = "Possession de SMG", jail = 25, fine = 25000 },
            { name = 'pos_weapon_smg_mk2', label = "Possession de SMG MKII", jail = 25, fine = 25000 },
            { name = 'pos_weapon_smg_assault', label = "Possession de SMG d'assaut", jail = 25, fine = 25000 },
            { name = 'pos_weapon_mini_smg', label = "Possession de Mini-SMG", jail = 25, fine = 25000 },
            { name = 'pos_weapon_phantom10', label = "Possession de Phtanom 10", jail = 25, fine = 25000 },
            { name = 'pos_weapon_submachine', label = "Possession de Pistolet Mitrailleur", jail = 25, fine = 25000 },
            { name = 'pos_weapon_mx_tactic', label = "Possession de MX Tactic", jail = 25, fine = 25000 },
            { name = 'pos_weapon_gusenberg', label = "Possession de Sulfateuse Gusenberg", jail = 25, fine = 30000 },
            { name = 'pos_weapon_carabine', label = "Possession de Carabine", jail = 25, fine = 35000 },
            { name = 'pos_weapon_carabine_mk2', label = "Possession de Carabine MKII", jail = 25, fine = 30000 },
            { name = 'pos_weapon_tactical_rifle', label = "Possession de Fusil Tactique", jail = 25, fine = 30000 },
            { name = 'pos_weapon_special_carabine', label = "Possession de Carabine Spéciale", jail = 25, fine = 30000 },
            { name = 'pos_weapon_special_carabine_mk2', label = "Possession de Carabine spéciale Mk II", jail = 25, fine = 30000 },
            { name = 'pos_weapon_tar21', label = "Possession de Fusil amélioré (Tar-21)", jail = 25, fine = 35000 },
            { name = 'pos_weapon_compact_rifle', label = "Possession de Fusil compact", jail = 25, fine = 25000 },
            { name = 'pos_weapon_smg45', label = "Possession de SMG-45", jail = 25, fine = 30000 },
            { name = 'pos_weapon_assault_rifle', label = "Possession de Fusil d'assaut", jail = 25, fine = 35000 },
            { name = 'pos_weapon_ar7', label = "Possession de AR7", jail = 25, fine = 35000 },
            { name = 'pos_weapon_mk_priss', label = "Possession de Mk Priss", jail = 25, fine = 35000 },
            { name = 'pos_weapon_battle_rifle', label = "Possession de Battle Rifle", jail = 25, fine = 35000 },
            { name = 'pos_weapon_heavy_rifle', label = "Possession de Fusil Lourd", jail = 25, fine = 35000 },
            { name = 'pos_weapon_sbr52', label = "Possession de Fusil SBR-52", jail = 25, fine = 35000 },
            { name = 'pos_weapon_bullpup_shotgun', label = "Possession de Fusils a Pompe Bullpup", jail = 25, fine = 25000 },
            { name = 'pos_weapon_bullpup_rifle', label = "Possession de Fusil d'assaut Bullpup", jail = 25, fine = 25000 },
            { name = 'pos_weapon_bullpup_rifle_mk2', label = "Possession de Fusil d'assaut Bullpup Mk II", jail = 25, fine = 25000 },
            { name = 'pos_weapon_assault_rifle_mk2', label = "Possession de Fusil d'assaut Mk II", jail = 25, fine = 35000 },
            { name = 'pos_weapon_military_rifle', label = "Possession de Fusil militaire", jail = 25, fine = 30000 },
            { name = 'pos_weapon_musket', label = "Possession de Mousquet", jail = 25, fine = 15000 },
            { name = 'pos_weapon_sawed_off', label = "Possession de Fusil à canon scié (Sawed Off)", jail = 25, fine = 25000 },
            { name = 'pos_weapon_striker12', label = "Possession de Striker 12", jail = 25, fine = 25000 },
            { name = 'pos_weapon_double_barrel', label = "Possession de Fusil à double canon", jail = 25, fine = 25000 },
            { name = 'pos_weapon_shotgun', label = "Possession de Fusil à pompe", jail = 25, fine = 25000 },
            { name = 'pos_weapon_spas12', label = "Possession de Spas 12", jail = 25, fine = 25000 },
            { name = 'pos_weapon_shotgun_mk2', label = "Possession de Fusil à pompe Mk II", jail = 25, fine = 30000 },
            { name = 'pos_weapon_assault_shotgun', label = "Possession de Fusil à pompe d'assaut", jail = 25, fine = 25000 },
            { name = 'pos_weapon_combat_shotgun', label = "Possession de Fusil à pompe de combat", jail = 25, fine = 25000 },
            { name = 'pos_weapon_heavy_shotgun', label = "Possession de Fusil à pompe lourd", jail = 25, fine = 25000 },
            { name = 'pos_weapon_combat_rifle', label = "Possession de Fusil de combat", jail = 25, fine = 35000 },
            { name = 'pos_weapon_advanced_rifle', label = "Possession de Fusil d'élite", jail = 25, fine = 40000 },
            -- Explosifs de lancer / Posés
            { name = 'pos_molotov', label = "Possession de Cocktail molotov", jail = 30, fine = 15000 },
            { name = 'pos_thermite', label = "Possession de charge thermite / Explosive", jail = 30, fine = 15000 },
            { name = 'pos_tear_gas', label = "Possession de Grenade lacrymogène", jail = 30, fine = 15000 },
            { name = 'pos_grenade', label = "POSSESSION DE GRENADE", jail = 30, fine = 135000 },
            { name = 'pos_bomb', label = "POSSESSION DE BOMBE", jail = 30, fine = 135000 },
            -- Munitions
            { name = 'ammo_pistol', label = "Possession de Munition de pistolet", jail = 10, fine = 18 },
            { name = 'ammo_smg', label = "Possession de Munition de SMG", jail = 10, fine = 23 },
            { name = 'ammo_shotgun', label = "Possession de Munition de fusil à pompe", jail = 10, fine = 27 },
            { name = 'ammo_assault', label = "Possession de Munitions fusil d'assaut", jail = 10, fine = 32 },
            { name = 'ammo_mg', label = "Possession de Munitions machine gun", jail = 10, fine = 36 },
            { name = 'ammo_box_pistol', label = "Possession boîte de Munition de pistolet", jail = 10, fine = 180 },
            { name = 'ammo_box_smg', label = "Possession boîte de Munition de SMG", jail = 10, fine = 230 },
            { name = 'ammo_box_shotgun', label = "Possession boîte de Munition de Fusil à pompe", jail = 10, fine = 270 },
            { name = 'ammo_box_assault', label = "Possession boîte de Munition de Fusil d'assaut", jail = 10, fine = 320 },
            { name = 'ammo_box_mg', label = "Possession boîte de Munition de Machine Gun", jail = 10, fine = 360 },
        }
    },
    crimes_against_persons = {
        label = "Crimes & Atteintes aux Personnes",
        options = {
            { name = 'assault_civil', label = "Agression sur citoyen / maltraitance animal", jail = 30, fine = 4500 },
            { name = 'menace_civil', label = "Menace et/ou intimidation envers un civil", jail = 15, fine = 3500 },
            { name = 'endangerment', label = "Mise en danger de la vie d'autrui", jail = 15, fine = 5800 },
            { name = 'non_assistance', label = "Non assistance à personne en danger", jail = 20, fine = 4050 },
            { name = 'hostage_civil', label = "Prise d'otage sur un civil", jail = 15, fine = 4500 },
            { name = 'assault_officer', label = "Agression sur agent (employé d'état ou police)", jail = 60, fine = 8500 },
            { name = 'death_threats', label = "Menaces de Mort et ou Menaces graves", jail = 45, fine = 8500 },
            { name = 'manslaughter', label = "Homicide involontaire", jail = 25, fine = 12500 },
            { name = 'sequestration', label = "SÉQUESTRATION", jail = 30, fine = 15500 },
            { name = 'torture', label = "TORTURE", jail = 30, fine = 25000 },
            { name = 'organ_traffic', label = "TRAFIC D'ORGANE", jail = 45, fine = 18000 },
            { name = 'murder_coma', label = "MEURTRE (COMA)", jail = 30, fine = 10800 },
            -- Mort RP uniques
            { name = 'assassination_rp', label = "Assassinat (Meurtre prémédité) (MORT RP)", jail = 60, fine = 225000 },
            { name = 'murder_rp', label = "Meurtre (MORT RP)", jail = 60, fine = 100800 },
        }
    },
    drugs_contraband = {
        label = "Stupéfiants, Contrebande & Environnement",
        options = {
            { name = 'drug_consumption', label = "Consommation de drogue", jail = 0, fine = 450 },
            { name = 'illegal_fish_pos', label = "Possession poisson illégal (tortue, requin...)", jail = 10, fine = 900 },
            { name = 'poaching', label = "Braconnage - Chasse", jail = 10, fine = 1350 },
            { name = 'go_fast', label = "Go fast", jail = 20, fine = 2250 },
            { name = 'drone_regulated_zone', label = "Utilisation illégale de drone zone réglementée", jail = 20, fine = 12000 },
            { name = 'drone_explosive', label = "Possession de Drone Explosif/Utilisation", jail = 40, fine = 150000 },
            { name = 'protected_fishing', label = "Pêche illégal (Espèce Protégée)", jail = 10, fine = 3600 },
            { name = 'protected_species_meat', label = "Possession d'espèce protégée (viande, poisson)", jail = 10, fine = 18 },
            { name = 'illegal_bait', label = "Possession appât illégal", jail = 10, fine = 45 },
            { name = 'drug_sale', label = "Vente de Drogue ou assimilé", jail = 10, fine = 3750 },
            { name = 'drug_traffic', label = "Trafic de Stupéfiant ou assimilé", jail = 10, fine = 6000 },
            { name = 'illegal_goods_sale', label = "Vente d'objet illégaux", jail = 20, fine = 5500 },
            { name = 'illegal_cash', label = "Possession d'argent liquide obtenu illégalement", jail = 10, fine = 1 },
            -- Matériel de piratage / contrebande
            { name = 'hacking_box', label = "Possession boîtier de piratage", jail = 10, fine = 270 },
            { name = 'darknet_box', label = "Possession de boîtier Darknet", jail = 10, fine = 1000 },
            { name = 'fleeca_card', label = "Possession de carte fleeca / banque", jail = 25, fine = 2700 },
            { name = 'modified_breaker', label = "Possession d'un disjoncteur modifié", jail = 10, fine = 2500 },
            { name = 'prepaid_card', label = "Possession de Carte Prépayée", jail = 10, fine = 45 },
            { name = 'encoder', label = "Possession d'Encodeur", jail = 10, fine = 20 },
            -- Composants / Graines / Chimie / Drogues dures & douces
            { name = 'seed_strawberry', label = "Possession de Graine de strawberry", jail = 10, fine = 30 },
            { name = 'fertilizer', label = "Possession de fertilisant", jail = 10, fine = 1 },
            { name = 'meth_kit', label = "Possession de kit de fabrication de meth", jail = 10, fine = 5000 },
            { name = 'gas_bz', label = "Possession de Gaz BZ", jail = 10, fine = 250 },
            { name = 'gunpowder', label = "Possession de Poudre à canon", jail = 10, fine = 2 },
            { name = 'b_magic', label = "Possession de B-Magic", jail = 10, fine = 45 },
            { name = 'h_47', label = "Possession de H-47", jail = 10, fine = 45 },
            { name = 'cannabis', label = "Possession de Cannabis", jail = 10, fine = 32 },
            { name = 'cocaine', label = "Possession de Cocaïne", jail = 10, fine = 45 },
            { name = 'crack', label = "Possession de Crack", jail = 10, fine = 90 },
            { name = 'ecstasy', label = "Possession d'Ecstasy", jail = 10, fine = 90 },
            { name = 'opium', label = "Possession d'Opium", jail = 10, fine = 90 },
            { name = 'trang', label = "Possession de Trang", jail = 10, fine = 90 },
            { name = 'heroine', label = "Possession d'Héroïne", jail = 10, fine = 72 },
            { name = 'purple_haze', label = "Possession de Purple Haze", jail = 10, fine = 90 },
            { name = 'sulfuric_acid', label = "Possession d'Acide sulfurique", jail = 10, fine = 10 },
            { name = 'salvia_leaves', label = "Possession de Feuilles de salvia", jail = 10, fine = 20 },
            { name = 'cannabis_branch', label = "Possession de Branche de Cannabis", jail = 10, fine = 15 },
            { name = 'methamphetamine', label = "Possession de Méthamphétamine", jail = 10, fine = 72 },
            { name = 'poppy', label = "Possession de Pavot", jail = 10, fine = 45 },
            { name = 'coca_leaves', label = "Possession de Feuilles de coca", jail = 10, fine = 41 },
            { name = 'red_phosphorus', label = "Possession de Phosphore rouge", jail = 10, fine = 10 },
            { name = 'pseudoephedrine', label = "Possession de Pseudoéphédrine", jail = 10, fine = 6 },
            { name = 'anhydrous_ammonia', label = "Possession d'Ammoniaque Anhydre", jail = 10, fine = 45 },
            { name = 'ether', label = "Possession d'Ether", jail = 10, fine = 45 },
            { name = 'lithium', label = "Possession de Lithium", jail = 10, fine = 45 },
            { name = 'blue_meth', label = "Possession de Meth Bleue", jail = 10, fine = 72 },
            { name = 'promethazine', label = "Possession de Prométhazine", jail = 10, fine = 45 },
            { name = 'fentanyl', label = "Possession de Fentanyl", jail = 10, fine = 10 },
            { name = 'xylazine', label = "Possession de Xylazine", jail = 10, fine = 10 },
            { name = 'belladonna', label = "Possession de Belladone", jail = 10, fine = 6 },
            { name = 'morphine', label = "Possession de Morphine", jail = 10, fine = 41 },
            { name = 'datura', label = "Possession de Datura", jail = 10, fine = 45 },
            { name = 'salvia', label = "Possession de Salvia", jail = 10, fine = 25 },
            { name = 'mexicana', label = "Possession de Mexicana", jail = 10, fine = 90 },
            { name = 'blacktrip', label = "Possession de Blacktrip", jail = 10, fine = 45 },
            { name = 'spore_x', label = "Possession de Spore X", jail = 10, fine = 45 },
            { name = 'oyster_red', label = "Possession de Oyster Rouge", jail = 10, fine = 20 },
            { name = 'oyster_blue', label = "Possession de Oyster Bleu", jail = 10, fine = 20 },
            { name = 'amanita_red', label = "Possession de Amanita Rouge", jail = 10, fine = 20 },
            { name = 'amanita_green', label = "Possession de Amanita Vert", jail = 10, fine = 20 },
            { name = 'psilocybe_green', label = "Possession de Psilocybe Vert", jail = 10, fine = 20 },
            { name = 'spectral_mold', label = "Possession de Moisissures Spectrales", jail = 10, fine = 20 },
            { name = 'veloceps_spores', label = "Possession de Spores De Véloceps", jail = 10, fine = 20 },
            { name = 'psilocybe_red', label = "Possession de Psilocybe Rouge", jail = 10, fine = 20 },
            { name = 'psilocybe_purple', label = "Possession de Psilocybe Violet", jail = 10, fine = 20 },
            { name = 'red_fang', label = "Possession de Red Fang", jail = 10, fine = 90 },
            { name = 'lean', label = "Possession de Lean", jail = 10, fine = 90 },
            { name = 'acetylsalicylic_acid', label = "Possession de Acide Acétylsalicylique", jail = 10, fine = 20 },
            { name = 'ma_huang', label = "Possession de Ma-Huang", jail = 10, fine = 20 },
            { name = 'ladanum', label = "Possession de Ladanum", jail = 10, fine = 90 },
        }
    },
    state_and_justice = {
        label = "Atteintes à l'État & Justice",
        options = {
            { name = 'contempt_officer', label = "Outrage de base envers représentant de l'état/magistrat", jail = 10, fine = 2500 },
            { name = 'public_service_abuse', label = "Appel abusif service publics", jail = 15, fine = 1800 },
            { name = 'investigation_hindrance', label = "Entrave à une opération/enquête (police/justice)", jail = 30, fine = 3500 },
            { name = 'non_denunciation', label = "Non dénonciation d'un acte illégal", jail = 15, fine = 2700 },
            { name = 'police_convocation_miss', label = "Non présentation à une convocation de police", jail = 20, fine = 6750 },
            { name = 'geo_assignation_violation', label = "Non respect de l'assignation géographique", jail = 10, fine = 18000 },
            { name = 'judicial_control_violation', label = "Non respect du contrôle judiciaire", jail = 10, fine = 2700 },
            { name = 'refusal_appear', label = "Refus de comparaître", jail = 30, fine = 1800 },
            { name = 'refusal_injunction', label = "Refus de se soumettre à une injonction", jail = 60, fine = 10800 },
            { name = 'police_station_escape', label = "Évasion du poste de police", jail = 20, fine = 7500 },
            { name = 'judicial_decision_civil_violation', label = "Non respect d'une décision de justice (citoyen)", jail = 30, fine = 9000 },
            { name = 'judicial_decision_company_violation', label = "Non respect d'une décision de justice (entreprise)", jail = 30, fine = 18000 },
            { name = 'magistrate_intimidation', label = "Intimidation/Chantage envers Magistrat", jail = 30, fine = 7500 },
            { name = 'state_rep_intimidation', label = "Menace / intimidation envers un représentant de l'état", jail = 20, fine = 3500 },
            { name = 'false_testimony', label = "Faux témoignage", jail = 30, fine = 9000 },
            { name = 'perjury', label = "Parjure", jail = 30, fine = 5500 },
            { name = 'evidence_tampering', label = "Destruction/Dissimulation de preuve", jail = 30, fine = 5500 },
            { name = 'abuse_of_office', label = "Abus de fonction", jail = 30, fine = 7200 },
            { name = 'impersonation', label = "Usurpation (identité et/ou fonction)", jail = 30, fine = 4600 },
            { name = 'confidential_info_leak', label = "Divulgation d'informations confidentielles", jail = 30, fine = 2000 },
            { name = 'corruption', label = "Corruption", jail = 15, fine = 8000 },
            { name = 'abuse_of_power', label = "Abus de Pouvoir", jail = 15, fine = 7500 },
            { name = 'fake_documents_admin', label = "Procurer frauduleusement document administration publique", jail = 30, fine = 13500 },
            { name = 'runaway', label = "Cavale", jail = 60, fine = 9000 },
            { name = 'escape_prison_or_convoy', label = "EVASION/ORGANISATION D'EVASION (PRISON / CONVOI)", jail = 30, fine = 13500 },
            { name = 'hostage_officer', label = "Prise d'otage sur représentant de l'état", jail = 30, fine = 18000 },
            { name = 'state_decree_violation', label = "Violation d'un ordre/décret gouvernemental", jail = 60, fine = 40500 },
            { name = 'professional_secrecy_violation', label = "Violation du secret professionnel", jail = 30, fine = 22500 },
            -- Atteintes graves à l'État (Haute trahison / Terrorisme / Mort RP)
            { name = 'state_security_attack', label = "Atteinte à la sécurité intérieure", jail = 30, fine = 12500 },
            { name = 'terrorism_act', label = "Acte lié au terrorisme", jail = 60, fine = 15000 },
            { name = 'terrorism', label = "TERRORISME", jail = 60, fine = 45000 },
            { name = 'treason', label = "TRAHISON", jail = 60, fine = 225000 },
            { name = 'state_crime_assistance', label = "Participation/assistance acte contre l'État", jail = 30, fine = 35500 },
            { name = 'nation_fundamental_attack', label = "ATTEINTES AUX INTÉRÊTS FONDAMENTAUX DE LA NATION", jail = 60, fine = 30600 },
            { name = 'nation_institution_attack', label = "ATTEINTES AUX INSTITUTION DE LA NATION", jail = 60, fine = 18000 },
            { name = 'murder_officer_coma', label = "MEURTRE SUR REPRÉSENTANT DE L'ÉTAT (COMA)", jail = 30, fine = 30000 },
            { name = 'murder_officer_rp', label = "MEURTRE SUR REPRÉSENTANT DE L'ÉTAT (MORT RP)", jail = 30, fine = 250000 },
            { name = 'assassination_officer_rp', label = "Assassinat sur représentant de l'état (MORT RP)", jail = 60, fine = 300000 },
        }
    },
    business_and_fraud = {
        label = "Économie, Entreprises & Fraudes",
        options = {
            { name = 'labor_code_violation', label = "Non respect du code du travail", jail = 10, fine = 7200 },
            { name = 'commerce_code_violation', label = "Non respect du code de commerce", jail = 10, fine = 7200 },
            { name = 'sell_at_loss', label = "Revente à perte", jail = 10, fine = 5000 },
            { name = 'breach_of_trust', label = "Abus de confiance", jail = 20, fine = 12500 },
            { name = 'plagiarism', label = "Plagiat", jail = 30, fine = 17500 },
            { name = 'counterfeiting', label = "Contrefaçon", jail = 25, fine = 15000 },
            { name = 'illegal_transaction_doa', label = "Participation à une transaction illégale (DOA)", jail = 15, fine = 8000 },
            { name = 'corporate_fraud', label = "Escroquerie à l'entreprise", jail = 30, fine = 9000 },
            { name = 'extortion_fraud', label = "Extorsion/Escroquerie", jail = 30, fine = 8500 },
            { name = 'fire_safety_violation', label = "Non respect des normes incendie (entreprise)", jail = 0, fine = 18000 },
            { name = 'insolvency_organization', label = "Organisation d'insolvabilité", jail = 0, fine = 13500 },
            { name = 'scam_report_unregistered', label = "Rapport de vol non enregistré", jail = 10, fine = 9000 },
            { name = 'harboring_criminals', label = "Recel de malfaiteurs", jail = 30, fine = 1800 },
            { name = 'false_declaration_profit', label = "Témoignage/fausse déclaration pour profit", jail = 30, fine = 8500 },
            { name = 'bleeter_illegal_act', label = "Acte / Trafic illégale sur Bleeter", jail = 30, fine = 18000 },
            { name = 'forgery_use', label = "Usage de Faux", jail = 30, fine = 2700 },
            { name = 'undeclared_activity', label = "Travail dissimulé par dissimulation d'activité", jail = 60, fine = 58500 },
            { name = 'undeclared_employment', label = "Travail dissimulé par dissimulation d'emploie salarié", jail = 60, fine = 45000 },
            { name = 'undeclared_work', label = "Travail dissimulé", jail = 60, fine = 45000 },
            { name = 'missing_legal_docs_company', label = "Absence de documents légaux d'une entreprise", jail = 60, fine = 63000 },
            { name = 'tax_evasion', label = "Fraude Fiscale", jail = 30, fine = 90000 },
            { name = 'arson', label = "Incendie criminel", jail = 30, fine = 20500 },
            { name = 'abusive_real_estate_sale', label = "Vente de biens Immobilier abusif", jail = 30, fine = 1 },
            { name = 'unauthorized_company_operation', label = "Exploitation d'une entreprise sans autorisation", jail = 30, fine = 100000 },
            { name = 'missing_operation_authorization', label = "Absence d'autorisation d'exploitation", jail = 30, fine = 250000 },
            { name = 'money_laundering', label = "Blanchiment", jail = 15, fine = 5 },
            { name = 'illegal_medicine_practice', label = "Pratique illégale de la médecine", jail = 30, fine = 9000 },
            { name = 'criminal_association', label = "Association de malfaiteurs", jail = 30, fine = 4500 },
            { name = 'embezzlement', label = "Détournement de fonds", jail = 30, fine = 18000 },
            { name = 'espionage', label = "Espionnage", jail = 30, fine = 7000 },
            { name = 'organized_gang', label = "Bande organisée", jail = 30, fine = 2500 },
            { name = 'illegal_licences_handling', label = "Non respect des licences et des papiers officiels", jail = 15, fine = 10000 },
            { name = 'blackmail', label = "Chantage", jail = 15, fine = 3150 },
        }
    },
}
    },

    -- ========================================================
    -- LSSD — Los Santos Sheriff Department
    -- Unlock by adding 'sheriff' to Config.EnablePoliceJobs
    -- ========================================================
    ['sheriff'] = {
        DisplayName         = 'Los Santos Sheriff Department',
        ShortName           = 'LSSD',
        -- place file in web/dist/
        LogoFile            = 'images/sheriff.webp',
        Theme               = 'lssd',
        Colors              = {
            primary = 'FFFFAE00',
            primaryDark = 'FFFCC26B',
            bg = 'rgba(163, 230, 53, 0.1)'
        },

        TabletCommand       = 'lssdmdt',
        OpenKey             = 'F6',

        CamPrefix           = 'LSSD',
        PlatePrefix         = 'LSSD',

        -- GPS Blip Color
        -- Cyan/Light Blue
        BlipColor           = 15,

        Codes               = {
            { id = 'green',  label = 'CODE GREEN',  color = '#22c55e', description = 'Normal patrol.' },
            { id = 'yellow', label = 'CODE YELLOW', color = '#eab308', description = 'Elevated vigilance.' },
            { id = 'red',    label = 'CODE RED',    color = '#ef4444', description = 'Active threat.' },
        },

        Documents           = {
            { title = 'LSSD Regulations', url = 'https://docs.google.com/document/d/example-lssd' },
        },

        -- LSSD Permissions (can be different from LSPD)
        Grades              = {
            ['0'] = { label = 'Deputy I', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = false, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = false, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = false, admin = false, code_change = false, custom_fine = false, custom_sentence = false, weapons_view = true, units_view = true, units_manage = false } },
            ['1'] = { label = 'Deputy II', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = true, admin = false, code_change = false, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = false } },
            ['2'] = { label = 'Corporal', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = true, admin = false, code_change = false, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = false } },
            ['3'] = { label = 'Sergeant', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = true, admin = false, code_change = true, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = true } },
            ['4'] = { label = 'Lieutenant', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, dispatch_view = true, cameras_view = true, admin = false, code_change = true, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = true } },
            ['5'] = { label = 'Captain', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, dispatch_view = true, cameras_view = true, admin = true, code_change = true, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = true } },
            ['6'] = { label = 'Undersheriff', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, dispatch_view = true, cameras_view = true, admin = true, code_change = true, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = true } },
            ['7'] = { label = 'Sheriff', permissions = { dashboard_view = true, profiles_view = true, profiles_create = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, dispatch_view = true, cameras_view = true, admin = true, code_change = true, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = true } },
        },

        Vehicles            = {
            { model = 'ssstanier',  label = 'Sheriff Stanier',    price = 45000, category = 'patrol' },
            { model = 'ssgranger',  label = 'Sheriff Granger',    price = 65000, category = 'suv' },
            { model = 'ssmaverick', label = 'Sheriff Helicopter', price = 0,     category = 'air' },
        },

        VehicleCategories   = {
            ['patrol'] = 'Patrol',
            ['suv']    = 'SUV / Offroad',
            ['air']    = 'Aircraft',
        },

        CustomVehicleImages = {},

        PenalCode           = {
            traffic = {
                label = 'Traffic Violations',
                options = {
                    { name = 'speed',        label = 'Speeding', jail = 0,  fine = 800 },
                    { name = 'drunkDriving', label = 'DUI',      jail = 15, fine = 4500 },
                }
            },
        },
    },

    -- ========================================================
    -- BCSO — Blaine County Sheriff's Office
    -- ========================================================
    ['bcso'] = {
        DisplayName         = "Blaine County Sheriff's Office",
        ShortName           = 'BCSO',
        -- place file in web/dist/
        LogoFile            = 'images/bcso.webp',
        Theme               = 'bcso',
        Colors              = {
            primary = 'FFFFFB00',
            primaryDark = 'FFF1F36C',
            bg = 'rgba(217, 119, 6, 0.1)'
        },

        TabletCommand       = 'bcsomdt',
        OpenKey             = 'F7',

        CamPrefix           = 'BCSO',
        PlatePrefix         = 'BCSO',

        -- GPS Blip Color
        -- Yellow/Orange
        BlipColor           = 5,

        Codes               = {
            { id = 'green',  label = 'CODE GREEN',  color = '#22c55e', description = 'Normal patrol.' },
            { id = 'yellow', label = 'CODE YELLOW', color = '#eab308', description = 'Elevated vigilance.' },
            { id = 'red',    label = 'CODE RED',    color = '#ef4444', description = 'Active threat.' },
        },

        Documents           = {
            { title = 'BCSO Regulations', url = 'https://docs.google.com/document/d/example-bcso' },
        },

        Grades              = {
            ['0'] = { label = 'Deputy', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = false, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = false, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = false, admin = false, code_change = false, custom_fine = false, custom_sentence = false, weapons_view = true, units_view = true, units_manage = false } },
            ['1'] = { label = 'Corporal', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = true, admin = false, code_change = false, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = false } },
            ['2'] = { label = 'Sergeant', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, dispatch_view = true, cameras_view = true, admin = false, code_change = true, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = true } },
            ['3'] = { label = 'Lieutenant', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, dispatch_view = true, cameras_view = true, admin = false, code_change = true, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = true } },
            ['4'] = { label = 'Sheriff', permissions = { dashboard_view = true, profiles_view = true, profiles_create = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, dispatch_view = true, cameras_view = true, admin = true, code_change = true, custom_fine = true, custom_sentence = true, weapons_view = true, units_view = true, units_manage = true } },
        },

        Vehicles            = {
            { model = 'bcsostanier', label = 'BCSO Stanier', price = 45000, category = 'patrol' },
            { model = 'bcsogranger', label = 'BCSO Granger', price = 65000, category = 'suv' },
        },

        VehicleCategories   = {
            ['patrol'] = 'Patrol',
            ['suv']    = 'SUV / Offroad',
        },

        CustomVehicleImages = {},

        PenalCode           = {
            traffic = {
                label = 'Traffic Violations',
                options = {
                    { name = 'speed', label = 'Speeding', jail = 0, fine = 700 },
                }
            },
        },
    },

    -- Add other police factions here following the same pattern...
}

-- ============================================================
-- Which jobs are active (will register commands/tablets)
-- Remove faction from this list to disable its tablet
-- ============================================================
Config.EnablePoliceJobs = {
    -- LSPD
    'fbi',
    -- PD Alias
    --'pd',
    -- LSSD (unlock if needed)
    -- 'sheriff',
    -- BCSO (unlock if needed)
    -- 'bcso',
}

-- ============================================================
-- Universal main definition of Config.Police
-- Replaces old references to Config.Police, allowing
-- uniform references across all system files.
-- ============================================================
Config.Police           = Config.PoliceJobs['fbi']
Config.Police.JobName   = 'fbi'
Config.EnablePolice     = true

-- Map 'pd' to 'police' config
Config.PoliceJobs['fbi'] = Config.PoliceJobs['fbi']
