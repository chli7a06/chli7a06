Config = Config or {}
print('^3[XR-MDT DEBUG]^7 config.armory.lua LOADING...')


-- ============================================================
-- XR-MDT: ARMORY (ARMORY) — Configuration
-- ============================================================
-- Each job has its own section in Config.Armory.Jobs
-- Mode: 'unlimited' = infinite items (default)
--       'limited'   = stock state in database (mdt_armory_stock)
--
-- Key = job name in framework (must be in Config.EnablePoliceJobs)
-- ============================================================

Config.Armory = {

    -- Must player be on duty (onduty) to use the armory?
    RequireDuty = true,

    -- Max distance from target (anti-exploit) checked server-side [meters]
    MaxDistance = 6.0,

    -- Max number of kits a player can save per job
    MaxKitsPerJob = 10,

    -- ============================================================
    -- IMAGE SOURCE CONFIGURATION
    -- ============================================================
    -- Define where item images should be loaded from in the NUI.
    -- Type: 'ox' | 'qb' | 'custom'
    -- CustomPath: Used only if Type is 'custom'. Use %s for item name.
    -- Example custom path: 'https://myserver.com/images/%s.png'
    ImageSource = {
        Type = 'ox',
        CustomPath = 'nui://ox_inventory/web/images/%s.png' 
    },

    -- ============================================================
    -- PER-JOB CONFIGURATION
    -- ============================================================
    Jobs = {

        -- =============================================
        -- LSPD — Los Santos Police Department
        -- =============================================
        ['fbi'] = {

            -- Armory mode: 'unlimited' | 'limited'
            Mode        = 'unlimited',

            -- ox_inventory stash ID for this armory
            -- (used for both 'Return equipment' and limited mode)
            StashId     = 'armory_police',
            StashSlots  = 150,
            StashWeight = 1000000,

            -- Target point in game world
            Target      = {
                Coords   = vector3(-447.64785766602, -1019.2450561523, 24.975135803223),
                Size     = vector3(1.5, 1.5, 2.0),
                Rotation = 358.0,
                -- enabled for testing
                Debug    = false,
            },

            -- Categories visible in NUI menu (order = tab order)
            Categories  = {
                { id = 'weapons', label = 'Firearms',   icon = 'fa-solid fa-gun' },
                { id = 'ammo',    label = 'Ammunition', icon = 'fa-solid fa-box' },
                { id = 'gear',    label = 'Gear',       icon = 'fa-solid fa-shield-halved' },
                { id = 'medical', label = 'Medical',    icon = 'fa-solid fa-kit-medical' },
            },

            -- List of items available in armory
            -- minGrade: minimum player rank (grade.level) to unlock
            -- amount: default amount taken to cart
            -- image: (optional) URL to a custom image for this item only. Overrides global ImageSource.
            Items       = {
                -- ── Weapons ────────────────────────────────────────────────────
                { category = 'weapons', item = 'weapon_ceramicpistol',   label = 'Ceramic Pistol',         amount = 1,  minGrade = 10 },
                { category = 'weapons', item = 'weapon_sb4s',       label = 'SB4S',            amount = 1,  minGrade = 10 },

                -- ── Ammunition ────────────────────────────────────────────────
                { category = 'ammo',    item = 'ammo-pistol',                label = 'Ammunition 9mm (50)',   amount = 50, minGrade = 10 },
                { category = 'ammo',    item = 'ammo-smg',              label = 'SMG Ammunition',     amount = 10, minGrade = 10 },

                -- ── Gear ─────────────────────────────────────────────
                { category = 'gear',    item = 'armor',                 label = 'Bulletproof Vest',      amount = 1,  minGrade = 0 },
                { category = 'gear',    item = 'handcuffs',             label = 'Handcuffs',             amount = 1,  minGrade = 0 },
                { category = 'gear',    item = 'police_radio',          label = 'Police Radio',          amount = 1,  minGrade = 0 },
                { category = 'gear',    item = 'flashlight',            label = 'Flashlight',            amount = 1,  minGrade = 0 },

                -- ── Medical ────────────────────────────────────────────────
                { category = 'medical', item = 'bandage',               label = 'Bandage (3)',           amount = 3,  minGrade = 10 },
                { category = 'medical', item = 'adrenaline',            label = 'Adrenaline',            amount = 1,  minGrade = 10 },
            },
        },

        -- =============================================
        -- SHERIFF — Los Santos Sheriff Department
        -- =============================================
        ['sheriff'] = {
            -- State saved in DB
            Mode        = 'limited',
            StashId     = 'armory_sheriff',
            StashSlots  = 100,
            StashWeight = 800000,

            Target      = {
                Coords   = vector3(1853.6, 3687.0, 34.27),
                Size     = vector3(0.5, 1.0, 2.0),
                Rotation = 0.0,
                Debug    = false,
            },

            Categories  = {
                { id = 'weapons', label = 'Weapons',    icon = 'fa-solid fa-gun' },
                { id = 'ammo',    label = 'Ammunition', icon = 'fa-solid fa-box' },
                { id = 'gear',    label = 'Gear',       icon = 'fa-solid fa-shield-halved' },
            },

            Items       = {
                { category = 'weapons', item = 'weapon_combatpistol', label = 'Combat Pistol',        amount = 1,  minGrade = 0 },
                { category = 'weapons', item = 'weapon_pumpshotgun',  label = 'Shotgun',              amount = 1,  minGrade = 3 },
                { category = 'weapons', item = 'weapon_carbinerifle', label = 'Combat Rifle',         amount = 1,  minGrade = 5 },
                { category = 'ammo',    item = 'ammo-9',              label = 'Ammunition 9mm (50)',  amount = 50, minGrade = 0 },
                { category = 'ammo',    item = 'ammo-rifle',          label = 'Ammunition 5.56 (30)', amount = 30, minGrade = 3 },
                { category = 'gear',    item = 'armor',               label = 'Bulletproof Vest',     amount = 1,  minGrade = 0 },
                { category = 'gear',    item = 'handcuffs',           label = 'Handcuffs',            amount = 1,  minGrade = 0 },
                { category = 'gear',    item = 'police_radio',        label = 'Radio',                amount = 1,  minGrade = 0 },
            },
        },

        -- =============================================
        -- BCSO — Blaine County Sheriff's Office
        -- Unlock by adding 'bcso' to Config.EnablePoliceJobs
        -- =============================================
        ['bcso'] = {
            Mode        = 'unlimited',
            StashId     = 'armory_bcso',
            StashSlots  = 100,
            StashWeight = 800000,

            Target      = {
                -- adjust to your server
                Coords   = vector3(1857.8, 3682.1, 34.27),
                Size     = vector3(0.5, 1.0, 2.0),
                Rotation = 0.0,
                Debug    = false,
            },

            Categories  = {
                { id = 'weapons', label = 'Weapons',    icon = 'fa-solid fa-gun' },
                { id = 'ammo',    label = 'Ammunition', icon = 'fa-solid fa-box' },
                { id = 'gear',    label = 'Gear',       icon = 'fa-solid fa-shield-halved' },
            },

            Items       = {
                { category = 'weapons', item = 'weapon_combatpistol', label = 'Combat Pistol',       amount = 1,  minGrade = 0 },
                { category = 'weapons', item = 'weapon_pumpshotgun',  label = 'Shotgun',             amount = 1,  minGrade = 2 },
                { category = 'ammo',    item = 'ammo-9',              label = 'Ammunition 9mm (50)', amount = 50, minGrade = 0 },
                { category = 'gear',    item = 'armor',               label = 'Vest',                amount = 1,  minGrade = 0 },
                { category = 'gear',    item = 'handcuffs',           label = 'Handcuffs',           amount = 1,  minGrade = 0 },
            },
        },

        -- ============================================================
        -- Add other jobs here following the pattern above.
        -- Example:
        -- ['pd'] = Config.Armory.Jobs['police']
        -- ============================================================
    }
}

-- ============================================================
-- XR-MDT: Armory Module — Database Schema
-- Run this SQL on your database server before using the armory.
-- Compatible with: QBCore, QBox, ESX
-- ============================================================
--[[
CREATE TABLE IF NOT EXISTS `mdt_armory_kits` (
    `id`          INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `identifier`  VARCHAR(60)      NOT NULL COMMENT 'citizenid (QB/QBox) or identifier (ESX)',
    `job`         VARCHAR(50)      NOT NULL COMMENT 'Job name, e.g. police, sheriff',
    `kit_name`    VARCHAR(100)     NOT NULL COMMENT 'Player-defined kit name',
    `items`       LONGTEXT         NOT NULL COMMENT 'JSON array: [{item, amount, label}]',
    `created_at`  TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_identifier_job` (`identifier`(50), `job`(30))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `mdt_armory_stock` (
    `id`          INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `job`         VARCHAR(50)      NOT NULL COMMENT 'Job owning this stock entry',
    `item`        VARCHAR(100)     NOT NULL COMMENT 'Item name/hash',
    `amount`      INT UNSIGNED     NOT NULL DEFAULT 0 COMMENT 'Current available quantity',
    `updated_at`  TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_job_item` (`job`(30), `item`(60))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
]]
