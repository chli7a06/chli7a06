Config = Config or {}

Config.DOJ = Config.DOJ or {}

Config.DOJ.JobName = 'doj'
Config.DOJ.TabletCommand = 'doj'
Config.DOJ.OpenKey = 'K'

-- Status codes (Same as LSPD, or custom)
Config.DOJ.Codes = (Config.Police and Config.Police.Codes) or {
    { id = 'green',  label = 'CODE GREEN',      color = '#22c55e', description = 'Stable.' },
    { id = 'yellow', label = 'CODE ORANGE', color = '#f97316', description = 'Risk.' },
    { id = 'red',    label = 'CODE RED',     color = '#ef4444', description = 'Alarm!' },
}

-- Documents / Procedures
Config.DOJ.Documents = {
   { title = 'State Constitution',  url = 'https://docs.google.com/document/d/1exampleid/preview' },
    { title = 'Penal Code (Full)', url = 'https://docs.google.com/document/d/2exampleid/preview' },
    { title = 'Application Templates',       url = 'https://docs.google.com/document/d/3exampleid/preview' }
}

-- Permissions
Config.DOJ.Grades = {
    ['0'] = { label = 'DOJ Student', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = false, reports_view = true, reports_create = false, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = false, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['1'] = { label = 'Public Lawyer', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = false, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = false, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['2'] = { label = 'Public Defender', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = false, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['3'] = { label = 'Assitant Attorney', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = false, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['4'] = { label = 'FBI Academy Trainee', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['5'] = { label = 'Junior Special Agent', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['6'] = { label = 'Special Agent', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, business_view = true, business_manage = false, code_change = false } },
    ['7'] = { label = 'Senior Officer', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['8'] = { label = 'Assistant Special Agent in Charge', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['9'] = { label = 'Special Agent in Charge', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, business_view = true, business_manage = false, code_change = false } },
    ['10'] = { label = 'Deputy Director', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['11'] = { label = 'District Attorney', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['12'] = { label = 'General Attorney', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['13'] = { label = 'Director of the FBI', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, business_view = true, business_manage = true, code_change = true } },
    ['14'] = { label = 'Judge', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, business_view = true, business_manage = true, code_change = true } },
}

-- Businesses visible in DOJ tablet
Config.DOJ.BusinessList = {
    { job = 'burgershot', label = 'Burger Shot' },
    { job = 'police',     label = 'Los Santos Police Department' },
    { job = 'ambulance',  label = 'Emergency Medical Services' },
    { job = 'white_widow', label = 'White Widdow' },
    { job = 'atomburger', label = 'Atom Burger' },
    { job = 'pharmacy', label = 'Crimson Pharmacy' },
    { job = 'bahama', label = 'Bahama Mamas Cabaret' },
    { job = 'minibrahim', label = 'Mini Brahim Market' },
    { job = 'taco', label = 'Taco Abass' },
    { job = 'catcafe', label = 'Cat Coffee' },
    { job = 'mm3_mecano', label = 'Turbo Cars' },
    { job = 'apexauto', label = 'Apex/Vice Car Dealership' },
    { job = 'skydome', label = 'Skydome Mount-Chilliad' },
    { job = 'casino', label = 'Crimson Casino' },
    { job = 'hotdogs', label = 'Hot Dog Stand' },
    { job = 'Daddy_Tobacco', label = 'Daddy Tobacco Factory' },

}

-- Tariff (Shared with LSPD for legal consistency)
Config.DOJ.PenalCode = (Config.Police and Config.Police.PenalCode) or {}
