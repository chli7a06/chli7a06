Config = Config or {}

-- Discord Webhooks and Category colors configuration.
-- Debug log output behavior is controlled by Config.Debug in config.main.lua
Config.Webhooks = {
    -- Primary global fallback webhook if others are not set
    Main = "",

    -- Global fallback webhooks for faction logs and administrative logs
    AdminMain = "",
    FactionMain = "",

    -- Faction-specific webhooks.
    -- Set separate links for administrative events (hiring, firing, ranks)
    -- and operational/faction events (fines, reports, armory).
    Jobs = {
        LSPD = {
            Faction = "",
            Admin = "",
        },
        EMS = {
            Faction = "",
            Admin = "",
        },
        DOJ = {
            Faction = "",
            Admin = "",
        },
        Business = {
            Faction = "",
            Admin = "",
        },
    },

    -- Webhooks for specific action types (overrides Jobs faction webhooks if set)
    Types = {
        Database = "",
        Money = "",
        Items = "",
        JobChange = "",
        Duty = "",
        Commands = "",
    },

    Routing = {
        -- Fallback routing for any log type not explicitly specified below
        ["Default"] = "faction",

        -- Administrative events (personnel, access, code changes, deletions)
        ["Hired"] = "both",
        ["Fired"] = "both",
        ["Promotion/Demotion"] = "both",
        ["Badge Changed"] = "both",
        ["Suspension"] = "both",
        ["License Issued"] = "both",
        ["Code Changed"] = "both",
        ["Report: Deleted"] = "both",
        ["Armory: Delete Kit"] = "both",
        ["Employee Note Created"] = "both",
        ["Employee Note Deleted"] = "both",

        -- Faction operational events
        ["Armory: Return"] = "faction",
        ["Armory: Collect"] = "faction",
        ["Armory: Save Kit"] = "faction",
        ["Armory: Collect Kit"] = "faction",
        ["Armory: Weapon Taken"] = "faction",
        ["Invoice Issued"] = "faction",
        ["Invoice Paid"] = "faction",
        ["Document: Created"] = "faction",
        ["Document: Updated"] = "faction",
        ["Document: Printed"] = "faction",
        ["Document: Received"] = "faction",
        ["Document: Signed"] = "faction",
        ["Document: Profile Printed"] = "faction",
        ["Duty: Started (CODE 1)"] = "faction",
        ["Duty: Break (CODE 2)"] = "faction",
        ["Duty: Ended (CODE 3)"] = "faction",
        ["Duty: Started"] = "faction",
        ["Duty: Break"] = "faction",
        ["Duty: Ended"] = "faction",
        ["Case Created"] = "faction",
        ["Medical Record Added"] = "faction",
        ["Patient Note Added"] = "faction",
        ["Citizen Lookup"] = "faction",
        ["Citizen Note Added"] = "faction",
        ["Warrant Issued"] = "faction",
        ["Jail Sentence"] = "faction",
        ["Fine Issued"] = "faction",
        ["Incident Report Created"] = "faction",
        ["Report: Created"] = "faction",
        ["Report: Updated"] = "faction",
    },

    -- Appearance & Colors for Discord Embeds
    Categories = {
        -- Blue
        LSPD = { Color = 2123412, Title = "🚓 LSPD LOGS" },
        -- Red
        EMS = { Color = 15158332, Title = "🚑 EMS LOGS" },
        -- Gold
        DOJ = { Color = 15844367, Title = "⚖️ DOJ LOGS" },
        -- Green
        Business = { Color = 3066993, Title = "💼 BUSINESS LOGS" },
        -- Grey
        System = { Color = 8359053, Title = "⚙️ SYSTEM LOGS" },
    }
}
