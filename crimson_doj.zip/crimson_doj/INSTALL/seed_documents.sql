-- ============================================================
-- XR-MDT: Tabele dokumentów i archiwum
-- Dołącz do: database_qb.sql / database_qbox.sql / database_esx.sql
-- ============================================================

-- Szablony dokumentów (baza wzorów do wydruku)
CREATE TABLE IF NOT EXISTS `mdt_templates` (
  `id`           INT(11)       NOT NULL AUTO_INCREMENT,
  `faction`      VARCHAR(50)   NOT NULL,
  `title`        VARCHAR(255)  NOT NULL,
  `html_content` LONGTEXT      NOT NULL,
  `created_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_faction` (`faction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Robocze dokumenty (wersje robocze, szablony w tablecie)
CREATE TABLE IF NOT EXISTS `mdt_documents` (
  `id`           VARCHAR(60)   NOT NULL,
  `faction`      VARCHAR(50)   NOT NULL,
  `title`        VARCHAR(255)  NOT NULL,
  `html_content` LONGTEXT      NOT NULL,
  `image_url`    VARCHAR(512)  DEFAULT NULL,
  `author_id`    VARCHAR(60)   DEFAULT NULL,
  `author_name`  VARCHAR(120)  DEFAULT NULL,
  `created_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_faction` (`faction`),
  INDEX `idx_author`  (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Archiwum — wydrukowane instancje z unikatowym numerem seryjnym
-- UWAGA: doc_number jako osobna kolumna AUTO_INCREMENT wymaga w MySQL
-- by była UNIQUE KEY (działa z InnoDB gdy PRIMARY KEY to inna kolumna)
CREATE TABLE IF NOT EXISTS `mdt_document_archive` (
  `id`           VARCHAR(60)   NOT NULL,
  `doc_number`   INT(11)       NOT NULL AUTO_INCREMENT,
  `faction`      VARCHAR(50)   NOT NULL,
  `title`        VARCHAR(255)  NOT NULL,
  `html_content` LONGTEXT      NOT NULL,
  `image_url`    VARCHAR(512)  DEFAULT NULL,
  `author_id`    VARCHAR(60)   DEFAULT NULL,
  `author_name`  VARCHAR(120)  DEFAULT NULL,
  `is_in_archive` TINYINT(1)  NOT NULL DEFAULT 0
                    COMMENT '0 = u gracza w ekwipunku, 1 = w kartotece',
  `created_at`   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_doc_number` (`doc_number`),
  INDEX `idx_faction`    (`faction`),
  INDEX `idx_author`     (`author_id`),
  INDEX `idx_in_archive` (`is_in_archive`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- DANE STARTOWE — 3 szablony LSPD
-- INSERT IGNORE pomija duplikaty przy kolejnych instalacjach
-- ============================================================

SET @sig_style = 'display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-end;width:220px;min-height:70px;padding:8px 12px 6px;margin:8px 4px;border:none;border-bottom:2px solid #1e293b;cursor:pointer;vertical-align:middle;position:relative;background:transparent;';

INSERT IGNORE INTO `mdt_templates` (`faction`, `title`, `html_content`) VALUES

('police', 'Protokół Zatrzymania',
'{"pages":[{"header":"LSPD — Mission Row Police Department","watermark":"LSPD","footer":"Dokument poufny — tylko do użytku służbowego","html":"<p><strong style=\"font-size:16px;\">PROTOKÓŁ ZATRZYMANIA</strong></p><hr/><p>Data zatrzymania: _______________</p><p>Imię i nazwisko zatrzymanego: _______________</p><p>Podstawa prawna: _______________</p><p>Miejsce zatrzymania: _______________</p><p>Opis zdarzenia:</p><p style=\"min-height:80px;\">_______________</p><br/><div class=\"signature-slot\" data-id=\"sig_officer\" data-label=\"Oficer prowadzący\" style=\"display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-end;width:220px;min-height:70px;padding:8px 12px 6px;margin:8px 4px;border:none;border-bottom:2px solid #1e293b;cursor:pointer;vertical-align:middle;position:relative;background:transparent;\"><span style=\"font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;\">Oficer prowadzący</span></div>"}]}'),

('police', 'Mandat Karny',
'{"pages":[{"header":"LSPD — Wydział Ruchu Drogowego","watermark":"LSPD","footer":"","html":"<p><strong style=\"font-size:16px;\">MANDAT KARNY</strong></p><hr/><p>Numer mandatu: _______________</p><p>Wystawiono dla: _______________</p><p>Kwota grzywny: _______________ zł</p><p>Naruszenie: _______________</p><p>Miejsce i czas: _______________</p><br/><div class=\"signature-slot\" data-id=\"sig_officer\" data-label=\"Wystawiający funkcjonariusz\" style=\"display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-end;width:220px;min-height:70px;padding:8px 12px 6px;margin:8px 4px;border:none;border-bottom:2px solid #1e293b;cursor:pointer;vertical-align:middle;position:relative;background:transparent;\"><span style=\"font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;\">Wystawiający funkcjonariusz</span></div><div class=\"signature-slot\" data-id=\"sig_citizen\" data-label=\"Ukarany / Odmowa podpisu\" style=\"display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-end;width:220px;min-height:70px;padding:8px 12px 6px;margin:8px 4px;border:none;border-bottom:2px solid #1e293b;cursor:pointer;vertical-align:middle;position:relative;background:transparent;\"><span style=\"font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;\">Ukarany / Odmowa podpisu</span></div>"}]}'),

('police', 'Raport ze Zdarzenia',
'{"pages":[{"header":"LSPD — Raport Służbowy","watermark":"LSPD","footer":"Wygenerowano przez system XR-MDT","html":"<p><strong style=\"font-size:16px;\">RAPORT ZE ZDARZENIA</strong></p><hr/><p>Data: _______________</p><p>Lokalizacja: _______________</p><p>Uczestnicy zdarzenia: _______________</p><p>Opis przebiegu zdarzeń:</p><p style=\"min-height:100px;\">_______________</p><p>Podjęte działania: _______________</p><p>Wnioski: _______________</p><br/><div class=\"signature-slot\" data-id=\"sig_reporting\" data-label=\"Sporządzający raport\" style=\"display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-end;width:220px;min-height:70px;padding:8px 12px 6px;margin:8px 4px;border:none;border-bottom:2px solid #1e293b;cursor:pointer;vertical-align:middle;position:relative;background:transparent;\"><span style=\"font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;\">Sporządzający raport</span></div><div class=\"signature-slot\" data-id=\"sig_supervisor\" data-label=\"Zatwierdził przełożony\" style=\"display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-end;width:220px;min-height:70px;padding:8px 12px 6px;margin:8px 4px;border:none;border-bottom:2px solid #1e293b;cursor:pointer;vertical-align:middle;position:relative;background:transparent;\"><span style=\"font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;\">Zatwierdził przełożony</span></div>"}]}');

-- ============================================================
-- DANE STARTOWE — 3 wydrukowane dokumenty w kartotece (archiwum)
-- Podpisane wzorcowo, z numerami #0001 #0002 #0003
-- ============================================================

INSERT IGNORE INTO `mdt_document_archive`
  (`id`, `faction`, `title`, `html_content`, `author_id`, `author_name`, `is_in_archive`)
VALUES

('ARC-DEMO-0001', 'police', 'Protokół Zatrzymania — Wzór #0001',
'{"pages":[{"header":"LSPD — Mission Row Police Department","watermark":"LSPD","footer":"Dokument poufny — tylko do użytku służbowego","html":"<p><strong style=\"font-size:16px;\">PROTOKÓŁ ZATRZYMANIA</strong></p><hr/><p>Data zatrzymania: 01.01.2026</p><p>Imię i nazwisko zatrzymanego: Jan Kowalski</p><p>Podstawa prawna: Art. 15 Ustawy o Policji</p><p>Miejsce zatrzymania: Mission Row</p><p>Opis zdarzenia:</p><p>Osoba zatrzymana podczas rutynowej kontroli. Brak dokumentów tożsamości. Przewieziona na posterunek w celu ustalenia tożsamości.</p><br/><div class=\"signature-slot signed\" data-id=\"sig_officer\" data-label=\"Oficer prowadzący\" data-signed-by=\"Sgt. John Smith\" style=\"display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-end;width:220px;min-height:70px;padding:8px 12px 6px;margin:8px 4px;border:none;border-bottom:2px solid #1e293b;cursor:default;vertical-align:middle;position:relative;background:transparent;user-select:none;\"><span class=\"sig-name\" style=\"font-family:\'Dancing Script\',cursive;font-size:26px;font-weight:700;color:#1e293b;line-height:1.1;text-align:center;width:100%;\">Sgt. John Smith</span><span class=\"sig-date\" style=\"font-size:9px;color:#94a3b8;font-family:sans-serif;margin-top:2px;font-style:italic;\">01.01.2026 08:30</span><span class=\"sig-label\" style=\"font-size:10px;color:#475569;text-transform:uppercase;letter-spacing:0.5px;font-weight:600;font-family:sans-serif;margin-top:4px;\">Oficer prowadzący</span></div>"}]}',
'SYSTEM', 'System XR-MDT', 1),

('ARC-DEMO-0002', 'police', 'Mandat Karny — Wzór #0002',
'{"pages":[{"header":"LSPD — Wydział Ruchu Drogowego","watermark":"LSPD","footer":"","html":"<p><strong style=\"font-size:16px;\">MANDAT KARNY</strong></p><hr/><p>Numer mandatu: MK-2026-0001</p><p>Wystawiono dla: Adam Nowak</p><p>Kwota grzywny: 500 zł</p><p>Naruszenie: Przekroczenie prędkości o 40 km/h w obszarze zabudowanym</p><p>Miejsce i czas: Alta Street, 01.01.2026 godz. 14:20</p><br/><div class=\"signature-slot signed\" data-id=\"sig_officer\" data-label=\"Wystawiający funkcjonariusz\" data-signed-by=\"Cpl. Maria Kowalska\" style=\"display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-end;width:220px;min-height:70px;padding:8px 12px 6px;margin:8px 4px;border:none;border-bottom:2px solid #1e293b;cursor:default;vertical-align:middle;position:relative;background:transparent;user-select:none;\"><span class=\"sig-name\" style=\"font-family:\'Dancing Script\',cursive;font-size:26px;font-weight:700;color:#1e293b;line-height:1.1;text-align:center;width:100%;\">Cpl. Maria Kowalska</span><span class=\"sig-date\" style=\"font-size:9px;color:#94a3b8;font-family:sans-serif;margin-top:2px;font-style:italic;\">01.01.2026 14:25</span><span class=\"sig-label\" style=\"font-size:10px;color:#475569;text-transform:uppercase;letter-spacing:0.5px;font-weight:600;font-family:sans-serif;margin-top:4px;\">Wystawiający funkcjonariusz</span></div><div class=\"signature-slot\" data-id=\"sig_citizen\" data-label=\"Ukarany / Odmowa podpisu\" style=\"display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-end;width:220px;min-height:70px;padding:8px 12px 6px;margin:8px 4px;border:none;border-bottom:2px solid #1e293b;cursor:pointer;vertical-align:middle;position:relative;background:transparent;\"><span style=\"font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;\">Ukarany / Odmowa podpisu</span></div>"}]}',
'SYSTEM', 'System XR-MDT', 1),

('ARC-DEMO-0003', 'police', 'Raport ze Zdarzenia — Wzór #0003',
'{"pages":[{"header":"LSPD — Raport Służbowy","watermark":"LSPD","footer":"Wygenerowano przez system XR-MDT","html":"<p><strong style=\"font-size:16px;\">RAPORT ZE ZDARZENIA</strong></p><hr/><p>Data: 02.01.2026</p><p>Lokalizacja: Vinewood Hills</p><p>Uczestnicy zdarzenia: 3 osoby cywilne, 2 funkcjonariusze</p><p>Opis przebiegu zdarzeń:</p><p>Patrol otrzymał zgłoszenie o podejrzanym zachowaniu. Po przybyciu na miejsce stwierdzono próbę włamania do posesji. Sprawca zbiegł przed przybyciem jednostek wsparcia.</p><p>Podjęte działania: Przeszukanie terenu, zabezpieczenie śladów, przesłuchanie świadków.</p><p>Wnioski: Sprawa przekazana do dalszego dochodzenia.</p><br/><div class=\"signature-slot signed\" data-id=\"sig_reporting\" data-label=\"Sporządzający raport\" data-signed-by=\"Off. Tom Williams\" style=\"display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-end;width:220px;min-height:70px;padding:8px 12px 6px;margin:8px 4px;border:none;border-bottom:2px solid #1e293b;cursor:default;vertical-align:middle;position:relative;background:transparent;user-select:none;\"><span class=\"sig-name\" style=\"font-family:\'Dancing Script\',cursive;font-size:26px;font-weight:700;color:#1e293b;line-height:1.1;text-align:center;width:100%;\">Off. Tom Williams</span><span class=\"sig-date\" style=\"font-size:9px;color:#94a3b8;font-family:sans-serif;margin-top:2px;font-style:italic;\">02.01.2026 20:15</span><span class=\"sig-label\" style=\"font-size:10px;color:#475569;text-transform:uppercase;letter-spacing:0.5px;font-weight:600;font-family:sans-serif;margin-top:4px;\">Sporządzający raport</span></div><div class=\"signature-slot\" data-id=\"sig_supervisor\" data-label=\"Zatwierdził przełożony\" style=\"display:inline-flex;flex-direction:column;align-items:center;justify-content:flex-end;width:220px;min-height:70px;padding:8px 12px 6px;margin:8px 4px;border:none;border-bottom:2px solid #1e293b;cursor:pointer;vertical-align:middle;position:relative;background:transparent;\"><span style=\"font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:0.5px;\">Zatwierdził przełożony</span></div>"}]}',
'SYSTEM', 'System XR-MDT', 1);
