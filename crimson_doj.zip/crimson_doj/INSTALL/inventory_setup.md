# Inventory Integration Guide
**Mastering Item Hooks for XR-MDT**

This guide provides the necessary technical configurations to integrate **XR-MDT** items (Bodycams, GPS, Documents) into your inventory system.

---

## 1. Item Definitions (`config.main.lua`)
Before adding items to your inventory, ensure the internal keys match your configuration file:

```lua
Config.Items = {
    bodycam = 'bodycam',
    gps = 'gps',
    document = 'document',
    tracking_band = 'tracking_band'
}
```

---

## 2. 🌀 Ox Inventory Setup (`ox_inventory`)

### ⚡ Recommended: Server Export 
Assigning the `client.export` property is the most reliable method. It ensures items are **not consumed** and the client-side logic triggers instantly.

Add this to `ox_inventory/data/items.lua`:

```lua
['bodycam'] = {
    label = 'Axon Body 3',
    weight = 500,
    stack = false,
    close = true,
    client = {
        export = 'xr-mdt.bodycam'
    }
},  

['gps'] = {
    label = 'GPS Tracker',
    weight = 100,
    stack = false,
    close = true,
    client = {
        export = 'xr-mdt.gps'
    }
},

['document'] = {
    label = 'A4 Document',
    weight = 10,
    stack = false,
    close = true,
    client = {
        export = 'xr-mdt.document'
    }
},

['tracking_band'] = {
    label = 'Tracking Band',
    weight = 100,
    stack = false,
    close = true,
    client = {
        export = 'xr-mdt.tracking_band'
    }
}
```

---

## 3. 🔵 QB-Core Inventory Setup
In `qb-core/shared/items.lua`, simply define the items. **XR-MDT** automatically registers the usable item logic on the server-side.

```lua
gps           = { name = 'gps', label = 'GPS', weight = 100, type = 'item', image = 'gps.png', unique = false, useable = true, shouldClose = false, description = 'Police GPS' },
bodycam       = { name = 'bodycam', label = 'Bodycam', weight = 100, type = 'item', image = 'bodycam.png', unique = false, useable = true, shouldClose = false, description = 'Axon Body 3' },
document      = { name = 'document', label = 'Document', weight = 10, type = 'item', image = 'document.png', unique = true, useable = true, shouldClose = true, description = 'Official Document' },
tracking_band = { name = 'tracking_band', label = 'Tracking Band', weight = 100, type = 'item', image = 'tracking_band.png', unique = false, useable = true, shouldClose = true, description = 'Ankle GPS Tracker' }
```

---

## 4. 🟢 ESX Standard Setup
Run this SQL query to register the items in your database:

```sql
INSERT INTO `items` (`name`, `label`, `weight`, `rare`, `can_remove`) VALUES
('gps', 'GPS Tracker', 1, 0, 1),
('bodycam', 'Axon Bodycam', 1, 0, 1),
('document', 'Official Document', 1, 0, 1),
('tracking_band', 'Ankle Tracker', 1, 0, 1);
```

---

## 🛠 Troubleshooting Item Logic
If items do not trigger:
1.  **Check Server Console:** Look for the `[XR-MDT]` prefix.
2.  **Job Permissions:** Ensure your character has a job defined in `Config.Cameras.AllowedJobs`.
3.  **Inventory Metadata:** If you are using Ox Inventory and the document does not open, ensure you are not clearing metadata upon item creation.
