-- Database structure for xr-mdt (ESX Edition)

-- Framework Extensions (ESX compatible logic)
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `charid` int(11) DEFAULT NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `ssn` varchar(20) DEFAULT NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `badge` varchar(50) DEFAULT '00';
ALTER TABLE `owned_vehicles` ADD COLUMN IF NOT EXISTS `vin` varchar(50) DEFAULT NULL;

-- Core
CREATE TABLE IF NOT EXISTS `mdt_statistics` (
  `citizenid` varchar(50) NOT NULL,
  `job` varchar(20) DEFAULT 'unemployed',
  `duty_minutes` int(11) DEFAULT 0,
  `reports_count` int(11) DEFAULT 0,
  `arrests_count` int(11) DEFAULT 0,
  `calls_count` int(11) DEFAULT 0,
  PRIMARY KEY (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `mdt_settings` (
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO `mdt_settings` (`setting_key`, `setting_value`) VALUES ('lspd_code', 'green');

CREATE TABLE IF NOT EXISTS `mdt_units` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(50) NOT NULL,
  `type` VARCHAR(50) NOT NULL DEFAULT 'Adam',
  `department` VARCHAR(20) NOT NULL DEFAULT 'police',
  `status` VARCHAR(20) DEFAULT 'Available',
  `members` TEXT DEFAULT '[]',
  `creator` VARCHAR(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `phone_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `citizenid` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL,
  `society` varchar(50) NOT NULL,
  `sender` varchar(100) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `mdt_notes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `citizenid` VARCHAR(50) NOT NULL,
  `department` VARCHAR(20) NOT NULL DEFAULT 'police',
  `title` VARCHAR(255) DEFAULT 'Untitled',
  `content` LONGTEXT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (`citizenid`),
  INDEX (`department`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- MDT LSPD / DOJ (Shared)
CREATE TABLE IF NOT EXISTS `lspd_citizen_data` (
  `citizenid` varchar(50) NOT NULL,
  `mugshot_url` text DEFAULT NULL,
  `fingerprint` varchar(100) DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  PRIMARY KEY (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_convictions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `citizenid` varchar(50) NOT NULL,
  `offense` text NOT NULL,
  `fine` int(11) DEFAULT 0,
  `jail_time` int(11) DEFAULT 0,
  `author` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_licenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `citizenid` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `expires` varchar(50) DEFAULT 'Never',
  `granted_by` varchar(50) DEFAULT 'Police',
  `granted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `citizenid_type` (`citizenid`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_warrants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `citizenid` varchar(50) NOT NULL,
  `reason` text DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `citizenid` varchar(50) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_vehicle_tags` (
  `plate` varchar(20) NOT NULL,
  `wanted` tinyint(1) DEFAULT 0,
  `stolen` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `jail_sentences` (
  `citizenid` varchar(50) NOT NULL,
  `time_remaining` int(11) DEFAULT 0,
  `in_jail` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_incidents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` VARCHAR(50) DEFAULT 'OPEN',
  `notes` LONGTEXT DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_incident_criminals` (
  `incident_id` int(11) NOT NULL,
  `citizenid` varchar(50) NOT NULL,
  `role` varchar(50) DEFAULT 'Criminal',
  PRIMARY KEY (`incident_id`,`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_incident_vehicles` (
  `incident_id` int(11) NOT NULL,
  `plate` varchar(20) NOT NULL,
  `role` varchar(50) DEFAULT 'Suspect',
  PRIMARY KEY (`incident_id`,`plate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_incident_officers` (
  `incident_id` int(11) NOT NULL,
  `officerid` varchar(50) NOT NULL,
  `badge` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`incident_id`,`officerid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `lspd_reports` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL,
  `type` VARCHAR(255) DEFAULT 'Theft',
  `description` LONGTEXT DEFAULT NULL,
  `author` VARCHAR(100) DEFAULT NULL,
  `author_id` VARCHAR(50) DEFAULT NULL,
  `tags` LONGTEXT DEFAULT NULL,
  `gallery` LONGTEXT DEFAULT NULL,
  `officers` LONGTEXT DEFAULT NULL,
  `civilians` LONGTEXT DEFAULT NULL,
  `suspects` LONGTEXT DEFAULT NULL,
  `vehicles` LONGTEXT DEFAULT NULL,
  `weapons` LONGTEXT DEFAULT NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `mdt_weapons` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `serial` VARCHAR(50) UNIQUE NOT NULL,
  `citizenid` VARCHAR(50) NOT NULL,
  `model` VARCHAR(50) DEFAULT 'Unknown',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `tracking_bands` (
  `citizenid` VARCHAR(50) NOT NULL,
  `tracker_id` VARCHAR(50) DEFAULT NULL,
  `applied_by` VARCHAR(50) DEFAULT NULL,
  `applied_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- MDT EMS
CREATE TABLE IF NOT EXISTS `ems_citizen_data` (
  `citizenid` varchar(50) NOT NULL,
  `blood_type` varchar(10) DEFAULT 'Unknown',
  `allergies` text DEFAULT NULL,
  `chronic_diseases` text DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `insurance` varchar(50) DEFAULT 'inactive',
  `avatar` text DEFAULT NULL,
  PRIMARY KEY (`citizenid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `ems_medical_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `citizenid` varchar(50) NOT NULL,
  `diagnosis` text DEFAULT NULL,
  `treatment` text DEFAULT NULL,
  `doctor` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- MDT DOJ
CREATE TABLE IF NOT EXISTS `doj_cases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `author` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'OTWARTA',
  `suspects` longtext DEFAULT NULL,
  `witnesses` longtext DEFAULT NULL,
  `vehicles` longtext DEFAULT NULL,
  `officers` longtext DEFAULT NULL,
  `photos` longtext DEFAULT NULL,
  `charges` longtext DEFAULT NULL,
  `notes` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- MDT Business
CREATE TABLE IF NOT EXISTS `business_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_name` varchar(50) NOT NULL,
  `citizenid` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `issuer` varchar(100) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `business_tariffs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_name` varchar(50) NOT NULL,
  `label` varchar(100) NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `mdt_business_data` (
  `job_name` VARCHAR(50) PRIMARY KEY,
  `logo_url` LONGTEXT,
  `notes` LONGTEXT,
  `licenses` LONGTEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- MDT Logs
CREATE TABLE IF NOT EXISTS `mdt_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `job` VARCHAR(50) NOT NULL,
    `citizenid` VARCHAR(50) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `rank` VARCHAR(50),
    `action_type` VARCHAR(100) NOT NULL,
    `details` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- MDT Documents & Templates
DROP TABLE IF EXISTS `mdt_documents`; CREATE TABLE `mdt_documents` (
  `id` varchar(50) NOT NULL,
  `faction` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `html_content` longtext NOT NULL,
  `author_id` varchar(50) DEFAULT NULL,
  `author_name` varchar(100) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  INDEX (`faction`),
  INDEX (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `mdt_templates`; CREATE TABLE `mdt_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `faction` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `html_content` longtext NOT NULL,
  PRIMARY KEY (`id`),
  INDEX (`faction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- MDT Recordings
CREATE TABLE IF NOT EXISTS `mdt_recordings` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `video_url` VARCHAR(255) NOT NULL,
    `owner` VARCHAR(100) NOT NULL,
    `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `faction` VARCHAR(50) DEFAULT 'LSPD',
    `metadata` LONGTEXT DEFAULT NULL,
    INDEX (`owner`),
    INDEX (`faction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- MDT Armory
CREATE TABLE IF NOT EXISTS `mdt_armory_kits` (
    `id`          INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `identifier`  VARCHAR(60)      NOT NULL COMMENT 'citizenid (QB/QBox) or identifier (ESX)',
    `job`         VARCHAR(50)      NOT NULL COMMENT 'Job name, e.g. police, sheriff',
    `kit_name`    VARCHAR(100)     NOT NULL COMMENT 'Player-defined kit name',
    `items`       LONGTEXT         NOT NULL COMMENT 'JSON array: [{item, amount, label}]',
    `created_at`  TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_identifier_job` (`identifier`(50), `job`(30))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- MDT Armory Stock
CREATE TABLE IF NOT EXISTS `mdt_armory_stock` (
    `id`          INT UNSIGNED     NOT NULL AUTO_INCREMENT,
    `job`         VARCHAR(50)      NOT NULL COMMENT 'Job owning this stock entry',
    `item`        VARCHAR(100)     NOT NULL COMMENT 'Item name/hash',
    `amount`      INT UNSIGNED     NOT NULL DEFAULT 0 COMMENT 'Current available quantity',
    `updated_at`  TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_job_item` (`job`(30), `item`(60))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Bank Statements (Transaction History)
CREATE TABLE IF NOT EXISTS `bank_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_name` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL,
  `statement_type` varchar(20) NOT NULL COMMENT 'deposit or withdraw',
  `reason` varchar(255) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX (`account_name`),
  INDEX (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Document Archive (Kartoteka)
CREATE TABLE IF NOT EXISTS `mdt_document_archive` (
  `id` varchar(50) NOT NULL,
  `doc_number` INT AUTO_INCREMENT,
  `faction` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `html_content` longtext NOT NULL,
  `author_id` varchar(50) DEFAULT NULL,
  `author_name` varchar(100) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `is_in_archive` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY (`doc_number`),
  INDEX (`faction`),
  INDEX (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
