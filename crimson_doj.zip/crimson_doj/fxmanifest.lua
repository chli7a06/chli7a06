shared_script '@WaveShield/resource/include.lua'

fx_version 'cerulean'
game 'gta5'

author 'Rabbicik'
description 'Crimson DOJ - Qbox configuration and Crimson branding (based on XR-MDT)'
version '2.0-beta'

dependencies {
    'qbx_core',
    'ox_lib',
    'oxmysql',

}

ui_page 'web/dist/index.html'

shared_scripts {
    '@ox_lib/init.lua',
    'configs/config.main.lua',
    'configs/config.webhook.lua',
    'configs/locales/*.lua',
    'configs/config.police.lua',
    'configs/config.ems.lua',
    'configs/config.business.lua',
    'configs/config.doj.lua',
    'configs/config.armory.lua',
}

client_scripts {
    'editable/client/main.lua',
    'client/cl_armory.lua',
    'client/cl_dispatch.lua',
    'client/cl_lspd.lua',
    'client/cl_ems.lua',
    'client/cl_business.lua',
    'client/cl_doj.lua',
    'client/cl_bodycam.lua',
    'client/cl_gps.lua',
    'client/cl_tracking.lua',
    'client/cl_heli.lua',
    'client/cl_blips.lua',
    'client/cl_documents.lua',
    'client/cl_archive.lua',
    'client/cl_logs.lua',
    'editable/client/lspd.lua',
    'editable/client/ems.lua',
    'editable/client/business.lua',
    'editable/client/doj.lua',
    'editable/tablets/*/client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/sv_main.lua',
    'server/sv_database.lua',
    'server/sv_duty.lua',
    'server/sv_statistics.lua',
    'editable/server/main.lua',
    'editable/server/sv_items.lua',
    'editable/server/lspd.lua',
    'editable/server/ems.lua',
    'editable/server/business.lua',
    'editable/server/doj.lua',
    'server/sv_lspd.lua',
    'server/sv_reports.lua',
    'server/sv_notepad.lua',
    'server/sv_documents.lua',
    'server/sv_lspd_employees.lua',
    'server/sv_units.lua',
    'server/sv_ems.lua',
    'server/sv_ems_employees.lua',
    'server/sv_business.lua',
    'server/sv_doj.lua',
    'server/sv_bodycam.lua',
    'editable/server/sv_vehicles.lua',
    'server/sv_gps.lua',
    'server/sv_weapons.lua',
    'server/sv_tracking.lua',
    'server/sv_logs.lua',
    'server/sv_armory.lua'
}

files {
    'web/dist/index.html',
    'web/dist/armory.html',
    'web/dist/assets/**',
    'web/dist/images/**',
    'web/dist/sounds/**',
    'web/dist/locales/**',
}

escrow_ignore {
    'configs/*.lua',
    'configs/locales/*.lua',
    'editable/*.lua',
    'editable/server/*.lua',
    'editable/client/*.lua',
    'client/cl_armory.lua'
}

dependency '/assetpacks'
