EditTable.LSPD = EditTable.LSPD or {}
EditTable.LSPD.ClientEvents = EditTable.LSPD.ClientEvents or {}

--[[
    Called when panic button is pressed
--]]
EditTable.LSPD.ClientEvents.PanicButton = function()
    -- Client side visual/audio effects
    -- Server side handles the blips
end

-- --- Police Custom Commands ---
if Config.EnableDispatch then
    RegisterCommand('bk1', function() sendBackupAlert(1, 'POLICEBackup1', 'Code 2', 3, 'BK1') end, false)
    RegisterCommand('bk2', function() sendBackupAlert(2, 'POLICEBackup2', 'Code 3', 47, 'BK2') end, false)
    RegisterCommand('bk3', function() sendBackupAlert(3, 'POLICEBackup3', 'Code 3', 1, 'BK3') end, false)
    RegisterCommand('bk', function() sendBackupAlert(2, 'POLICEBackup2', 'Code 3', 47, 'BK2') end, false)

    RegisterCommand('10-13', function()
        local player = Bridge.GetPlayerData()
        if not player or not player.job then return end
        if (player.job.name ~= 'fbi' and player.job.name ~= 'ambulance' and player.job.name ~= 'doj') then return end

        local coords = GetEntityCoords(PlayerPedId())
        local alertCoords = { x = coords.x, y = coords.y, z = coords.z }
        local callsign = player.metadata.callsign or "00"
        local name = player.charinfo.firstname .. " " .. player.charinfo.lastname

        TriggerServerEvent('xr-mdt:server:lspd:createAlert', {
            code = '10-13',
            title = string.format((Locales[Config.Language] or Locales['en']).lspd.officer_down_title, callsign, name),
            description = string.format((Locales[Config.Language] or Locales['en']).lspd.officer_down_desc, callsign,
                name),
            short = (Locales[Config.Language] or Locales['en']).lspd.officer_down_title,
            coords = alertCoords,
            sound = 'POLICEOfficerDown',
            jobs = { 'police', 'ambulance', 'doj' },
            blip = {
                sprite = 303,
                scale = 1.3,
                color = 1,
                name = GetLocale("lspd.officer_down_title")
            },
            alertTime = 120
        })
    end, false)
end

-- --- Dispatch & UI Commands ---
if Config.EnableDispatch then
    RegisterCommand('mdt_dispatch', function()
        local PlayerData = Bridge.GetPlayerData()
        if not PlayerData or not PlayerData.job then return end
        if LocalPlayer.state.phoneOpen then return end
        if (PlayerData.job.name == 'fbi' or PlayerData.job.name == 'ambulance') and PlayerData.job.onduty then
            isDispatchOpen = not isDispatchOpen
            SetNuiFocus(isDispatchOpen, isDispatchOpen)
            SendNUIMessage({
                action = 'toggleDispatch',
                state = isDispatchOpen
            })
        end
    end, false)
    RegisterKeyMapping('mdt_dispatch', GetLocale("keys.dispatch_cmd"), 'keyboard',
        'DELETE')

    RegisterCommand('panic_button', function()
        local player = Bridge.GetPlayerData()
        if not player or not player.job then return end
        if (player.job.name ~= 'fbi' and player.job.name ~= 'ambulance' and player.job.name ~= 'doj') then return end

        if not IsControlPressed(0, 21) then return end

        local currentTime = GetGameTimer()
        if (currentTime - lastPanic) < 10000 then
            Bridge.Notify(GetLocale("lspd.panic_wait"), 'error')
            return
        end
        lastPanic = currentTime

        local coords = GetEntityCoords(PlayerPedId())
        local alertCoords = { x = coords.x, y = coords.y, z = coords.z }
        local callsign = player.metadata.callsign or "00"
        local name = player.charinfo.firstname .. " " .. player.charinfo.lastname

        TriggerServerEvent('xr-mdt:server:lspd:createAlert', {
            code = '10-13',
            title = string.format((Locales[Config.Language] or Locales['en']).lspd.panic_title, callsign, name),
            description = string.format((Locales[Config.Language] or Locales['en']).lspd.panic_desc, callsign, name),
            short = (Locales[Config.Language] or Locales['en']).lspd.panic_title,
            coords = alertCoords,
            sound = 'POLPanicButton',
            jobs = { 'fbi', 'ambulance', 'doj' },
            blip = {
                sprite = 480,
                scale = 1.3,
                color = 1,
                name = (Locales[Config.Language] or Locales['en']).lspd.panic_title
            },
            alertTime = 120
        })
    end, false)
    RegisterKeyMapping('panic_button', (Locales[Config.Language] or Locales['en']).keys.panic_cmd, 'keyboard', 'L')
end
