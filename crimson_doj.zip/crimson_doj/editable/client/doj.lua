EditTable.DOJ = EditTable.DOJ or {}
EditTable.DOJ.ClientEvents = {}


--[[
    Example Event
--]]
-- Config.DOJ.ClientEvents.OnCaseUpdated = function(caseId)

-- end
