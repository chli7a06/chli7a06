EditTable.Business = EditTable.Business or {}
EditTable.Business.ClientEvents = EditTable.Business.ClientEvents or {}
