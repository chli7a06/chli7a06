EditTable.EMS = EditTable.EMS or {}
EditTable.EMS.ClientEvents = EditTable.EMS.ClientEvents or {}
