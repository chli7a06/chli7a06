print('^3[XR-MDT DEBUG]^7 main.lua START')

local QBCore = nil
local ESX = nil

-- Simple Framework Detection
CreateThread(function()
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        QBCore = exports['qb-core']:GetCoreObject()
    elseif Config.Framework == 'esx' then
        ESX = exports['es_extended']:getSharedObject()
    end
    print('^2[XR-MDT]^7 Bridge System Initialized (Framework: ' .. tostring(Config.Framework) .. ')')
end)

function GetLocale(path)
    if not path then return nil end
    local keys = {}
    for key in path:gmatch("([^%.]+)") do
        table.insert(keys, key)
    end

    local current = Locales[Config.Language] or Locales['en']
    if not current then return nil end

    for _, key in ipairs(keys) do
        if type(current) == 'table' and current[key] then
            current = current[key]
        else
            return nil
        end
    end
    return current
end

Bridge = Bridge or {}

local function NormalizeESXPlayerData(playerData)
    if not playerData then return nil end
    local pd = {}
    for k, v in pairs(playerData) do
        pd[k] = v
    end

    if pd.job and (type(pd.job.grade) == 'number' or type(pd.job.grade) == 'string') then
        local normJob = {}
        for k, v in pairs(pd.job) do
            normJob[k] = v
        end
        local gradeLevel = tonumber(pd.job.grade) or 0
        normJob.original_grade = pd.job.grade
        normJob.grade = {
            level = gradeLevel,
            name = pd.job.grade_label or pd.job.grade_name or tostring(gradeLevel)
        }
        normJob.isboss = (pd.job.grade_name == 'boss')
        normJob.onduty = true
        pd.job = normJob
    end

    -- ESX Compatibility Shims
    pd.charinfo = pd.charinfo or {
        firstname = pd.firstName or "Unknown",
        lastname = pd.lastName or "Officer"
    }
    pd.items = pd.items or pd.inventory or {}

    return pd
end

-- --- EXPORTS DO ZEWNĄTRZ (FRAMEWORK, TARGET, INVENTORY, NOTIFY) ---
function Bridge.GetPlayerData()
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return QBCore.Functions.GetPlayerData()
    elseif Config.Framework == 'esx' then
        return NormalizeESXPlayerData(ESX.GetPlayerData())
    end
    return nil
end

--[[
    -@param text string
    -@param type string? 'success' | 'error' | 'info'
    -@param length number?
--]]
function Bridge.Notify(text, notifyType, length)
    local notifyData = {}
    if type(text) == 'table' then
        notifyData = text
        text = notifyData.description or notifyData.text or ""
        notifyType = notifyData.type or notifyType or 'info'
        length = notifyData.duration or notifyData.length or length or 5000
    else
        notifyType = notifyType or 'info'
        length = length or 5000
        notifyData = {
            description = text,
            type = notifyType,
            duration = length
        }
    end

    if GetResourceState('xr-hud') == 'started' then
        local title = notifyData.title or ''
        local description = text or ''
        exports['xr-hud']:ShowNotification(title, description)
        return
    end

    if Config.Framework == 'qbox' or Config.Notify.Type == 'ox' then
        lib.notify(notifyData)
    elseif Config.Notify.Type == 'qb' then
        local displayMsg = text
        if notifyData.title then
            displayMsg = "[" .. notifyData.title .. "] " .. text
        end
        QBCore.Functions.Notify(displayMsg, notifyType, length)
    elseif Config.Notify.Type == 'esx' then
        local displayMsg = text
        if notifyData.title then
            displayMsg = "~y~~h~" .. notifyData.title .. "~h~~w~\n" .. text
        end
        ESX.ShowNotification(displayMsg)
    else
        local displayMsg = text
        if notifyData.title then
            displayMsg = "[" .. notifyData.title .. "] " .. text
        end
        BeginTextCommandThefeedPost("STRING")
        AddTextComponentSubstringPlayerName(displayMsg)
        EndTextCommandThefeedPostTicker(false, true)
    end
end

function Bridge.TriggerCallback(name, cb, ...)
    local timeout = false
    CreateThread(function()
        -- 10s timeout
        Wait(10000)
        if not timeout and cb then
            timeout = true
            EditTable.Functions.ReportError(EditTable.Functions.ErrorCodes.CALLBACK_TIMEOUT,
                "Callback exceeded 10s: " .. name)
        end
    end)

    if Config.Framework == 'qbox' or Config.Framework == 'qb' then
        local args = { ... }
        CreateThread(function()
            local result = lib.callback.await(name, false, table.unpack(args))
            if not timeout and cb then
                timeout = true
                cb(result)
            end
        end)
    elseif Config.Framework == 'esx' then
        ESX.TriggerServerCallback(name, function(...)
            if not timeout and cb then
                timeout = true
                cb(...)
            end
        end, ...)
    end
end

function Bridge.IsPlayerLoaded()
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        -- Primary check via state bag
        if LocalPlayer.state.isLoggedIn then return true end

        -- Fallback check via QBCore export
        if QBCore then
            local data = QBCore.Functions.GetPlayerData()
            if data and data.citizenid then return true end
        end
        return false
    elseif Config.Framework == 'esx' then
        if ESX and ESX.IsPlayerLoaded then
            return ESX.IsPlayerLoaded()
        end
        -- Fallback for ESX if object is ready but function isn't called yet
        local data = ESX.GetPlayerData()
        if data and data.identifier then return true end
    end
    return true
end

function Bridge.GetClosestVehicle(coords)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return QBCore.Functions.GetClosestVehicle(coords)
    elseif Config.Framework == 'esx' then
        return ESX.Game.GetClosestVehicle(coords)
    end

    return GetClosestVehicle(coords.x, coords.y, coords.z, 5.0, 0, 70)
end

function Bridge.GetClosestPlayer()
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return QBCore.Functions.GetClosestPlayer()
    elseif Config.Framework == 'esx' then
        return ESX.Game.GetClosestPlayer()
    end

    -- Native Fallback
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    local closestPlayer, closestDistance = -1, -1
    local players = GetActivePlayers()

    for i = 1, #players do
        local target = GetPlayerPed(players[i])
        if target ~= ped then
            local targetCoords = GetEntityCoords(target)
            local distance = #(coords - targetCoords)

            if closestDistance == -1 or distance < closestDistance then
                closestPlayer = players[i]
                closestDistance = distance
            end
        end
    end

    return closestPlayer, closestDistance
end

function Bridge.OpenMenu(data)
    if Config.Framework == 'qbox' then
        local options = {}
        for _, v in ipairs(data) do
            if not v.isMenuHeader then
                table.insert(options, {
                    title = v.header,
                    description = v.txt,
                    icon = v.icon,
                    serverEvent = v.params.isServer and v.params.event or nil,
                    event = not v.params.isServer and v.params.event or nil,
                    args = v.params.args
                })
            end
        end
        lib.registerContext({
            id = 'mdt_menu',
            title = (Locales[Config.Language] or Locales['en']).system.menu_title,
            options = options
        })
        lib.showContext('mdt_menu')
    elseif Config.Framework == 'qb' then
        exports['qb-menu']:openMenu(data)
    elseif Config.Framework == 'esx' then
        if GetResourceState('ox_lib') == 'started' then
            local options = {}
            for _, v in ipairs(data) do
                if not v.isMenuHeader then
                    table.insert(options, {
                        title = v.header,
                        description = v.txt,
                        icon = v.icon,
                        serverEvent = v.params.isServer and v.params.event or nil,
                        event = not v.params.isServer and v.params.event or nil,
                        args = v.params.args
                    })
                end
            end
            lib.registerContext({
                id = 'mdt_menu',
                title = (Locales[Config.Language] or Locales['en']).system.menu_title,
                options = options
            })
        end
    end
end

-- --- TARGETING BRIDGE & DEBUG SYSTEM ---
local ActiveZones = {}

function Bridge.AddBoxZone(data)
    CreateThread(function()
        -- Crucial: Wait for target resources to fully initialize
        Wait(1000)

        local oxState = GetResourceState('ox_target')
        local qbxState = GetResourceState('qbx_target')
        local qbState = GetResourceState('qb-target')

        local name = data.name or ("zone_" .. tostring(math.random(1000)))

        if oxState ~= 'started' and qbxState ~= 'started' and qbState ~= 'started' then
            if Config.Debug then
                print('^1[XR-MDT ERROR]^7 Cannot create BoxZone (' ..
                    name .. '). No target system running.')
            end
            return
        end

        if Config.Debug then
            ActiveZones[name] = { coords = data.coords }
            print(string.format('^3[XR-MDT DEBUG]^7 Initializing Zone: %s', name))
        end

        if oxState == 'started' then
            -- ==========================================
            -- OX_TARGET NATIVE API
            -- ==========================================
            local oxOptions = {}

            -- Global Debug Option
            if Config.Debug then
                table.insert(oxOptions, {
                    name = name .. "_debug",
                    label = "DEBUG: Check Permissions",
                    icon = "fa-solid fa-bug",
                    onSelect = function()
                        local pd = Bridge.GetPlayerData()
                        print("^3[XR-MDT DEBUG]^7 --- Permission Check (" .. name .. ") ---")
                        print("^3[XR-MDT DEBUG]^7 Job:", pd and pd.job and pd.job.name or "None")
                        print("^3[XR-MDT DEBUG]^7 Grade:",
                            pd and pd.job and pd.job.grade and pd.job.grade.level or "None")
                    end
                })
            end

            -- If the user provided ox_target native syntax, we can mostly pass it through.
            -- But we must ensure missing things are mapped safely.
            for i, opt in ipairs(data.options or {}) do
                local o = {
                    name = opt.name or (name .. "_opt_" .. i),
                    label = opt.label,
                    icon = opt.icon,
                    distance = opt.distance or 2.5
                }

                if opt.onSelect then o.onSelect = opt.onSelect end
                if opt.event then o.event = opt.event end
                if opt.serverEvent then o.serverEvent = opt.serverEvent end
                if opt.groups then o.groups = opt.groups end
                if opt.items then o.items = opt.items end

                -- Fallbacks just in case
                if opt.action then
                    o.onSelect = function(actionData)
                        local entity = type(actionData) == 'table' and actionData.entity or actionData
                        opt.action(entity)
                    end
                end
                if opt.job then o.groups = { [opt.job] = 0 } end

                table.insert(oxOptions, o)
            end

            if Config.Debug then
                print('^3[XR-MDT DEBUG]^7 Attempting to register ox_target BoxZone...')
                print('^3[XR-MDT DEBUG]^7 Coords: ' .. tostring(data.coords) .. ' Size: ' .. tostring(data.size))
            end

            local success, err = pcall(function()
                exports.ox_target:addBoxZone({
                    name = name,
                    coords = data.coords,
                    size = data.size,
                    rotation = data.rotation or 0.0,
                    debug = data.debug or Config.Debug,
                    drawSprite = data.debug or Config.Debug,
                    options = oxOptions
                })
            end)

            if not success then
                print('^1[XR-MDT CRITICAL ERROR]^7 ox_target failed to create zone! ERROR: ' .. tostring(err))
            elseif Config.Debug then
                print('^2[XR-MDT DEBUG]^7 Successfully created ox_target BoxZone: ' .. name)
            end
        elseif qbxState == 'started' or qbState == 'started' then
            -- ==========================================
            -- QB-TARGET / QBX_TARGET API
            -- ==========================================
            local qbOptions = {}

            if Config.Debug then
                table.insert(qbOptions, {
                    type = "client",
                    label = "DEBUG: Check Permissions",
                    icon = "fa-solid fa-bug",
                    action = function()
                        local pd = Bridge.GetPlayerData()
                        print("^3[XR-MDT DEBUG]^7 --- Permission Check (" .. name .. ") ---")
                        print("^3[XR-MDT DEBUG]^7 Job:", pd and pd.job and pd.job.name or "None")
                        print("^3[XR-MDT DEBUG]^7 Grade:",
                            pd and pd.job and pd.job.grade and pd.job.grade.level or "None")
                    end
                })
            end

            for _, opt in ipairs(data.options or {}) do
                local o = {
                    type = opt.type or (opt.event and "client" or nil),
                    event = opt.event,
                    action = opt.action or opt.onSelect,
                    icon = opt.icon,
                    label = opt.label,
                    item = opt.item or opt.items
                }

                if opt.job then
                    o.job = opt.job
                elseif opt.groups then
                    o.job = opt.groups
                end

                table.insert(qbOptions, o)
            end

            local height = data.size and data.size.z or 2.0
            local minZ = data.coords.z - (height / 2.0)
            local maxZ = data.coords.z + (height / 2.0)

            local zoneData = {
                name = name,
                heading = data.rotation or 0.0,
                debugPoly = data.debug or Config.Debug,
                minZ = minZ,
                maxZ = maxZ,
            }

            local targetOptions = {
                options = qbOptions,
                distance = data.options and data.options[1] and data.options[1].distance or 2.5
            }

            if Config.Debug then
                print('^3[XR-MDT DEBUG]^7 Attempting to register qbx/qb-target BoxZone...')
            end

            local length = data.size and data.size.y or 1.5
            local width = data.size and data.size.x or 1.5

            if qbxState == 'started' then
                local success, err = pcall(function()
                    exports.qbx_target:AddBoxZone(name, data.coords, length, width, zoneData, targetOptions)
                end)
                if not success then
                    print('^1[XR-MDT CRITICAL ERROR]^7 qbx_target failed! ERROR: ' .. tostring(err))
                elseif Config.Debug then
                    print('^2[XR-MDT DEBUG]^7 Created qbx_target BoxZone: ' .. name)
                end
            else
                local success, err = pcall(function()
                    exports['qb-target']:AddBoxZone(name, data.coords, length, width, zoneData, targetOptions)
                end)
                if not success then
                    print('^1[XR-MDT CRITICAL ERROR]^7 qb-target failed! ERROR: ' .. tostring(err))
                elseif Config.Debug then
                    print('^2[XR-MDT DEBUG]^7 Created qb-target BoxZone: ' .. name)
                end
            end
        end
    end)
end

function Bridge.AddGlobalPlayer(options)
    CreateThread(function()
        Wait(1000)
        local oxState = GetResourceState('ox_target')
        local qbxState = GetResourceState('qbx_target')
        local qbState = GetResourceState('qb-target')

        local finalOptions = options.options or options

        if oxState == 'started' then
            for _, opt in ipairs(finalOptions) do
                if opt.action then
                    local originalAction = opt.action
                    opt.onSelect = function(actionData)
                        local entity = type(actionData) == 'table' and actionData.entity or actionData
                        originalAction(entity)
                    end
                end
            end
            exports.ox_target:addGlobalPlayer(finalOptions)
        elseif qbxState == 'started' then
            exports.qbx_target:AddGlobalPlayer({ options = finalOptions, distance = options.distance or 2.0 })
        elseif qbState == 'started' then
            exports['qb-target']:AddGlobalPlayer({ options = finalOptions, distance = options.distance or 2.0 })
        end
    end)
end

function Bridge.RemoveZone(name)
    if Config.Debug then ActiveZones[name] = nil end
    local oxState = GetResourceState('ox_target')
    local qbxState = GetResourceState('qbx_target')
    local qbState = GetResourceState('qb-target')

    if oxState == 'started' then
        exports.ox_target:removeZone(name)
    elseif qbxState == 'started' then
        exports.qbx_target:RemoveZone(name)
    elseif qbState == 'started' then
        exports['qb-target']:RemoveZone(name)
    end
end

-- --- DEBUG COMMAND & VISUALS ---
if Config.Debug then
    RegisterCommand('mdt_debug', function()
        print('^3--- XR-MDT ACTIVE TARGET ZONES ---^7')
        local count = 0
        for k, v in pairs(ActiveZones) do
            count = count + 1
            print(string.format('^3[%d] Name:^7 %s', count, k))
            print(string.format('^3    Type:^7 %s', v.type))
            print(string.format('^3    Pos:^7 %s', v.coords))
        end
        if count == 0 then print('^1No active zones registered.^7') end
        print('^3---------------------------------^7')
    end, false)

    -- Visual markers for zones in debug mode
    CreateThread(function()
        while true do
            local sleep = 1000
            local pCoords = GetEntityCoords(cache.ped or PlayerPedId())

            local hasZones = false
            for k, v in pairs(ActiveZones) do
                hasZones = true
                local dist = #(pCoords - v.coords)
                if dist < 10.0 then
                    sleep = 0
                    DrawMarker(28, v.coords.x, v.coords.y, v.coords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.2, 0.2, 0.2, 255,
                        255, 0, 150, false, false, 2, nil, nil, false)

                    -- Floating text
                    local screenX, screenY = GetScreenCoordFromWorldCoord(v.coords.x, v.coords.y, v.coords.z + 0.3)
                    if screenX then
                        SetTextScale(0.35, 0.35)
                        SetTextFont(4)
                        SetTextProportional(1)
                        SetTextColour(255, 255, 255, 215)
                        SetTextEntry("STRING")
                        SetTextCentre(1)
                        AddTextComponentString("MDT: " .. k)
                        DrawText(screenX, screenY)
                    end
                end
            end

            if not hasZones then sleep = 2000 end
            Wait(sleep)
        end
    end)
end




-- --- GLOBALNE FUNKCJE EDIT TABLE (ANIMACJE ITP) ---
EditTable = EditTable or {}
EditTable.ClientEvents = EditTable.ClientEvents or {}
EditTable.Functions = EditTable.Functions or {}

EditTable.Functions.ErrorCodes = {
    UI_ERROR = "#ERR-10001",
    CALLBACK_TIMEOUT = "#ERR-10002",
    ANIMATION_ERROR = "#ERR-10003",
    INVALID_PLAYER_DATA = "#ERR-10004",
    UNKNOWN_ERROR = "#ERR-99999",
}

EditTable.Functions.ReportError = function(code, message)
    if not Config.Debug then return end

    local info = debug.getinfo(2, "Sl")
    local file = info.short_src:match("^.+/(.+)$") or info.short_src
    local line = info.currentline

    local formattedMessage = string.format(
        "\n^1[XR-MDT CLIENT ERROR | %s]^7\n^1FILE:^7 %s\n^1LINE:^7 %s\n^1MESSAGE:^7 %s\n",
        code or EditTable.Functions.ErrorCodes.UNKNOWN_ERROR, file, line, message or "No details provided")

    print(formattedMessage)
end

EditTable.ClientEvents.OpenTablet = function()
    -- Animacja wyciągania tabletu z konfigiem (możesz dodać Config.UseAnimations = true żeby móc to wyłączać)
    RequestAnimDict("amb@world_human_seat_wall_tablet@female@base")
    while not HasAnimDictLoaded("amb@world_human_seat_wall_tablet@female@base") do Wait(10) end
    TaskPlayAnim(PlayerPedId(), "amb@world_human_seat_wall_tablet@female@base", "base", 8.0, -8.0, -1, 50, 0, false,
        false, false)
end

EditTable.ClientEvents.CloseTablet = function()
    StopAnimTask(PlayerPedId(), "amb@world_human_seat_wall_tablet@female@base", "base", 1.0)
end

local isTabletOpen = false

local function OpenFactionTablet()
    local PlayerData = Bridge.GetPlayerData()
    if not PlayerData or not PlayerData.job then return end
    if LocalPlayer.state.phoneOpen then return end
    if LocalPlayer.state.invBusy then return end
    if isTabletOpen then return end

    local appType = nil
    local permissions = {}
    local factionConfig = nil

    if PlayerData.job.name == 'ambulance' then
        if not Config.EnableEMS then return end
        appType = 'ems'
        permissions = {
            dashboard_view = true,
            profiles_view = true,
            profiles_edit = true,
            reports_view = true,
            reports_create = true
        }
    elseif PlayerData.job.name == 'doj' then
        if not Config.EnableDOJ then return end
        appType = 'doj'
        local gradeLevel = tostring(PlayerData.job.grade.level)
        if Config.DOJ.Grades and Config.DOJ.Grades[gradeLevel] then
            permissions = Config.DOJ.Grades[gradeLevel].permissions
        else
            permissions = { dashboard_view = true, cases_view = true }
        end
    else
        -- Check if player is in any multi-faction police job
        local jobConfig = Config.PoliceJobs[PlayerData.job.name]
        if jobConfig then
            appType = 'police'
            factionConfig = jobConfig

            local gradeLevel = PlayerData.job.grade.level
            local gradeData = jobConfig.Grades[tostring(gradeLevel)] or jobConfig.Grades[tonumber(gradeLevel)]

            if gradeData then
                permissions = gradeData.permissions
            else
                permissions = {
                    dashboard_view = true,
                    profiles_view = true
                }
            end
        end
    end

    if not appType then return end

    isTabletOpen = true
    LocalPlayer.state:set("invBusy", true, true)
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        type = appType,
        permissions = permissions,
        language = Config.Language,
        factionConfig = factionConfig,
        archivesConfig = Config.Archives,
        locales = Locales[Config.Language] or Locales['en']
    })
    EditTable.ClientEvents.OpenTablet()
end

local function CloseTablet()
    isTabletOpen = false
    LocalPlayer.state:set("invBusy", false, true)
    SetNuiFocus(false, false)
    EditTable.ClientEvents.CloseTablet()
    SendNUIMessage({ action = 'close' })
end

RegisterNUICallback('close', function(data, cb)
    CloseTablet()
    cb('ok')
end)




EditTable.Functions.GetPlayerData = function()
    return Bridge.GetPlayerData()
end

EditTable.Functions.GetJob = function()
    local pd = Bridge.GetPlayerData()
    return pd and pd.job or nil
end

EditTable.Functions.IsOnDuty = function()
    local pd = Bridge.GetPlayerData()
    return pd and pd.job and pd.job.onduty or false
end

-- --- SYSTEM DISPATCH I EXPORTY LOKALNE ---
RegisterNetEvent('xr-mdt:client:newDispatch', function(data)
    SendNUIMessage({
        action = 'addDispatch',
        data = data
    })
end)

local function AddDispatch(data)
    SendNUIMessage({
        action = 'addDispatch',
        data = data
    })
end
exports('AddDispatch', AddDispatch)

--[[
    Odbiera globalną pozycję bodycama z serwera i przekazuje do NUI.
--]]
RegisterNetEvent('xr-mdt:client:bodycam:setPosition', function(x, y)
    SendNUIMessage({
        action = 'bodycamSetPosition',
        x = x,
        y = y
    })
end)

--[[
    Uruchamia tryb przeciągania bodycama w NUI.
    Tylko dla administratorów (weryfikacja po stronie serwera przed wysłaniem eventu).
--]]
RegisterNetEvent('xr-mdt:client:bodycam:enterDragMode', function()
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'bodycamEnterDrag' })
end)

RegisterNUICallback('bodycam:dragEnd', function(data, cb)
    SetNuiFocus(false, false)
    if data and data.x and data.y then
        TriggerServerEvent('xr-mdt:server:bodycam:savePosition', data.x, data.y)
    end
    cb('ok')
end)

local function TriggerDispatch(code, title, description, location, jobs)
    TriggerServerEvent('xr-mdt:server:triggerDispatch', {
        code = code,
        title = title,
        description = description,
        location = location,
        jobs = jobs or { 'police' },
        time = GetGameTimer(),
        sound = 'Lose_1st'
    })
end
exports('TriggerDispatch', TriggerDispatch)

-- --- TŁUMACZENIA I INICJALIZACJA UI ---
CreateThread(function()
    Wait(2000)
    if Config.Language and Locales[Config.Language] then
        SendNUIMessage({
            action = 'setLocales',
            data = Locales[Config.Language]
        })
    end

    Bridge.TriggerCallback('xr-mdt:server:bodycam:getPosition', function(pos)
        if pos and pos.x and pos.y then
            SendNUIMessage({
                action = 'bodycamSetPosition',
                x = pos.x,
                y = pos.y
            })
        end
    end)
end)

RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    if Config.Language and Locales[Config.Language] then
        SendNUIMessage({
            action = 'setLocales',
            data = Locales[Config.Language]
        })
    end
end)

RegisterNetEvent('esx:playerLoaded', function()
    if Config.Language and Locales[Config.Language] then
        SendNUIMessage({
            action = 'setLocales',
            data = Locales[Config.Language]
        })
    end
end)

if Config.Debug then
    print(string.format("^2[XR-MDT CLIENT TRACE]^7 Script Initialized Successfully (Framework: %s)", Config.Framework))
end

-- ============================================================
-- CENTRAL TABLET ACCESS
-- ============================================================

local function ToggleTablet()
    if IsPauseMenuActive() then return end
    if LocalPlayer.state.invBusy then return end
    if Config.Debug then print("[XR-MDT] Access requested via Command/Key") end

    -- Verification if player is loaded (framework specific)
    if not Bridge.IsPlayerLoaded() then
        if Config.Debug then print("[XR-MDT] Access denied: Player not fully loaded") end
        return
    end

    TriggerServerEvent('xr-mdt:server:requestOpenMDT')
end

RegisterCommand(Config.Tablet.Command or 'mdt', function()
    ToggleTablet()
end, false)

CreateThread(function()
    -- Wait for manifest and configs to settle
    Wait(2000)
    RegisterKeyMapping(Config.Tablet.Command or 'mdt', 'Open MDT', 'keyboard', Config.Tablet.Key or 'DELETE')
    if Config.Debug then
        print(string.format("^2[XR-MDT]^7 Key mapping registered: %s (Key: %s)",
            Config.Tablet.Command or 'mdt', Config.Tablet.Key or 'DELETE'))
    end
end)

-- Trigger for external scripts
RegisterNetEvent('xr-mdt:client:toggleTablet', function()
    ToggleTablet()
end)

-- ============================================================
-- CENTRAL SIGNAL ROUTER
-- ============================================================

RegisterNetEvent('xr-mdt:client:open', function(data)
    if not data or not data.type then
        if Config.Debug then print("^1[XR-MDT ERROR]^7 Received open signal with invalid data.") end
        return
    end

    if Config.Debug then print(string.format("[XR-MDT] SIGNAL RECEIVED: Routing to app type '%s'...", data.type)) end

    -- Route to the correct faction-standard internal events
    if data.type == 'business' or data.type == 'firma' then
        if LocalPlayer.state.invBusy then return end
        LocalPlayer.state:set("invBusy", true, true)
        TriggerEvent('xr-mdt:client:openBusinessTablet')
    else
        -- This covers police, ambulance, doj, and other faction-hub apps
        OpenFactionTablet()
    end
end)

--[[
    Runs a minigame (default ox_lib skill check) when trying to remove a GPS tracking band.
    Calls cb(success) with the outcome.
--]]
EditTable.Functions.RunTrackingMinigame = function(cb)
    local success = lib.skillCheck({ 'easy', 'medium', 'medium' }, { 'w', 'a', 's', 'd' })
    cb(success)
end

--[[
    Checks if the target player is cuffed.
    Supports QB, ESX, and generic animation fallbacks.
--]]
EditTable.Functions.IsPlayerCuffed = function(targetPed, targetServerId)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local targetState = Player(targetServerId).state
        if targetState and targetState.isHandcuffed then
            return true
        end
    elseif Config.Framework == 'esx' then
        local targetState = Player(targetServerId).state
        if targetState and (targetState.isHandcuffed or targetState.handcuffed) then
            return true
        end
    end
    if IsEntityPlayingAnim(targetPed, "mp_arresting", "idle", 3) or
        IsEntityPlayingAnim(targetPed, "mp_arrest_paired", "crook_bound_idle", 3) or
        IsEntityPlayingAnim(targetPed, "anim@move_m@prisoner_cuffed", "idle", 3) then
        return true
    end
    return false
end

-- ============================================================
-- CLIENT EXPORTS FOR ITEMS (OX_INVENTORY)
-- Returning false prevents item consumption.
-- ============================================================

local function HandleGPSUse()
    local pd = Bridge.GetPlayerData()
    if not pd or not pd.job then return false end

    local allowed = false
    if Config.IsEnforcementJob(pd.job.name) or Config.IsMedicalJob(pd.job.name) or pd.job.name == "doj" then
        allowed = true
    end

    if not allowed then
        Bridge.Notify((Locales[Config.Language] or Locales['en']).gps.unauthorized, 'error')
        return false
    end

    TriggerServerEvent('xr-mdt:server:toggle:gps')
    return false
end

exports('gps', function(data, slot)
    TriggerEvent('xr-mdt:client:useGPSItem')
    return false
end)

RegisterNetEvent('xr-mdt:client:gpsToggleSound', function()
    SendNUIMessage({
        action = 'playSound',
        data = { file = 'axon', volume = 0.5 }
    })
end)

-- Used by QBCore/ESX server-side RegisterUsableItem if ox_inventory is not handling it via export
RegisterNetEvent('xr-mdt:client:useGPSItem', function()
    HandleGPSUse()
end)

exports('bodycam', function(data, slot)
    TriggerServerEvent('xr-mdt:server:toggle:bodycam')
    return false
end)


exports('tablet', function(data, slot)
    TriggerServerEvent('xr-mdt:server:requestOpenMDT')
    return false
end)
