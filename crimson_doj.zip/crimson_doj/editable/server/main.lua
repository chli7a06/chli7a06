local OxInventory = nil

function GetLocale(path)
    if not path then return nil end
    local keys = {}
    for key in path:gmatch("([^%.]+)") do
        table.insert(keys, key)
    end

    local current = Locales[Config.Language] or Locales['en']
    if not current then return nil end

    for _, key in ipairs(keys) do
        if type(current) == 'table' and current[key] then
            current = current[key]
        else
            return nil
        end
    end
    return current
end

EditTable = EditTable or {}
EditTable.Functions = EditTable.Functions or {}
EditTable.LSPD = EditTable.LSPD or {}
EditTable.LSPD.Functions = EditTable.LSPD.Functions or {}

EditTable.Functions.ErrorCodes = {
    DATABASE_ERROR = "#ERR-00001",
    PLAYER_NOT_FOUND = "#ERR-00002",
    INSUFFICIENT_FUNDS = "#ERR-00003",
    INVALID_JOB = "#ERR-00004",
    ITEM_NOT_FOUND = "#ERR-00005",
    PERMISSION_DENIED = "#ERR-00006",
    UNKNOWN_ERROR = "#ERR-99999",
}

EditTable.Functions.ReportError = function(code, message)
    if not Config.Debug then return end

    local info = debug.getinfo(2, "Sl")
    local file = info.short_src:match("^.+/(.+)$") or info.short_src
    local line = info.currentline

    local formattedMessage = string.format("\n^1[XR-MDT ERROR | %s]^7\n^1FILE:^7 %s\n^1LINE:^7 %s\n^1MESSAGE:^7 %s\n",
        code or EditTable.Functions.ErrorCodes.UNKNOWN_ERROR, file, line, message or "No details provided")

    print(formattedMessage)

    -- Optionally send to Discord too
    if Config.Webhooks.Main ~= "" then
        EditTable.Functions.SendDebug("System", "ERROR REPORTED", formattedMessage, "Commands")
    end
end

EditTable.Functions.SendDebug = function(category, title, message, debugType, fields)
    if not Config.Debug then return end

    -- Console Trace is now tied directly to Config.Debug
    print(string.format("^2[XR-MDT TRACE | %s]^7 %s: %s", category, title, message:gsub("\n", " | ")))

    local catData = Config.Webhooks.Categories[category]

    -- Determine webhook (Priority: Type > JobCategory > Main)
    local webhook = Config.Webhooks.Types[debugType]
    if not webhook or webhook == "" then
        webhook = Config.Webhooks.Jobs[category]
    end
    if not webhook or webhook == "" then
        webhook = Config.Webhooks.Main
    end

    if not webhook or webhook == "" then
        -- Silent return if no webhook configured
        return
    end

    local embed = {
        {
            ["title"] = (catData and catData.Title or "DEBUG") .. " - " .. title,
            ["description"] = message,
            ["type"] = "rich",
            ["color"] = catData and catData.Color or 16777215,
            ["fields"] = fields or {},
            ["footer"] = {
                ["text"] = "XR-MDT Debug System • " .. os.date("%Y-%m-%d %H:%M:%S"),
            },
        }
    }

    PerformHttpRequest(webhook, function(err, text, headers) end, 'POST',
        json.encode({ username = "XR-MDT Debug", embeds = embed }), { ['Content-Type'] = 'application/json' })
end

if GetResourceState('ox_inventory') == 'started' then
    OxInventory = exports.ox_inventory
end

if Config.Framework == 'qb' or Config.Framework == 'qbox' then
    QBCore = exports['qb-core']:GetCoreObject()
elseif Config.Framework == 'esx' then
    ESX = exports['es_extended']:getSharedObject()

    MySQL.ready(function()
        local checkSsn = MySQL.query.await("SHOW COLUMNS FROM users LIKE 'ssn'")
        if not checkSsn or #checkSsn == 0 then
            print('^1[XR-MDT] ERROR: Database schema is incompatible!^7')
            print('^1Missing column in users: ssn^7')
            print(
                '^1Please follow the documentation or import INSTALL/database_esx.sql: https://docs.xr-core.pl/^7')
        end

        local checkCharid = MySQL.query.await("SHOW COLUMNS FROM users LIKE 'charid'")
        if not checkCharid or #checkCharid == 0 then
            print('^1[XR-MDT] ERROR: Database schema is incompatible!^7')
            print('^1Missing column in users: charid^7')
            print(
                '^1Please follow the documentation or import INSTALL/database_esx.sql: https://docs.xr-core.pl/^7')
        end

        if checkSsn and #checkSsn > 0 then
            local usersWithoutSsn = MySQL.query.await(
                "SELECT identifier FROM users WHERE ssn IS NULL OR ssn = ''")
            if usersWithoutSsn and #usersWithoutSsn > 0 then
                for _, user in ipairs(usersWithoutSsn) do
                    local newSsn = EditTable.LSPD.Functions.GenerateSSN()
                    MySQL.query.await("UPDATE users SET ssn = ? WHERE identifier = ?",
                        { newSsn, user.identifier })
                end
            end
        end
    end)

    RegisterNetEvent('esx:playerLoaded', function(playerId, xPlayer)
        local hasSsn = MySQL.scalar.await("SELECT ssn FROM users WHERE identifier = ?", { xPlayer.identifier })
        if not hasSsn or hasSsn == '' then
            local newSsn = EditTable.LSPD.Functions.GenerateSSN()
            MySQL.query.await("UPDATE users SET ssn = ? WHERE identifier = ?", { newSsn, xPlayer.identifier })
        end

        local hasCharId = MySQL.scalar.await("SELECT charid FROM users WHERE identifier = ?", { xPlayer.identifier })
        -- if not hasCharId or hasCharId == '' then
        --     MySQL.query.await("UPDATE users SET charid = ? WHERE identifier = ?", { xPlayer.identifier, xPlayer.identifier })
        -- end
    end)
elseif Config.Framework == 'qbox' then
    QBCore = exports['qb-core']:GetCoreObject()
end

-- Deprecated legacy log removed in favor of v2.0 Splash Screen

local function NormalizeESXJob(job, source)
    if not job then return nil end
    if type(job.grade) == 'number' or type(job.grade) == 'string' then
        local normJob = {}
        for k, v in pairs(job) do
            normJob[k] = v
        end
        local gradeLevel = tonumber(job.grade) or 0
        normJob.original_grade = job.grade
        normJob.grade = {
            level = gradeLevel,
            name = job.grade_label or job.grade_name or tostring(gradeLevel)
        }
        normJob.isboss = (job.grade_name == 'boss')

        if Config.Framework == 'esx' and Config.ESXDuty and source then
            normJob.onduty = GetESXDutyStatus(source)
        else
            normJob.onduty = true
        end

        return normJob
    end
    return job
end

Bridge = {}

-- --- EXPORTY ZEWNTRZNE (FRAMEWORK, NOTIFY, HAS MONEY ETC.) ---
function Bridge.GetPlayer(source)
    if Config.Framework == 'qbox' then
        return exports.qbx_core:GetPlayer(source)
    elseif Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return QBCore.Functions.GetPlayer(source)
    elseif Config.Framework == 'esx' then
        return ESX.GetPlayerFromId(source)
    end
    return nil
end

function Bridge.GetJob(source)
    local player = Bridge.GetPlayer(source)
    if not player then return nil end

    local job = nil
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        job = player.PlayerData.job
    elseif Config.Framework == 'esx' then
        job = NormalizeESXJob(player.job, source)
    end

    if Config.Debug then
        EditTable.Functions.SendDebug("System", "Get Job",
            string.format("Source: %s\nJob: %s\nGrade: %s", source, job and job.name or "None",
                job and (job.grade.name or job.grade.level) or "N/A"), "JobChange")
    end

    return job
end

function Bridge.Notify(source, text, notifyType, length)
    local notifyData = {}
    if type(text) == 'table' then
        notifyData = text
        text = notifyData.description or notifyData.text or ""
        notifyType = notifyData.type or notifyType or 'info'
        length = notifyData.duration or notifyData.length or length or 5000
    else
        notifyType = notifyType or 'info'
        length = length or 5000
        notifyData = {
            description = text,
            type = notifyType,
            duration = length
        }
    end

    if Config.Framework == 'qbox' or Config.Notify.Type == 'ox' then
        TriggerClientEvent('ox_lib:notify', source, notifyData)
    elseif Config.Notify.Type == 'qb' then
        local displayMsg = text
        if notifyData.title then
            displayMsg = "[" .. notifyData.title .. "] " .. text
        end
        TriggerClientEvent('QBCore:Notify', source, displayMsg, notifyType, length)
    elseif Config.Notify.Type == 'esx' then
        local displayMsg = text
        if notifyData.title then
            displayMsg = "~y~~h~" .. notifyData.title .. "~h~~w~\n" .. text
        end
        TriggerClientEvent('esx:showNotification', source, displayMsg)
    end
end

function Bridge.GetMoney(source, type)
    local player = Bridge.GetPlayer(source)
    if not player then return 0 end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return player.Functions.GetMoney(type)
    elseif Config.Framework == 'esx' then
        if type == 'cash' then type = 'money' end
        local account = player.getAccount(type)
        return account and account.money or 0
    end
    return 0
end

function Bridge.AddMoney(source, type, amount)
    local player = Bridge.GetPlayer(source)
    if not player then return false end

    local success = false
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        success = player.Functions.AddMoney(type, amount)
    elseif Config.Framework == 'esx' then
        if type == 'cash' then type = 'money' end
        player.addAccountMoney(type, amount)
        success = true
    end

    if Config.Debug then
        EditTable.Functions.SendDebug("System", "Add Money",
            string.format("Source: %s\nType: %s\nAmount: %s\nSuccess: %s", source, type, amount, success), "Money")
    end

    return success
end

function Bridge.RemoveMoney(source, type, amount)
    local player = Bridge.GetPlayer(source)
    if not player then return false end

    local success = false
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        success = player.Functions.RemoveMoney(type, amount)
    elseif Config.Framework == 'esx' then
        if type == 'cash' then type = 'money' end
        if player.getAccount(type).money >= amount then
            player.removeAccountMoney(type, amount)
            success = true
        end
    end

    if Config.Debug then
        EditTable.Functions.SendDebug("System", "Remove Money",
            string.format("Source: %s\nType: %s\nAmount: %s\nSuccess: %s", source, type, amount, success), "Money")
    end

    return success
end

function Bridge.GetItem(source, item)
    if OxInventory then
        return OxInventory:GetItem(source, item, nil, false)
    end
    local player = Bridge.GetPlayer(source)
    if not player then return nil end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return player.Functions.GetItemByName(item)
    elseif Config.Framework == 'esx' then
        return player.getInventoryItem(item)
    end
    return nil
end

function Bridge.GetItemCount(source, item)
    if OxInventory then
        return OxInventory:GetItemCount(source, item, nil, false)
    end
    local data = Bridge.GetItem(source, item)
    if not data then return 0 end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return data.amount or data.count or 0
    elseif Config.Framework == 'esx' then
        return data.count or 0
    end
    return 0
end

function Bridge.AddItem(source, item, count, slot, metadata)
    local success = false
    if OxInventory then
        local ok, response = OxInventory:AddItem(source, item, count, metadata, slot or false)
        if Config.Debug then
            EditTable.Functions.SendDebug("System", "OxInventory AddItem",
                string.format("Source: %s | Item: %s | Count: %s | OK: %s | Response: %s",
                    source, item, count, tostring(ok), tostring(type(response) == 'table' and response.slot or response)), "Items")
        end
        success = ok == true
    else
        local player = Bridge.GetPlayer(source)
        if player then
            if Config.Framework == 'qb' or Config.Framework == 'qbox' then
                local result = player.Functions.AddItem(item, count, slot or false, metadata)
                success = result == true or result ~= nil
            elseif Config.Framework == 'esx' then
                player.addInventoryItem(item, count, metadata, slot)
                success = true
            end
        end
    end

    if Config.Debug then
        EditTable.Functions.SendDebug("System", "Add Item",
            string.format("Source: %s\nItem: %s\nCount: %s\nSuccess: %s", source, item, count, tostring(success)), "Items")
    end

    return success
end

function Bridge.RemoveItem(source, item, count, slot)
    local success = false
    if OxInventory then
        success = OxInventory:RemoveItem(source, item, count, nil, slot)
    else
        local player = Bridge.GetPlayer(source)
        if player then
            if Config.Framework == 'qb' or Config.Framework == 'qbox' then
                success = player.Functions.RemoveItem(item, count, slot)
            elseif Config.Framework == 'esx' then
                player.removeInventoryItem(item, count, slot)
                success = true
            end
        end
    end

    if Config.Debug then
        EditTable.Functions.SendDebug("System", "Remove Item",
            string.format("Source: %s\nItem: %s\nCount: %s\nSuccess: %s", source, item, count, success), "Items")
    end

    return success
end

Bridge.Bank = {}

--[[
    Pobiera dane konta bankowego gracza oraz historię jego transakcji.
    Obsługuje integrację ze skryptem snipe-banking oraz standardowy fallback.
--]]
function Bridge.Bank.GetPlayerBankDetails(citizenId)
    local balance = 0
    local targetPlayer = Bridge.GetPlayerByCitizenId(citizenId)
    if targetPlayer then
        if Config.Framework == 'qb' or Config.Framework == 'qbox' then
            balance = targetPlayer.Functions.GetMoney('bank') or 0
        elseif Config.Framework == 'esx' then
            local account = targetPlayer.getAccount('bank')
            balance = account and account.money or 0
        end
    else
        if Config.Framework == 'qb' or Config.Framework == 'qbox' then
            local result = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', { citizenId })
            if result and result.money then
                local money = json.decode(result.money)
                balance = money and money.bank or 0
            end
        elseif Config.Framework == 'esx' then
            local result = MySQL.single.await('SELECT bank FROM users WHERE identifier = ?', { citizenId })
            if result then
                balance = result.bank or 0
            end
        end
    end

    local bankAccounts = {}
    local personalAcc = {
        id = citizenId,
        label = GetLocale('doj.businesses.personal_bank') or 'Konto osobiste',
        balance = balance,
        type = 'checking'
    }

    local transactions = {}

    if GetResourceState('snipe-banking') == 'started' then
        local result = MySQL.single.await("SELECT unique_id FROM banking_users WHERE identifier = ? AND type = 'personal'", { citizenId })
        if result and result.unique_id then
            personalAcc.id = result.unique_id
        end

        local rows = MySQL.query.await([[
            SELECT id, amount, transaction_type as type, memo as title, created_at as date, unique_id as account
            FROM banking_transactions
            WHERE unique_id = ?
            ORDER BY created_at DESC LIMIT 20
        ]], { personalAcc.id }) or {}

        for _, r in ipairs(rows) do
            local rawDate = r.date
            local formattedDate = tostring(rawDate)
            if type(rawDate) == 'number' then
                if rawDate > 1000000000000 then
                    rawDate = rawDate / 1000
                end
                formattedDate = os.date('%Y-%m-%d %H:%M', math.floor(rawDate))
            end

            table.insert(transactions, {
                id = r.id,
                account = r.account,
                type = r.type,
                amount = r.amount,
                title = r.title or "Transaction",
                date = formattedDate
            })
        end
    else
        local status, rows = pcall(function()
            return MySQL.query.await([[
                SELECT id, amount, statement_type as type, reason as title, date, account_name as account
                FROM bank_statements
                WHERE account_name = ?
                ORDER BY date DESC LIMIT 20
            ]], { citizenId })
        end)
        if status and rows then
            for _, r in ipairs(rows) do
                local rawDate = r.date
                local formattedDate = tostring(rawDate)
                if type(rawDate) == 'number' then
                    if rawDate > 1000000000000 then
                        rawDate = rawDate / 1000
                    end
                    formattedDate = os.date('%Y-%m-%d %H:%M', math.floor(rawDate))
                end
                table.insert(transactions, {
                    id = r.id,
                    account = r.account,
                    type = r.type,
                    amount = r.amount,
                    title = r.title or "Transaction",
                    date = formattedDate
                })
            end
        end
    end

    table.insert(bankAccounts, personalAcc)
    return {
        bankAccounts = bankAccounts,
        transactions = transactions
    }
end

function Bridge.Bank.GetBalance(accountName)
    if not accountName or accountName == "" then return 0 end
    if GetResourceState('snipe-banking') == 'started' then
        local balance = exports['snipe-banking']:GetAccountBalance(accountName)
        if balance == false or balance == nil then
            pcall(function()
                exports['snipe-banking']:CreateJobGangAccount(accountName, accountName, 0, true)
            end)
            return 0
        end
        return balance
    end

    if GetResourceState('Renewed-Banking') == 'started' then
        local amount = exports['Renewed-Banking']:getAccountMoney(accountName)
        return amount or 0
    end

    if GetResourceState('xr-bank') == 'started' then
        return exports['xr-bank']:GetAccountBalance(accountName) or 0
    end

    if Config.Framework == 'qbox' and GetResourceState('qbx_management') == 'started' then
        return exports['qbx_management']:GetAccount(accountName).amount or 0
    end

    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        if GetResourceState('qb-banking') == 'started' then
            return exports['qb-banking']:GetAccountBalance(accountName)
        elseif GetResourceState('qb-management') == 'started' then
            local amount = nil
            TriggerEvent('qb-management:server:GetAccount', accountName, function(balance)
                amount = balance
            end)
            return amount or 0
        end
    elseif Config.Framework == 'esx' then
        local society = accountName:find("society_") and accountName or "society_" .. accountName
        
        -- Try exports first (Legacy/Modern ESX)
        if GetResourceState('esx_addonaccount') == 'started' then
            local account = exports['esx_addonaccount']:GetSharedAccount(society)
            if account then return account.money or 0 end
        end

        -- Fallback to TriggerEvent
        local result = nil
        TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
            result = account
        end)
        return result and result.money or 0
    end
    return 0
end

function Bridge.Bank.AddMoney(accountName, amount, reason)
    local success = false

    if GetResourceState('snipe-banking') == 'started' then
        success = exports['snipe-banking']:AddMoneyToAccount(accountName, amount)
        if not success then
            pcall(function()
                exports['snipe-banking']:CreateJobGangAccount(accountName, accountName, 0, true)
                success = exports['snipe-banking']:AddMoneyToAccount(accountName, amount)
            end)
        end
        if success == nil then success = true end
    elseif GetResourceState('Renewed-Banking') == 'started' then
        success = exports['Renewed-Banking']:addAccountMoney(accountName, amount)
    elseif GetResourceState('xr-bank') == 'started' then
        success = exports['xr-bank']:AddMoney(accountName, amount)
    elseif Config.Framework == 'qbox' and GetResourceState('qbx_management') == 'started' then
        exports['qbx_management']:AddMoney(accountName, amount)
        success = true
    elseif Config.Framework == 'qb' or Config.Framework == 'qbox' then
        if GetResourceState('qb-banking') == 'started' then
            exports['qb-banking']:AddMoney(accountName, amount)
            success = true
        elseif GetResourceState('qb-management') == 'started' then
            TriggerEvent('qb-management:server:AddMoney', accountName, amount)
            success = true
        end
    elseif Config.Framework == 'esx' then
        local society = accountName:find("society_") and accountName or "society_" .. accountName
        
        if GetResourceState('esx_addonaccount') == 'started' then
            local account = exports['esx_addonaccount']:GetSharedAccount(society)
            if account then 
                account.addMoney(amount)
                success = true
            end
        end

        if not success then
            TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
                if account then
                    account.addMoney(amount)
                    success = true
                end
            end)
        end
    end

    if success then
        MySQL.insert('INSERT INTO bank_statements (account_name, amount, statement_type, reason) VALUES (?, ?, ?, ?)',
            { accountName, amount, 'deposit', reason or 'MDT Transaction' })
    end

    return success
end

function Bridge.Bank.RemoveMoney(accountName, amount, reason)
    local success = false

    if GetResourceState('snipe-banking') == 'started' then
        success = exports['snipe-banking']:RemoveMoneyFromAccount(accountName, amount)
        if not success then
            pcall(function()
                exports['snipe-banking']:CreateJobGangAccount(accountName, accountName, 0, true)
                success = exports['snipe-banking']:RemoveMoneyFromAccount(accountName, amount)
            end)
        end
        if success == nil then success = true end
    elseif GetResourceState('Renewed-Banking') == 'started' then
        success = exports['Renewed-Banking']:removeAccountMoney(accountName, amount)
    elseif GetResourceState('xr-bank') == 'started' then
        success = exports['xr-bank']:RemoveMoney(accountName, amount)
    elseif Config.Framework == 'qbox' and GetResourceState('qbx_management') == 'started' then
        exports['qbx_management']:RemoveMoney(accountName, amount)
        success = true
    elseif Config.Framework == 'qb' or Config.Framework == 'qbox' then
        if GetResourceState('qb-banking') == 'started' then
            exports['qb-banking']:RemoveMoney(accountName, amount)
            success = true
        elseif GetResourceState('qb-management') == 'started' then
            TriggerEvent('qb-management:server:RemoveMoney', accountName, amount)
            success = true
        end
    elseif Config.Framework == 'esx' then
        local society = accountName:find("society_") and accountName or "society_" .. accountName
        
        if GetResourceState('esx_addonaccount') == 'started' then
            local account = exports['esx_addonaccount']:GetSharedAccount(society)
            if account then 
                account.removeMoney(amount)
                success = true
            end
        end

        if not success then
            TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
                if account then
                    account.removeMoney(amount)
                    success = true
                end
            end)
        end
    end

    if success then
        MySQL.insert('INSERT INTO bank_statements (account_name, amount, statement_type, reason) VALUES (?, ?, ?, ?)',
            { accountName, amount, 'withdraw', reason or 'MDT Transaction' })
    end

    return success
end

function Bridge.GetCitizenId(player)
    if not player then return nil end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return player.PlayerData.citizenid
    elseif Config.Framework == 'esx' then
        return player.identifier
    end
end

function Bridge.GetCharInfo(player)
    if not player then
        return {
            firstname = (Locales[Config.Language] or Locales['en']).system.unknown,
            lastname = (Locales[Config.Language] or Locales['en'])
                .system.unknown,
            phone = '000'
        }
    end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return player.PlayerData.charinfo
    elseif Config.Framework == 'esx' then
        return {
            firstname = player.get('firstName') or (Locales[Config.Language] or Locales['en']).system.unknown,
            lastname = player.get('lastName') or (Locales[Config.Language] or Locales['en']).system.unknown,
            phone = player.get(Config.ESXPhoneNumberColumn or 'phoneNumber') or "000-000"
        }
    end
end

function Bridge.GetCitizenName(citizenId)
    if not citizenId then return (Locales[Config.Language] or Locales['en']).system.unknown end

    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local result = MySQL.single.await('SELECT charinfo FROM players WHERE citizenid = ?', { citizenId })
        if result and result.charinfo then
            local charinfo = json.decode(result.charinfo)
            return (charinfo.firstname or "Unknown") .. " " .. (charinfo.lastname or "Unknown")
        end
    elseif Config.Framework == 'esx' then
        local result = MySQL.single.await('SELECT firstname, lastname FROM users WHERE identifier = ?', { citizenId })
        if result then
            return (result.firstname or "Unknown") .. " " .. (result.lastname or "Unknown")
        end
    end
    return (Locales[Config.Language] or Locales['en']).system.unknown
end


function Bridge.GetMetaData(player, key)
    if not player then return nil end
    if type(player) == 'number' then
        player = Bridge.GetPlayer(player)
    end
    if not player then return nil end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return player.PlayerData.metadata[key]
    elseif Config.Framework == 'esx' then
        return player.get(key)
    end
end

function Bridge.SetMetaData(player, key, value)
    if not player then return end
    if type(player) == 'number' then
        player = Bridge.GetPlayer(player)
    end
    if not player then return end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        player.Functions.SetMetaData(key, value)
    elseif Config.Framework == 'esx' then
        player.set(key, value)
    end
end

function Bridge.CreateCallback(name, handler)
    if Config.Framework == 'qbox' or Config.Framework == 'qb' then
        lib.callback.register(name, function(source, ...)
            local p = promise.new()
            handler(source, function(...)
                p:resolve({ ... })
            end, ...)
            local result = Citizen.Await(p)
            return table.unpack(result)
        end)
    elseif Config.Framework == 'esx' then
        ESX.RegisterServerCallback(name, function(source, cb, ...)
            handler(source, cb, ...)
        end)
    end
end

function Bridge.RegisterUsableItem(name, handler)
    if Config.Framework == 'qbox' then
        exports.qbx_core:CreateUseableItem(name, handler)
    elseif Config.Framework == 'qb' or Config.Framework == 'qbox' then
        QBCore.Functions.CreateUseableItem(name, handler)
    elseif Config.Framework == 'esx' then
        ESX.RegisterUsableItem(name, handler)
    end
end

function Bridge.GetPlayers()
    if Config.Framework == 'qbox' then
        return exports.qbx_core:GetQBPlayers()
    elseif Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return QBCore.Functions.GetQBPlayers()
    elseif Config.Framework == 'esx' then
        return ESX.GetExtendedPlayers()
    end
    return {}
end

function Bridge.GetSource(player)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return player.PlayerData.source
    elseif Config.Framework == 'esx' then
        return player.source
    end
end

function Bridge.GetJobFromObject(player)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return player.PlayerData.job
    elseif Config.Framework == 'esx' then
        return NormalizeESXJob(player.job, player.source)
    end
end

function Bridge.GetCitizenIdFromObject(player)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return player.PlayerData.citizenid
    elseif Config.Framework == 'esx' then
        return player.identifier
    end
end

function Bridge.GetPlayerByCitizenId(citizenId)
    if Config.Framework == 'qbox' then
        return exports.qbx_core:GetPlayerByCitizenId(citizenId)
    elseif Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return QBCore.Functions.GetPlayerByCitizenId(citizenId)
    elseif Config.Framework == 'esx' then
        local xPlayers = ESX.GetExtendedPlayers()
        for _, xPlayer in pairs(xPlayers) do
            if xPlayer.identifier == citizenId then
                return xPlayer
            end
        end
    end
    return nil
end

function Bridge.SetJob(player, job, grade)
    if not player then return end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        player.Functions.SetJob(job, grade)
    elseif Config.Framework == 'esx' then
        player.setJob(job, grade)
    end

    if Config.Debug then
        EditTable.Functions.SendDebug("System", "Set Job",
            string.format("Source: %s\nIdentifier: %s\nNew Job: %s\nGrade: %s", player.source or player.PlayerData.source,
                Bridge.GetCitizenId(player), job, grade), "JobChange")
    end
end

function Bridge.SetJobDuty(player, state)
    if not player then return end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        player.Functions.SetJobDuty(state)
    elseif Config.Framework == 'esx' then
        if Config.ESXDuty then
            SetESXDutyStatus(player.source, state)
            TriggerClientEvent('xr-mdt:client:updateDuty', player.source, state and 1 or 3)
            TriggerClientEvent('esx:showNotification', player.source,
                state and (Locales[Config.Language] or Locales['en']).system.duty_on or
                (Locales[Config.Language] or Locales['en']).system.duty_off)
        end
    end

    if Config.Debug then
        EditTable.Functions.SendDebug("System", "Set Duty",
            string.format("Source: %s\nIdentifier: %s\nState: %s", player.source or player.PlayerData.source,
                Bridge.GetCitizenId(player), state), "Duty")
    end
end

function Bridge.Save(player)
    if not player then return end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        player.Functions.Save()
    elseif Config.Framework == 'esx' then

    end
end

function Bridge.JailPlayer(source, time)
    if not source or source <= 0 then return end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        if GetResourceState('xr-jail') == 'started' then
            exports['xr-jail']:JailPlayer(source, time)
        elseif GetResourceState('qb-prison') == 'started' then
            TriggerEvent('qb-prison:server:SetJailStatus', source, time)
        end
    elseif Config.Framework == 'esx' then
        TriggerEvent('esx_jail:sendToJail', source, time * 60)
    end
end

function Bridge.DeductMoneyByCitizenId(citizenId, type, amount, reason)
    local targetPlayer = Bridge.GetPlayerByCitizenId(citizenId)
    if targetPlayer then
        -- Online
        return Bridge.RemoveMoney(Bridge.GetSource(targetPlayer), type, amount)
    else
        -- Offline
        if Config.Framework == 'qb' or Config.Framework == 'qbox' then
            local player = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', { citizenId })
            if player then
                local money = json.decode(player.money)
                money[type] = (money[type] or 0) - amount
                return MySQL.update.await('UPDATE players SET money = ? WHERE citizenid = ?', { json.encode(money), citizenId }) > 0
            end
        elseif Config.Framework == 'esx' then
            if type == 'cash' then type = 'money' end
            local account = type == 'money' and 'money' or 'bank'
            -- ESX offline money is usually in users table (money/bank columns) or accounts table.
            -- Using a generic query for typical ESX setups.
            local query = string.format('UPDATE users SET %s = %s - ? WHERE identifier = ?', type, type)
            return MySQL.update.await(query, { amount, citizenId }) > 0
        end
    end
    return false
end


function Bridge.OnPlayerLoaded(handler)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        RegisterNetEvent('QBCore:Server:PlayerLoaded', function(Player)
            handler(Player.PlayerData.source, Player)
        end)
    elseif Config.Framework == 'esx' then
        RegisterNetEvent('esx:playerLoaded', function(playerId, xPlayer)
            handler(playerId, xPlayer)
        end)
    end
end

function Bridge.IsOnDuty(player)
    if not player then return false end
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return player.PlayerData.job.onduty
    elseif Config.Framework == 'esx' then
        if Config.ESXDuty then
            return GetESXDutyStatus(player.source)
        end
        return true
    end
    return false
end

function Bridge.RegisterCommand(name, help, arguments, restricted, handler)
    local wrappedHandler = function(source, args)
        if Config.Debug then
            EditTable.Functions.SendDebug("System", "Command Used",
                string.format("Source: %s\nCommand: %s\nArgs: %s", source, name, json.encode(args)), "Commands")
        end
        handler(source, args)
    end

    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        QBCore.Commands.Add(name, help, arguments, restricted, wrappedHandler)
    elseif Config.Framework == 'esx' then
        local group = 'user'
        if restricted == true then group = 'admin' end
        if type(restricted) == 'string' then group = restricted end

        ESX.RegisterCommand(name, group, function(xPlayer, args, showError)
            wrappedHandler(xPlayer.source, args)
        end, true, { help = help, arguments = arguments })
    end
end

function Bridge.UpdateVehicleOwner(plate, targetCitizenId)
    local VehiclesTable = (Config.Framework == 'qb' or Config.Framework == 'qbox') and 'player_vehicles' or
        'owned_vehicles'
    local OwnerColumn = (Config.Framework == 'qb' or Config.Framework == 'qbox') and 'citizenid' or 'owner'

    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local targetLicense = nil
        local targetPlayer = Bridge.GetPlayerByCitizenId(targetCitizenId)

        if targetPlayer then
            targetLicense = targetPlayer.PlayerData.license
        else
            local result = MySQL.single.await('SELECT license FROM players WHERE citizenid = ?', { targetCitizenId })
            if result then targetLicense = result.license end
        end

        if targetLicense then
            local query = 'UPDATE player_vehicles SET citizenid = ?, license = ? WHERE plate = ?'
            return MySQL.update.await(query, { targetCitizenId, targetLicense, plate })
        end
    end

    local query = string.format('UPDATE %s SET %s = ? WHERE plate = ?', VehiclesTable, OwnerColumn)
    return MySQL.update.await(query, { targetCitizenId, plate })
end

-- --- EditTable Server Events (DO EDYCJI PRZEZ UYTKOWNIKA W POTRZEBIE) ---
EditTable.Events = EditTable.Events or {}

--[[
    Called when the script needs to remove money
--]]
EditTable.Events.RemoveMoney = function(source, type, amount)
    return Bridge.RemoveMoney(source, type, amount)
end

--[[
    Called to check if player has an item
--]]
EditTable.Events.HasItem = function(source, item, count)
    local owned = Bridge.GetItemCount(source, item)
    return owned >= (count or 1)
end

--[[
    Database Customization
--]]
EditTable.Events.Query = function(query, params)
    if Config.Debug then
        EditTable.Functions.SendDebug("System", "Database Query",
            string.format("Query: %s\nParams: %s", query, json.encode(params)), "Database")
    end
    local status, result = pcall(function()
        return MySQL.query.await(query, params)
    end)

    if not status then
        EditTable.Functions.ReportError(EditTable.Functions.ErrorCodes.DATABASE_ERROR,
            string.format("Query Failed: %s\nError: %s", query, result))
        return {}
    end
    return result
end

--[[
    Dispatch Logic Customizable Sender
--]]
EditTable.Events.SendDispatch = function(data)
    local jobs = data.jobs or { 'police' }
    local players = GetPlayers()

    for _, src in pairs(players) do
        src = tonumber(src)
        local playerJob = Bridge.GetJob(src)

        if playerJob and playerJob.onduty then
            local jobName = playerJob.name
            for _, targetJob in pairs(jobs) do
                if jobName == targetJob then
                    TriggerClientEvent('xr-mdt:client:newDispatch', src, data)
                    break
                end
            end
        end
    end
end

-- Bridge Event Listeners for Dispatch
RegisterNetEvent('xr-mdt:server:triggerDispatch', function(data)
    if not data or not data.title then return end
    EditTable.Events.SendDispatch(data)
end)

RegisterNetEvent('xr-mdt:server:triggerNotification', function(text, type, length)
    local src = source
    Bridge.Notify(src, text, type, length)
end)

-- --- FUNKCJE POBIERANIA DANYCH DLA SKRYPTU ---
EditTable.Functions = EditTable.Functions or {}

EditTable.Functions.GetPlayer = function(source)
    return Bridge.GetPlayer(source)
end

EditTable.Functions.GetJob = function(source)
    return Bridge.GetJob(source)
end

EditTable.Functions.IsOnDuty = function(source)
    local job = Bridge.GetJob(source)
    return job and job.onduty or false
end

EditTable.Functions.GetCitizenId = function(source)
    local player = Bridge.GetPlayer(source)
    return Bridge.GetCitizenId(player)
end



-- ============================================================
-- WEAPON SERIALIZATION SYSTEM
-- ============================================================

local charset = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

EditTable.LSPD.Functions.GenerateWeaponSerial = function()
    local config = Config.WeaponSerialization
    if not config or not config.Enabled then return "UNKNOWN-" .. os.time() end

    local serial = config.Prefix .. "-"
    local format = config.Format or "XXXX-XXXX"

    for i = 1, #format do
        local c = format:sub(i, i)
        if c == "X" then
            local rand = math.random(1, #charset)
            serial = serial .. charset:sub(rand, rand)
        else
            serial = serial .. c
        end
    end

    return serial
end

exports('GenerateWeaponSerial', function()
    return EditTable.LSPD.Functions.GenerateWeaponSerial()
end)

--[[
    Returns the framework-specific unique identifier for a player
--]]
EditTable.Functions.GetTrackingIdentifier = function(player)
    return Bridge.GetCitizenId(player)
end

--[[
    Checks if a player is cuffed on the server side.
    Ensures framework-specific data structure compatibility.
--]]
EditTable.Functions.IsPlayerCuffed = function(targetPed, targetServerId)
    local targetPlayer = Bridge.GetPlayer(targetServerId)
    if not targetPlayer then return false end

    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local isHandcuffed = targetPlayer.PlayerData.metadata['ishandcuffed'] == true
        if not isHandcuffed then
            local state = Player(targetServerId).state
            isHandcuffed = state and state.isHandcuffed
        end
        return isHandcuffed
    elseif Config.Framework == 'esx' then
        local state = Player(targetServerId).state
        local isHandcuffed = state and (state.isHandcuffed or state.handcuffed)
        if isHandcuffed == nil then isHandcuffed = false end
        return isHandcuffed
    end
    return false
end

