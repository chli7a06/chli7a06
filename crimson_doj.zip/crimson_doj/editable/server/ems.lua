EditTable.EMS = EditTable.EMS or {}
EditTable.EMS.Events = EditTable.EMS.Events or {}

--[[
    Bill Player (Medical Bill)
]]
EditTable.EMS.Events.BillPatient = function(source, targetSource, citizenId, amount, reason)
    EditTable.Functions.SendDebug("EMS", "Bill Patient",
        string.format("Medic: %s\nTarget: %s\nCitizenID: %s\nAmount: $%s\nReason: %s", source,
            targetSource or "Offline", citizenId, amount, reason), "Money")

    if targetSource and targetSource > 0 then
        if Bridge.RemoveMoney(targetSource, 'bank', amount) then
            Bridge.Bank.AddMoney('ambulance', amount)
            Bridge.Notify(targetSource,
                string.format((Locales[Config.Language] or Locales['en']).ems.medical_bill, amount), 'info')
            return true
        else
            Bridge.Notify(source, (Locales[Config.Language] or Locales['en']).system.no_money, 'error')
        end
    else
        MySQL.insert('INSERT INTO phone_invoices (citizenid, amount, society, sender, title) VALUES (?, ?, ?, ?, ?)',
            { citizenId, amount, 'ambulance', 'EMS', (Locales[Config.Language] or Locales['en']).ems.medical_bill_title ..
            ': ' .. reason })
        return true
    end
    return false
end

--[[
    Revive Player (if triggered from MDT/Dispatch)
]]
EditTable.EMS.Events.RevivePlayer = function(source, targetSource)
    EditTable.Functions.SendDebug("EMS", "Revive Player", string.format("Medic: %s\nTarget: %s", source, targetSource))
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        TriggerClientEvent('hospital:client:Revive', targetSource)
    end
end

-- --- Database Queries (Customizable) ---
EditTable.EMS.Queries = EditTable.EMS.Queries or {}

--[[
    Search Patient
]]
EditTable.EMS.Queries.SearchPatient = function(query)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return MySQL.query.await([[
            SELECT citizenid, charinfo FROM players 
            WHERE citizenid LIKE ? 
            OR charinfo LIKE ? 
            OR CONCAT(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(charinfo, '$.firstname')), JSON_UNQUOTE(JSON_EXTRACT(charinfo, '$.Firstname')), ''), ' ', COALESCE(JSON_UNQUOTE(JSON_EXTRACT(charinfo, '$.lastname')), JSON_UNQUOTE(JSON_EXTRACT(charinfo, '$.Lastname')), '')) LIKE ?
            LIMIT 10
        ]], { '%' .. query .. '%', '%' .. query .. '%', '%' .. query .. '%' })
    elseif Config.Framework == 'esx' then
        return MySQL.query.await(
            'SELECT identifier as citizenid, ssn, firstname, lastname FROM users WHERE identifier LIKE ? OR ssn LIKE ? OR firstname LIKE ? OR lastname LIKE ? LIMIT 10',
            { '%' .. query .. '%', '%' .. query .. '%', '%' .. query .. '%', '%' .. query .. '%' })
    end
    return {}
end

--[[
    Get Patient Details (Charinfo)
]]
EditTable.EMS.Queries.GetPatientDetails = function(citizenId)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return MySQL.single.await('SELECT charinfo FROM players WHERE citizenid = ?', { citizenId })
    elseif Config.Framework == 'esx' then
        return MySQL.single.await('SELECT ssn, firstname, lastname, dateofbirth, sex FROM users WHERE identifier = ?',
            { citizenId })
    end
    return nil
end

--[[
    Update EMS Stats
]]
EditTable.EMS.Queries.UpdateOfficerStats = function(citizenId, statType, amount)
    exports['xr-mdt']:UpdateStatistic(citizenId, statType, amount)
end

-- --- Global Helpers ---

--[[
    Handle treatment cost for a patient (framework-agnostic)
    Called when treatment is applied via MDT or direct export
]]
function EMS_HandleTreatment(source, citizenId, amount, treatmentName)
    local targetPlayer = Bridge.GetPlayerByCitizenId(citizenId)
    local cost = tonumber(amount) or 0

    if cost > 0 and targetPlayer then
        local targetSrc = Bridge.GetSource(targetPlayer)
        if Bridge.RemoveMoney(targetSrc, 'bank', cost) then
            Bridge.Bank.AddMoney('ambulance', cost)
            Bridge.Notify(targetSrc,
                string.format((Locales[Config.Language] or Locales['en']).ems.treatment_cost_notif, cost, treatmentName),
                'success')
        else
            Bridge.Notify(targetSrc,
                (Locales[Config.Language] or Locales['en']).ems.no_money_treatment, 'error')
        end
    end
end

-- --- Exports ---

exports('ApplyTreatment', function(citizenId, amount, treatmentName)
    EMS_HandleTreatment(nil, citizenId, amount, treatmentName)
end)
