EditTable.LSPD = EditTable.LSPD or {}
---@diagnostic disable: undefined-global
EditTable.LSPD.Events = EditTable.LSPD.Events or {}
EditTable.LSPD.Functions = EditTable.LSPD.Functions or {}

--[[
    Custom SSN Generation (6 digits, no dashes by default)
--]]
EditTable.LSPD.Functions.GenerateSSN = function()
    return tostring(math.random(100000, 999999))
end

--[[
    Custom VIN Format (12 characters by default)
--]]
EditTable.LSPD.Functions.GenerateVIN = function()
    local charset = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    local str = ""
    for i = 1, 12 do
        local rand = math.random(#charset)
        str = str .. string.sub(charset, rand, rand)
    end
    return str
end

--[[
    1. Jail Player
    Called when a player is sentenced to jail
    @param source: number (Officer)
    @param targetSource: number (Criminal, can be nil if offline)
    @param citizenId: string
    @param time: number (months)
--]]
EditTable.LSPD.Events.JailPlayer = function(source, targetSource, citizenId, time)
    EditTable.Functions.SendDebug("LSPD", "Jail Player",
        string.format("Officer: %s\nTarget: %s\nCitizenID: %s\nTime: %s months", source, targetSource or "Offline",
            citizenId, time), "Database")

    if targetSource and targetSource > 0 then
        -- Online Jail Logic
        -- Default: Use xr-jail default export or QBCore jail
        if Config.Framework == 'qb' or Config.Framework == 'qbox' then
            -- TriggerEvent('qb-prison:server:SetJailStatus', targetSource, time) -- Example for standard QB
            exports['xr-jail']:JailPlayer(targetSource, time)
            Bridge.Notify(targetSource,
                string.format((Locales[Config.Language] or Locales['en']).lspd.sent_to_jail, time), 'error')
        elseif Config.Framework == 'esx' then
            TriggerEvent('esx_jail:sendToJail', targetSource, time * 60)
        end
    else
        -- Offline Jail Logic (Database Update)
        MySQL.insert(
            'INSERT INTO jail_sentences (citizenid, time_remaining, in_jail) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE time_remaining = ?, in_jail = ?',
            { citizenId, time, 1, time, 1 })
    end
end

--[[
    2. Fine Player
    Called when a fine is issued
--]]
EditTable.LSPD.Events.FinePlayer = function(source, targetSource, citizenId, amount, reason)
    EditTable.Functions.SendDebug("LSPD", "Fine Player",
        string.format("Officer: %s\nTarget: %s\nCitizenID: %s\nAmount: $%s\nReason: %s", source,
            targetSource or "Offline", citizenId, amount, reason), "Money")

    if targetSource and targetSource > 0 then
        -- Online: Try to remove money
        if Bridge.RemoveMoney(targetSource, 'bank', amount) then
            -- Add to Society
            Bridge.AddMoney(EditTable.LSPD.JobName, 'bank', amount)
            Bridge.Notify(targetSource,
                string.format((Locales[Config.Language] or Locales['en']).lspd.received_fine, amount, reason), 'error')
            return true
        else
            Bridge.Notify(source, (Locales[Config.Language] or Locales['en']).system.no_money, 'error')
            return false
        end
    else
        -- Offline: Send Invoice
        MySQL.insert('INSERT INTO phone_invoices (citizenid, amount, society, sender, title) VALUES (?, ?, ?, ?, ?)',
            { citizenId, amount, EditTable.LSPD.JobName, 'Police Department', 'Fine: ' .. reason })
        return true
    end
end

--[[
    3. License Grant
--]]
EditTable.LSPD.Events.GrantLicense = function(source, targetSource, citizenId, type)
    EditTable.Functions.SendDebug("LSPD", "Grant License",
        string.format("Officer: %s\nTarget: %s\nCitizenID: %s\nType: %s", source, targetSource or "Offline", citizenId,
            type), "Database")

    if not citizenId then return end

    -- Default, or pass as arg if needed
    local expires = 'Never'

    -- MDT DB Update
    MySQL.insert(
        'INSERT INTO lspd_licenses (citizenid, type, expires, granted_by, granted_at) VALUES (?, ?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE expires = ?, granted_by = ?, granted_at = NOW()',
        { citizenId, type, expires, 'Police', expires, 'Police' })

    -- Framework Metadata Update
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local player = targetSource and Bridge.GetPlayer(targetSource)
        if player then
            local licences = player.PlayerData.metadata['licences'] or {}
            licences[type] = true
            player.Functions.SetMetaData('licences', licences)
            Bridge.Notify(targetSource,
                string.format((Locales[Config.Language] or Locales['en']).lspd.license_granted, type), 'success')
        end
    elseif Config.Framework == 'esx' then
        TriggerEvent('esx_license:addLicense', targetSource, type)
    end
end

--[[
    4. License Revoke
--]]
EditTable.LSPD.Events.RevokeLicense = function(source, targetSource, citizenId, type)
    EditTable.Functions.SendDebug("LSPD", "Revoke License",
        string.format("Officer: %s\nTarget: %s\nCitizenID: %s\nType: %s", source, targetSource or "Offline", citizenId,
            type), "Database")

    if not citizenId then return end

    -- MDT DB Update
    MySQL.update('DELETE FROM lspd_licenses WHERE citizenid = ? AND type = ?', { citizenId, type })

    -- Framework Metadata Update
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local player = targetSource and Bridge.GetPlayer(targetSource)
        if player then
            local licences = player.PlayerData.metadata['licences'] or {}
            licences[type] = false
            player.Functions.SetMetaData('licences', licences)
            Bridge.Notify(targetSource,
                string.format((Locales[Config.Language] or Locales['en']).lspd.license_revoked, type), 'error')
        else
            -- Offline metadata update would go here if needed
        end
    elseif Config.Framework == 'esx' then
        TriggerEvent('esx_license:removeLicense', targetSource, type)
    end
end

-- --- Database Queries (Customizable) ---
EditTable.LSPD.Queries = EditTable.LSPD.Queries or {}

--[[
    Search Citizen by Name or ID
--]]
EditTable.LSPD.Queries.SearchCitizen = function(query)
    local search = '%' .. query .. '%'
    local processed = {}

    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local results = MySQL.query.await([[
            SELECT p.citizenid, p.charinfo, c.mugshot_url,
            (SELECT COUNT(*) FROM lspd_warrants WHERE citizenid COLLATE utf8mb4_general_ci = p.citizenid COLLATE utf8mb4_general_ci) as wanted_count
            FROM players p
            LEFT JOIN lspd_citizen_data c ON c.citizenid COLLATE utf8mb4_general_ci = p.citizenid COLLATE utf8mb4_general_ci
            WHERE p.citizenid LIKE ?
            OR p.charinfo LIKE ?
            OR CONCAT(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.firstname')), JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.Firstname')), ''), ' ', COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.lastname')), JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.Lastname')), '')) LIKE ?
            LIMIT 10
        ]], { search, search, search })

        for _, p in ipairs(results) do
            local charinfo = p.charinfo
            if type(charinfo) == 'string' then
                charinfo = json.decode(charinfo)
            end
            charinfo = charinfo or {}
            
            table.insert(processed, {
                id = p.citizenid,
                ssn = p.citizenid,
                firstName = charinfo.firstname or "Unknown",
                lastName = charinfo.lastname or "Unknown",
                phone = charinfo.phone or "Unknown",
                wanted = (p.wanted_count and p.wanted_count > 0),
                avatar = p.mugshot_url or "",
                charinfo = p.charinfo
            })
        end
    elseif Config.Framework == 'esx' then
        local results = MySQL.query.await([[
            SELECT u.identifier as citizenid, u.ssn, u.firstname, u.lastname, u.dateofbirth, u.phone_number, c.mugshot_url,
            (SELECT COUNT(*) FROM lspd_warrants WHERE citizenid COLLATE utf8mb4_general_ci = u.identifier COLLATE utf8mb4_general_ci) as wanted_count
            FROM users u
            LEFT JOIN lspd_citizen_data c ON c.citizenid COLLATE utf8mb4_general_ci = u.identifier COLLATE utf8mb4_general_ci
            WHERE u.firstname LIKE ? OR u.lastname LIKE ? OR u.identifier LIKE ? OR u.ssn LIKE ? OR CONCAT(u.firstname, ' ', u.lastname) LIKE ?
            LIMIT 10
        ]], { search, search, search, search, search })

        for _, p in ipairs(results) do
            table.insert(processed, {
                id = p.citizenid,
                ssn = p.ssn or p.citizenid,
                firstName = p.firstname or "Unknown",
                lastName = p.lastname or "Unknown",
                phone = p.phone_number or "Unknown",
                wanted = (p.wanted_count and p.wanted_count > 0),
                avatar = p.mugshot_url or ""
            })
        end
    end

    return processed
end

--[[
    Get Citizen Details
--]]
EditTable.LSPD.Queries.GetCitizenDetails = function(citizenId)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return MySQL.single.await('SELECT charinfo, job, metadata FROM players WHERE citizenid = ?', { citizenId })
    elseif Config.Framework == 'esx' then
        return MySQL.single.await(
            'SELECT ssn, firstname, lastname, job, job_grade, dateofbirth, sex, height FROM users WHERE identifier = ?',
            { citizenId })
    end
    return nil
end

--[[
    Search Vehicle (All vehicles from database, not just police)
--]]
EditTable.LSPD.Queries.SearchVehicle = function(query)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return MySQL.query.await(
            'SELECT * FROM player_vehicles WHERE LOWER(plate) LIKE ? OR LOWER(vehicle) LIKE ? LIMIT 20',
            { '%' .. query .. '%', '%' .. query .. '%' })
    elseif Config.Framework == 'esx' then
        return MySQL.query.await(
            'SELECT * FROM owned_vehicles WHERE LOWER(plate) LIKE ? OR LOWER(vehicle) LIKE ? LIMIT 20',
            { '%' .. query .. '%', '%' .. query .. '%' })
    end
    return {}
end

--[[
    Get Vehicle Details
--]]
EditTable.LSPD.Queries.GetVehicleDetails = function(plate)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return MySQL.single.await('SELECT * FROM player_vehicles WHERE plate = ?', { plate })
    elseif Config.Framework == 'esx' then
        return MySQL.single.await('SELECT * FROM owned_vehicles WHERE plate = ?', { plate })
    end
    return nil
end

--[[
    Update Officer Stats (Wrapper)
--]]
EditTable.LSPD.Queries.UpdateOfficerStats = function(citizenId, type, amount)
    -- This assumes xr-mdt has an export or internal function, but we can expose the query here too if needed.
    exports['xr-mdt']:UpdateStatistic(citizenId, type, amount)
end

--[[
    Get Warrants (Active) with names joined from players/users table
--]]
EditTable.LSPD.Queries.GetWarrants = function(citizenId)
    local query = ''
    local params = {}

    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        if citizenId then
            query =
            'SELECT w.*, p.charinfo FROM lspd_warrants w JOIN players p ON p.citizenid COLLATE utf8mb4_general_ci = w.citizenid COLLATE utf8mb4_general_ci WHERE w.citizenid = ? ORDER BY w.created_at DESC'
            params = { citizenId }
        else
            query =
            'SELECT w.*, p.charinfo FROM lspd_warrants w JOIN players p ON p.citizenid COLLATE utf8mb4_general_ci = w.citizenid COLLATE utf8mb4_general_ci ORDER BY w.created_at DESC LIMIT 50'
        end

        local results = MySQL.query.await(query, params)
        if results then
            for _, v in ipairs(results) do
                local charinfo = type(v.charinfo) == 'string' and json.decode(v.charinfo) or v.charinfo
                if charinfo then
                    v.firstName = charinfo.firstname or "Unknown"
                    v.lastName = charinfo.lastname or "Unknown"
                end
            end
        end
        return results or {}
    elseif Config.Framework == 'esx' then
        if citizenId then
            query =
            'SELECT w.*, u.firstname, u.lastname FROM lspd_warrants w JOIN users u ON u.identifier COLLATE utf8mb4_general_ci = w.citizenid COLLATE utf8mb4_general_ci WHERE w.citizenid = ? ORDER BY w.created_at DESC'
            params = { citizenId }
        else
            query =
            'SELECT w.*, u.firstname, u.lastname FROM lspd_warrants w JOIN users u ON u.identifier COLLATE utf8mb4_general_ci = w.citizenid COLLATE utf8mb4_general_ci ORDER BY w.created_at DESC LIMIT 50'
        end

        local results = MySQL.query.await(query, params)
        if results then
            for _, v in ipairs(results) do
                v.firstName = v.firstname or "Unknown"
                v.lastName = v.lastname or "Unknown"
            end
        end
        return results or {}
    end
    return {}
end

--[[
    Issue Warrant (Query wrapper)
--]]
EditTable.LSPD.Queries.IssueWarrant = function(citizenId, reason, author)
    EditTable.Functions.SendDebug("LSPD", "Issue Warrant",
        string.format("CitizenID: %s\nReason: %s\nAuthor: %s", citizenId, reason, author), "Database")
    return MySQL.insert.await('INSERT INTO lspd_warrants (citizenid, reason, author) VALUES (?, ?, ?)',
        { citizenId, reason, author })
end

--[[
    Delete Warrant
--]]
EditTable.LSPD.Queries.DeleteWarrant = function(id)
    EditTable.Functions.SendDebug("LSPD", "Delete Warrant", string.format("Warrant ID: %s", id), "Database")
    MySQL.update.await('DELETE FROM lspd_warrants WHERE id = ?', { id })
end

--[[
    Check if Citizen is Wanted (Boolean)
--]]
EditTable.LSPD.Queries.IsCitizenWanted = function(citizenId)
    local count = MySQL.scalar.await('SELECT COUNT(*) FROM lspd_warrants WHERE citizenid = ?', { citizenId })
    return count > 0
end

--[[
    Function called when a sentence (Wyrok) is applied via MDT
    This handles money deduction and jail processing
--]]
EditTable.LSPD.Functions.HandleSentence = function(source, citizenId, fine, jailTime, reason, authorName)
    local fineAmount = tonumber(fine) or 0
    local months = tonumber(jailTime) or 0

    -- 1. Deduct Money
    if fineAmount > 0 then
        local success = Bridge.DeductMoneyByCitizenId(citizenId, 'bank', fineAmount, "fine-sentence")
        
        -- Add to Society
        Bridge.Bank.AddMoney('police', fineAmount)
        
        local targetPlayer = Bridge.GetPlayerByCitizenId(citizenId)
        if targetPlayer then
            local msg = success and string.format((Locales[Config.Language] or Locales['en']).lspd.fine_deducted, fineAmount, reason) 
                           or string.format((Locales[Config.Language] or Locales['en']).lspd.fine_debt, fineAmount)
            Bridge.Notify(Bridge.GetSource(targetPlayer), msg, 'error')
        end
    end

    -- 2. Jail Processing
    if months > 0 then
        local targetPlayer = Bridge.GetPlayerByCitizenId(citizenId)
        if targetPlayer then
            Bridge.Notify(Bridge.GetSource(targetPlayer), string.format((Locales[Config.Language] or Locales['en']).lspd.sentenced_months, months), 'error')
            Bridge.JailPlayer(Bridge.GetSource(targetPlayer), months)
        else
            -- Offline jail logic
            MySQL.insert(
                'INSERT INTO jail_sentences (citizenid, time_remaining, in_jail) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE time_remaining = ?, in_jail = ?',
                { citizenId, months, 1, months, 1 })
        end
    end

    return true
end

--[[
    Compatibility wrapper (if needed for old exports)
--]]
function LSPD_HandleSentence(...)
    return EditTable.LSPD.Functions.HandleSentence(...)
end

-- --- Exports ---

-- Export to allow external scripts to add sentences
exports('AddSentence', function(citizenId, fine, jailTime, reason, authorName)
    -- Insert into DB
    MySQL.insert.await(
        'INSERT INTO lspd_convictions (citizenid, offense, fine, jail_time, author) VALUES (?, ?, ?, ?, ?)', {
            citizenId, reason, fine, jailTime, authorName or "System"
        })

    -- Handle Effects
    LSPD_HandleSentence(nil, citizenId, fine, jailTime, reason, authorName or "System")

    -- Notify Clients
    TriggerClientEvent('xr-mdt:client:citizenUpdated', -1, citizenId)
end)

--[[
    5. Transfer Vehicle
--]]
EditTable.LSPD.Events.TransferVehicle = function(source, plate, targetCitizenId)
    EditTable.Functions.SendDebug("LSPD", "Transfer Vehicle",
        string.format("Officer: %s\nPlate: %s\nTarget CitizenID: %s", source, plate, targetCitizenId), "Database")

    if not plate or not targetCitizenId then return false end

    local success = Bridge.UpdateVehicleOwner(plate, targetCitizenId)
    if success then
        -- Notify all clients to update fleet view
        TriggerClientEvent('xr-mdt:client:updateFleet', -1)
        return true
    end
    return false
end
