EditTable.DOJ = EditTable.DOJ or {}

EditTable.DOJ.Queries = EditTable.DOJ.Queries or {}

EditTable.DOJ.Queries.GetPendingCasesCount = function()
    local result = MySQL.single.await('SELECT COUNT(*) as count FROM lspd_incidents')
    return result and result.count or 0
end

EditTable.DOJ.Queries.SearchCitizen = function(query)
    local search = '%' .. query .. '%'
    local processed = {}

    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local results = MySQL.query.await([[
            SELECT p.citizenid, p.charinfo, c.mugshot_url,
            (SELECT COUNT(*) FROM lspd_warrants WHERE citizenid COLLATE utf8mb4_general_ci = p.citizenid COLLATE utf8mb4_general_ci) as wanted_count
            FROM players p
            LEFT JOIN lspd_citizen_data c ON c.citizenid COLLATE utf8mb4_general_ci = p.citizenid COLLATE utf8mb4_general_ci
            WHERE p.citizenid LIKE ?
            OR p.charinfo LIKE ?
            OR CONCAT(COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.firstname')), JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.Firstname')), ''), ' ', COALESCE(JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.lastname')), JSON_UNQUOTE(JSON_EXTRACT(p.charinfo, '$.Lastname')), '')) LIKE ?
            LIMIT 10
        ]], { search, search, search })

        for _, p in ipairs(results) do
            local charinfo = p.charinfo
            if type(charinfo) == 'string' then
                charinfo = json.decode(charinfo)
            end
            charinfo = charinfo or {}

            table.insert(processed, {
                id = p.citizenid,
                ssn = p.citizenid,
                firstName = charinfo.firstname or "Unknown",
                lastName = charinfo.lastname or "Unknown",
                phone = charinfo.phone or "Unknown",
                wanted = (p.wanted_count and p.wanted_count > 0),
                avatar = p.mugshot_url or "",
                charinfo = p.charinfo
            })
        end
    elseif Config.Framework == 'esx' then
        local results = MySQL.query.await([[
            SELECT u.identifier as citizenid, u.ssn, u.firstname, u.lastname, u.dateofbirth, u.phone_number, c.mugshot_url,
            (SELECT COUNT(*) FROM lspd_warrants WHERE citizenid COLLATE utf8mb4_general_ci = u.identifier COLLATE utf8mb4_general_ci) as wanted_count
            FROM users u
            LEFT JOIN lspd_citizen_data c ON c.citizenid COLLATE utf8mb4_general_ci = u.identifier COLLATE utf8mb4_general_ci
            WHERE u.firstname LIKE ? OR u.lastname LIKE ? OR u.identifier LIKE ? OR u.ssn LIKE ? OR CONCAT(u.firstname, ' ', u.lastname) LIKE ?
            LIMIT 10
        ]], { search, search, search, search, search })

        for _, p in ipairs(results) do
            table.insert(processed, {
                id = p.citizenid,
                ssn = p.ssn or p.citizenid,
                firstName = p.firstname or "Unknown",
                lastName = p.lastname or "Unknown",
                phone = p.phone_number or "Unknown",
                wanted = (p.wanted_count and p.wanted_count > 0),
                avatar = p.mugshot_url or ""
            })
        end
    end

    return processed
end

EditTable.DOJ.Queries.GetCases = function()
    local incidents = MySQL.query.await('SELECT * FROM lspd_incidents ORDER BY created_at DESC LIMIT 50')
    for _, inc in ipairs(incidents) do
        local criminals = MySQL.query.await([[
            SELECT ic.citizenid as id, ic.role,
            CASE WHEN ? = 'qb' THEN (SELECT charinfo FROM players WHERE citizenid COLLATE utf8mb4_general_ci = ic.citizenid COLLATE utf8mb4_general_ci) ELSE NULL END as charinfo,
            CASE WHEN ? = 'esx' THEN (SELECT CONCAT(firstname, ' ', lastname) FROM users WHERE identifier COLLATE utf8mb4_general_ci = ic.citizenid COLLATE utf8mb4_general_ci) ELSE NULL END as name
            FROM lspd_incident_criminals ic WHERE ic.incident_id = ?
        ]], { Config.Framework, Config.Framework, inc.id })

        local suspects = {}
        for _, c in ipairs(criminals) do
            local name = c.name or (Locales[Config.Language] or Locales['en']).system.unknown
            if c.charinfo then
                local ci = json.decode(c.charinfo)
                name = ci.firstname .. ' ' .. ci.lastname
            end
            table.insert(suspects, { id = c.id, citizenId = c.id, name = name, role = c.role })
        end

        inc.suspects = suspects
        inc.witnesses = {}
        inc.vehicles = MySQL.query.await(
            'SELECT plate as id, plate, role FROM lspd_incident_vehicles WHERE incident_id = ?', { inc.id })
        inc.officers = MySQL.query.await(
            'SELECT officerid as id, badge FROM lspd_incident_officers WHERE incident_id = ?', { inc.id })
        inc.photos = inc.gallery and json.decode(inc.gallery) or {}
        inc.charges = {}
        inc.notes = inc.notes and json.decode(inc.notes) or {}
        inc.status = inc.status or 'OPEN'
    end
    return incidents
end

EditTable.DOJ.Queries.SearchCases = function(query)
    local search = '%' .. query .. '%'
    local incidents = MySQL.query.await(
        'SELECT * FROM lspd_incidents WHERE title LIKE ? OR id LIKE ? ORDER BY created_at DESC LIMIT 50',
        { search, search })
    for _, inc in ipairs(incidents) do
        local criminals = MySQL.query.await(
            'SELECT citizenid as id, role FROM lspd_incident_criminals WHERE incident_id = ?', { inc.id })
        local vehicles = MySQL.query.await('SELECT plate as id, role FROM lspd_incident_vehicles WHERE incident_id = ?',
            { inc.id })
        local officers = MySQL.query.await(
            'SELECT officerid as id, badge FROM lspd_incident_officers WHERE incident_id = ?', { inc.id })

        inc.suspects = criminals or {}
        inc.witnesses = {}
        inc.vehicles = vehicles or {}
        inc.officers = officers or {}
        inc.photos = inc.gallery and json.decode(inc.gallery) or {}
        inc.charges = {}
        inc.notes = {}
        inc.status = 'ZAMKNIĘTA'
    end
    return incidents
end

EditTable.DOJ.Queries.CreateCase = function(data, author)
    EditTable.Functions.SendDebug("DOJ", "Create Case",
        string.format("Author: %s\nTitle: %s\nSuspects: %s", author, data.title or "Untitled",
            json.encode(data.suspects or {})), "Database")

    local id = MySQL.insert.await(
        'INSERT INTO lspd_incidents (title, description, author, location) VALUES (?, ?, ?, ?)',
        {
            data.title or (Locales[Config.Language] or Locales['en']).system.no_title,
            data.description or (Locales[Config.Language] or Locales['en']).system.no_description,
            author,
            data.location or (Locales[Config.Language] or Locales['en']).system.unknown
        })

    if id then
        if data.suspects and #data.suspects > 0 then
            for _, s in ipairs(data.suspects) do
                MySQL.insert.await('INSERT INTO lspd_incident_criminals (incident_id, citizenid, role) VALUES (?, ?, ?)',
                    { id, s.id or s.citizenId, s.role or 'Suspect' })
            end
        end
        if data.vehicles and #data.vehicles > 0 then
            for _, v in ipairs(data.vehicles) do
                MySQL.insert.await('INSERT INTO lspd_incident_vehicles (incident_id, plate, role) VALUES (?, ?, ?)',
                    { id, v.id or v.plate, v.role or 'Vehicle' })
            end
        end
        if data.officers and #data.officers > 0 then
            for _, o in ipairs(data.officers) do
                MySQL.insert.await('INSERT INTO lspd_incident_officers (incident_id, officerid, badge) VALUES (?, ?, ?)',
                    { id, o.id or o.officerId, o.badge or '00' })
            end
        end
    end
    return id
end

EditTable.DOJ.Queries.UpdateCaseStatus = function(id, status)
    EditTable.Functions.SendDebug("DOJ", "Update Case Status", string.format("Case ID: %s\nNew Status: %s", id, status),
        "Database")
    local affected = MySQL.update.await('UPDATE lspd_incidents SET status = ? WHERE id = ?', { status, id })
    return affected > 0
end

EditTable.DOJ.Queries.UpdateCaseDescription = function(id, description)
    local affected = MySQL.update.await('UPDATE lspd_incidents SET description = ? WHERE id = ?', { description, id })
    return affected > 0
end

EditTable.DOJ.Queries.AddIncidentItem = function(incidentId, type, item)
    EditTable.Functions.SendDebug("DOJ", "Add Case Item",
        string.format("Case ID: %s\nType: %s\nItemData: %s", incidentId, type, json.encode(item)), "Database")
    if type == 'suspect' then
        return MySQL.insert.await('INSERT INTO lspd_incident_criminals (incident_id, citizenid, role) VALUES (?, ?, ?)',
            { incidentId, item.id or item.citizenId, item.role or 'Suspect' }) ~= nil
    elseif type == 'witness' then
        return MySQL.insert.await('INSERT INTO lspd_incident_criminals (incident_id, citizenid, role) VALUES (?, ?, ?)',
            { incidentId, item.id or item.citizenId, 'Witness' }) ~= nil
    elseif type == 'vehicle' then
        return MySQL.insert.await('INSERT INTO lspd_incident_vehicles (incident_id, plate, role) VALUES (?, ?, ?)',
            { incidentId, item.id or item.plate, item.role or 'Vehicle' }) ~= nil
    elseif type == 'officer' then
        return MySQL.insert.await('INSERT INTO lspd_incident_officers (incident_id, officerid, badge) VALUES (?, ?, ?)',
            { incidentId, item.id or item.officerId, item.badge or '00' }) ~= nil
    elseif type == 'photo' then
        local incident = MySQL.single.await('SELECT gallery FROM lspd_incidents WHERE id = ?', { incidentId })
        if not incident then return false end
        local gallery = {}
        if incident.gallery then
            gallery = json.decode(incident.gallery) or {}
        end
        table.insert(gallery, item.url)
        local affected = MySQL.update.await('UPDATE lspd_incidents SET gallery = ? WHERE id = ?',
            { json.encode(gallery), incidentId })
        return affected > 0
    end
    return false
end

EditTable.DOJ.Queries.RemoveIncidentItem = function(incidentId, type, itemId)
    if type == 'suspect' or type == 'witness' then
        return MySQL.update.await('DELETE FROM lspd_incident_criminals WHERE incident_id = ? AND citizenid = ?',
            { incidentId, itemId }) > 0
    elseif type == 'vehicle' then
        return MySQL.update.await('DELETE FROM lspd_incident_vehicles WHERE incident_id = ? AND plate = ?',
            { incidentId, itemId }) > 0
    elseif type == 'officer' then
        return MySQL.update.await('DELETE FROM lspd_incident_officers WHERE incident_id = ? AND officerid = ?',
            { incidentId, itemId }) > 0
    elseif type == 'photo' then
        local incident = MySQL.single.await('SELECT gallery FROM lspd_incidents WHERE id = ?', { incidentId })
        if not incident then return false end
        local gallery = {}
        if incident.gallery then
            gallery = json.decode(incident.gallery) or {}
        end
        local index = tonumber(itemId)
        if index then
            table.remove(gallery, index + 1)
            local affected = MySQL.update.await('UPDATE lspd_incidents SET gallery = ? WHERE id = ?',
                { json.encode(gallery), incidentId })
            return affected > 0
        end
    end
    return false
end

EditTable.DOJ.Queries.AddCaseNote = function(incidentId, note)
    local case = MySQL.single.await('SELECT notes FROM lspd_incidents WHERE id = ?', { incidentId })
    local notes = {}
    if case and case.notes then
        notes = json.decode(case.notes) or {}
    end
    table.insert(notes, 1, note)
    local affected = MySQL.update.await('UPDATE lspd_incidents SET notes = ? WHERE id = ?',
        { json.encode(notes), incidentId })
    return affected > 0
end

EditTable.DOJ.Queries.SearchVehicle = function(query)
    local search = '%' .. query .. '%'
    local vehiclesTable = (Config.Framework == 'qb' or Config.Framework == 'qbox') and 'player_vehicles' or
        'owned_vehicles'
    local ownerColumn = (Config.Framework == 'qb' or Config.Framework == 'qbox') and 'citizenid' or 'owner'

    local vehicles = MySQL.query.await(string.format([[
        SELECT v.*, t.wanted, t.stolen, t.notes as tag_notes
        FROM %s v
        LEFT JOIN lspd_vehicle_tags t ON t.plate COLLATE utf8mb4_general_ci = v.plate COLLATE utf8mb4_general_ci
        WHERE v.plate LIKE ?
        LIMIT 20
    ]], vehiclesTable), { search })

    local results = {}
    for _, v in ipairs(vehicles) do
        table.insert(results, {
            id = v.plate,
            plate = v.plate,
            vehicle = v.vehicle,
            vin = v.vin or "N/A",
            citizenid = v[ownerColumn],
            wanted = (v.wanted == 1),
            stolen = (v.stolen == 1),
            notes = v.tag_notes or ""
        })
    end
    return results
end

EditTable.DOJ.Queries.GetVehicleDetails = function(plate)
    local vehiclesTable = (Config.Framework == 'qb' or Config.Framework == 'qbox') and 'player_vehicles' or
        'owned_vehicles'
    local vehicle = MySQL.single.await(string.format('SELECT * FROM %s WHERE plate = ?', vehiclesTable), { plate })
    if vehicle then
        local ownerColumn = (Config.Framework == 'qb' or Config.Framework == 'qbox') and 'citizenid' or 'owner'
        local tags = MySQL.single.await('SELECT notes, wanted, image_url FROM lspd_vehicle_tags WHERE plate = ?',
            { plate })

        local notes = {}
        if tags and tags.notes then
            local decoded = json.decode(tags.notes)
            if type(decoded) == 'table' then
                notes = decoded
            end
        end

        return {
            id = vehicle.plate,
            plate = vehicle.plate,
            vehicle = vehicle.vehicle,
            vin = vehicle.vin or "N/A",
            citizenid = vehicle[ownerColumn],
            notes = notes,
            image = tags and tags.image_url or nil,
            wanted = tags and tags.wanted == 1 or false
        }
    end
    return nil
end

EditTable.DOJ.Queries.SearchBusiness = function(query)
    local businesses = {}
    return businesses
end

EditTable.DOJ.Queries.AddVehicleNote = function(plate, note, author)
    local existing = MySQL.single.await('SELECT notes FROM lspd_vehicle_tags WHERE plate = ?', { plate })
    local notes = {}
    if existing and existing.notes then
        local decoded = json.decode(existing.notes)
        if type(decoded) == 'table' then
            notes = decoded
        end
    end
    table.insert(notes, 1, note)

    local isWanted = 0
    local isStolen = 0
    if existing then
        local affected = MySQL.update.await('UPDATE lspd_vehicle_tags SET notes = ? WHERE plate = ?',
            { json.encode(notes), plate })
        return affected > 0
    else
        local id = MySQL.insert.await('INSERT INTO lspd_vehicle_tags (plate, notes, wanted, stolen) VALUES (?, ?, ?, ?)',
            { plate, json.encode(notes), isWanted, isStolen })
        return id
    end
end

EditTable.DOJ.Queries.SetVehicleWanted = function(plate, wanted)
    EditTable.Functions.SendDebug("DOJ", "Set Vehicle Wanted", string.format("Plate: %s\nWanted: %s", plate, wanted),
        "Database")
    local isWanted = wanted and 1 or 0
    local existing = MySQL.single.await('SELECT plate FROM lspd_vehicle_tags WHERE plate = ?', { plate })
    if existing then
        local affected = MySQL.update.await('UPDATE lspd_vehicle_tags SET wanted = ? WHERE plate = ?',
            { isWanted, plate })
        return affected > 0
    else
        local id = MySQL.insert.await('INSERT INTO lspd_vehicle_tags (plate, wanted) VALUES (?, ?)', { plate, isWanted })
        return id
    end
end

EditTable.DOJ.Queries.AddCitizenNote = function(citizenid, title, content, author)
    local id = MySQL.insert.await('INSERT INTO lspd_notes (citizenid, title, content, author) VALUES (?, ?, ?, ?)',
        { citizenid, title, content, author })
    return id
end

EditTable.DOJ.Queries.SetCitizenWanted = function(citizenid, reason, author)
    local id = MySQL.insert.await('INSERT INTO lspd_warrants (citizenid, reason, author) VALUES (?, ?, ?)',
        { citizenid, reason, author })
    return id
end

EditTable.DOJ.Queries.AddSentence = function(citizenid, fine, jail, offense, author)
    EditTable.Functions.SendDebug("DOJ", "Add Sentence",
        string.format("CitizenID: %s\nFine: $%s\nJail: %s months\nOffense: %s\nAuthor: %s", citizenid, fine, jail, offense,
            author), "Money")
    local id = MySQL.insert.await(
        'INSERT INTO lspd_convictions (citizenid, offense, fine, jail_time, author) VALUES (?, ?, ?, ?, ?)',
        { citizenid, offense, fine, jail, author })
    return id
end

EditTable.DOJ.Queries.GrantLicense = function(citizenid, type, author)
    local id = MySQL.insert.await('INSERT INTO lspd_licenses (citizenid, type, granted_by) VALUES (?, ?, ?)',
        { citizenid, type, author })
    return id
end

EditTable.DOJ.Queries.GetEmployees = function()
    local employees = {}
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local jobName = Config.DOJ.JobName
        local result = {}
        if type(jobName) == 'table' then
            local queryPart = ""
            local params = {}
            for i, name in ipairs(jobName) do
                if i > 1 then queryPart = queryPart .. " OR " end
                queryPart = queryPart .. 'JSON_UNQUOTE(JSON_EXTRACT(p.job, "$.name")) = ?'
                table.insert(params, name)
            end
            result = MySQL.query.await([[
                SELECT p.*, c.mugshot_url
                FROM players p
                LEFT JOIN lspd_citizen_data c ON c.citizenid COLLATE utf8mb4_general_ci = p.citizenid COLLATE utf8mb4_general_ci
                WHERE ]] .. queryPart, params)
        else
            result = MySQL.query.await([[
                SELECT p.*, c.mugshot_url
                FROM players p
                LEFT JOIN lspd_citizen_data c ON c.citizenid COLLATE utf8mb4_general_ci = p.citizenid COLLATE utf8mb4_general_ci
                WHERE JSON_UNQUOTE(JSON_EXTRACT(p.job, "$.name")) = ?
            ]], { jobName })
        end

        for _, p in ipairs(result) do
            local charinfo = p.charinfo
            if type(charinfo) == 'string' then charinfo = json.decode(charinfo) end
            charinfo = charinfo or {}

            local job = p.job
            if type(job) == 'string' then job = json.decode(job) end
            job = job or {}

            local metadata = p.metadata
            if type(metadata) == 'string' then metadata = json.decode(metadata) end
            metadata = metadata or {}

            local onDuty = false
            local dutyLabel = "Off Duty"

            if Config.Framework == 'qb' or Config.Framework == 'qbox' then
                local QBCore = exports['qb-core']:GetCoreObject()
                local onlinePlayer = QBCore.Functions.GetPlayerByCitizenId(p.citizenid)
                if onlinePlayer then
                    if onlinePlayer.PlayerData.job.onduty then
                        onDuty = true
                        dutyLabel = (Locales[Config.Language] or Locales['en']).system.status_on_duty
                    else
                        dutyLabel = (Locales[Config.Language] or Locales['en']).system.online_offduty
                    end

                    if onlinePlayer.PlayerData.charinfo then
                        charinfo = onlinePlayer.PlayerData.charinfo
                    end
                end
            end

            local firstName = charinfo.firstname or charinfo.Firstname or (Locales[Config.Language] or Locales['en']).system.unknown
            local lastName = charinfo.lastname or charinfo.Lastname or (Locales[Config.Language] or Locales['en']).system.unknown

            if firstName == "Unknown" then
                print('^3[XR-MDT] Warning: Could not find name for employee ' ..
                    tostring(p.citizenid) .. '. Raw charinfo: ' .. json.encode(charinfo) .. '^7')
            end
            local lastSeen = p.last_entered or p.last_login or p.last_updated or "N/A"

            table.insert(employees, {
                id = p.citizenid,
                name = firstName .. ' ' .. lastName,
                grade = job.grade and job.grade.name or "Unknown",
                gradeLabel = job.grade and job.grade.name or "Unknown",
                gradeLevel = job.grade and job.grade.level or 0,
                rank = job.grade and job.grade.name or "Unknown",
                callsign = metadata.callsign or charinfo.phone or "N/A",
                badge = metadata.callsign or charinfo.phone or "N/A",
                phone = charinfo.phone,
                dutyStart = 0,
                dutyTime = dutyLabel,
                onDuty = onDuty,
                notes = metadata.doj_notes or {},
                recentActivity = string.format((Locales[Config.Language] or Locales['en']).system.last_login_notif,
                    tostring(lastSeen)),
                avatar = p.mugshot_url
            })
        end
    elseif Config.Framework == 'esx' then
        local jobName = Config.DOJ.JobName
        local result = {}
        if type(jobName) == 'table' then
            local placeholders = string.rep('?,', #jobName):sub(1, -2)
            result = MySQL.query.await([[
                SELECT u.*, c.mugshot_url
                FROM users u
                LEFT JOIN lspd_citizen_data c ON c.citizenid COLLATE utf8mb4_general_ci = u.charid COLLATE utf8mb4_general_ci
                WHERE u.job IN (]] .. placeholders .. ')', jobName)
        else
            result = MySQL.query.await([[
                SELECT u.*, c.mugshot_url
                FROM users u
                LEFT JOIN lspd_citizen_data c ON c.citizenid COLLATE utf8mb4_general_ci = u.charid COLLATE utf8mb4_general_ci
                WHERE u.job = ?
            ]], { jobName })
        end

        for _, p in ipairs(result) do
            table.insert(employees, {
                id = p.charid or p.identifier,
                name = p.firstname .. ' ' .. p.lastname,
                grade = p.job_grade,
                rank = p.job_grade,
                callsign = p.phone_number,
                badge = p.phone_number,
                phone = p.phone_number,
                dutyTime = 0,
                avatar = p.mugshot_url
            })
        end
    end
    return employees
end
