EditTable.Business = EditTable.Business or {}
---@diagnostic disable: undefined-global
EditTable.Business.Events = EditTable.Business.Events or {}

--[[
    Hire Employee
]]
EditTable.Business.Events.HireEmployee = function(source, businessName, targetSource)
    EditTable.Functions.SendDebug("Business", "Hire Employee",
        string.format("Manager: %s\nBusiness: %s\nTarget: %s", source, businessName, targetSource))
end

--[[
    Fire Employee
]]
EditTable.Business.Events.FireEmployee = function(source, businessName, citizenId)
    EditTable.Functions.SendDebug("Business", "Fire Employee",
        string.format("Manager: %s\nBusiness: %s\nCitizenID: %s", source, businessName, citizenId), "JobChange")
end

-- --- Database Queries (Customizable) ---
EditTable.Business.Queries = EditTable.Business.Queries or {}

--[[
    Get Employees (Core function)
]]
EditTable.Business.Queries.GetEmployees = function(jobName)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        return MySQL.query.await('SELECT charinfo, job, metadata, citizenid FROM players WHERE job LIKE ?',
            { '%' .. jobName .. '%' })
    elseif Config.Framework == 'esx' then
        return MySQL.query.await(
            'SELECT identifier as citizenid, firstname, lastname, job, job_grade FROM users WHERE job = ?', { jobName })
    end
    return {}
end

--[[
    Hire Employee (Offline/Online DB Sync)
]]
EditTable.Business.Queries.HireEmployee = function(citizenId, jobName, grade)
    EditTable.Functions.SendDebug("Business", "DB Hire",
        string.format("CitizenID: %s\nJob: %s\nGrade: %s", citizenId, jobName, grade), "JobChange")
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local result = MySQL.single.await('SELECT job FROM players WHERE citizenid = ?', { citizenId })
        if result then
            local job = json.decode(result.job)
            job.name = jobName
            job.label = QBCore.Shared.Jobs[jobName].label
            job.onduty = true
            job.grade = {
                name = QBCore.Shared.Jobs[jobName].grades[tostring(grade)].name,
                level = grade
            }
            job.payment = QBCore.Shared.Jobs[jobName].grades[tostring(grade)].payment
            MySQL.update.await('UPDATE players SET job = ? WHERE citizenid = ?', { json.encode(job), citizenId })
            return true
        end
    elseif Config.Framework == 'esx' then
        MySQL.update.await('UPDATE users SET job = ?, job_grade = ? WHERE identifier = ?', { jobName, grade, citizenId })
        return true
    end
    return false
end

--[[
    Fire Employee (Offline DB Sync)
]]
EditTable.Business.Queries.FireEmployee = function(citizenId)
    EditTable.Functions.SendDebug("Business", "DB Fire", string.format("CitizenID: %s", citizenId), "JobChange")
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local player = MySQL.single.await('SELECT job FROM players WHERE citizenid = ?', { citizenId })
        if player then
            local job = json.decode(player.job)
            job.name = "unemployed"
            job.label = (Locales[Config.Language] or Locales['en']).system.unemployed
            job.grade = { name = (Locales[Config.Language] or Locales['en']).system.freelancer, level = 0 }
            job.payment = 10
            MySQL.update.await('UPDATE players SET job = ? WHERE citizenid = ?', { json.encode(job), citizenId })
            return true
        end
    elseif Config.Framework == 'esx' then
        MySQL.update.await('UPDATE users SET job = ?, job_grade = ? WHERE identifier = ?', { 'unemployed', 0, citizenId })
        return true
    end
    return false
end

--[[
    Get Offline Player Job Info (For validation)
]]
EditTable.Business.Queries.GetPlayerJob = function(citizenId)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local result = MySQL.single.await('SELECT job FROM players WHERE citizenid = ?', { citizenId })
        return result and json.decode(result.job) or nil
    elseif Config.Framework == 'esx' then
        return MySQL.single.await('SELECT job, job_grade FROM users WHERE identifier = ?', { citizenId })
    end
    return nil
end

--[[
    Promote Employee (Offline)
]]
EditTable.Business.Queries.PromoteEmployee = function(citizenId, jobName, newGrade)
    EditTable.Functions.SendDebug("Business", "Promote Employee",
        string.format("CitizenID: %s\nJob: %s\nNew Grade: %s", citizenId, jobName, newGrade), "JobChange")
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local player = MySQL.single.await('SELECT job FROM players WHERE citizenid = ?', { citizenId })
        if player then
            local job = json.decode(player.job)
            if job.name == jobName then
                job.grade.level = newGrade
                if QBCore.Shared.Jobs[jobName] and QBCore.Shared.Jobs[jobName].grades[tostring(newGrade)] then
                    job.grade.name = QBCore.Shared.Jobs[jobName].grades[tostring(newGrade)].name
                    job.payment = QBCore.Shared.Jobs[jobName].grades[tostring(newGrade)].payment
                end
                MySQL.update.await('UPDATE players SET job = ? WHERE citizenid = ?', { json.encode(job), citizenId })
                return true
            end
        end
    elseif Config.Framework == 'esx' then
        MySQL.update.await('UPDATE users SET job_grade = ? WHERE identifier = ? AND job = ?',
            { newGrade, citizenId, jobName })
        return true
    end
    return false
end

--[[
    Update Badge/Callsign (Offline)
]]
EditTable.Business.Queries.UpdateBadge = function(citizenId, newBadge)
    EditTable.Functions.SendDebug("Business", "Update Badge",
        string.format("CitizenID: %s\nNew Badge: %s", citizenId, newBadge), "Database")
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local result = MySQL.single.await('SELECT metadata FROM players WHERE citizenid = ?', { citizenId })
        if result then
            local metadata = json.decode(result.metadata)
            metadata.callsign = newBadge
            MySQL.update('UPDATE players SET metadata = ? WHERE citizenid = ?', { json.encode(metadata), citizenId })
            return true
        end
    end
    return false
end

--[[
    Suspend Employee (Offline)
]]
EditTable.Business.Queries.SuspendEmployee = function(citizenId)
    EditTable.Functions.SendDebug("Business", "Suspend Employee", string.format("CitizenID: %s", citizenId), "JobChange")
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local result = MySQL.single.await('SELECT metadata, job FROM players WHERE citizenid = ?', { citizenId })
        if result then
            local metadata = json.decode(result.metadata)
            metadata.is_suspended = not metadata.is_suspended

            local job = json.decode(result.job)
            if metadata.is_suspended then
                job.onduty = false
            end

            MySQL.update('UPDATE players SET metadata = ?, job = ? WHERE citizenid = ?',
                { json.encode(metadata), json.encode(job), citizenId })
            return true
        end
    end
    return false
end

--[[
    Add Note (Offline)
]]
EditTable.Business.Queries.AddNote = function(citizenId, newNote)
    EditTable.Functions.SendDebug("Business", "Add Note",
        string.format("CitizenID: %s\nNote: %s", citizenId, json.encode(newNote)), "Database")
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local result = MySQL.single.await('SELECT metadata FROM players WHERE citizenid = ?', { citizenId })
        if result then
            local metadata = json.decode(result.metadata)
            metadata.business_notes = metadata.business_notes or {}
            table.insert(metadata.business_notes, 1, newNote)
            MySQL.update('UPDATE players SET metadata = ? WHERE citizenid = ?', { json.encode(metadata), citizenId })
            return true
        end
    end
    return false
end

--[[
    Delete Note (Offline)
]]
EditTable.Business.Queries.DeleteNote = function(citizenId, noteId)
    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        local result = MySQL.single.await('SELECT metadata FROM players WHERE citizenid = ?', { citizenId })
        if result then
            local metadata = json.decode(result.metadata)
            if metadata.business_notes then
                local newNotes = {}
                for _, note in ipairs(metadata.business_notes) do
                    if tonumber(note.id) ~= noteId then
                        table.insert(newNotes, note)
                    end
                end
                metadata.business_notes = newNotes
                MySQL.update('UPDATE players SET metadata = ? WHERE citizenid = ?', { json.encode(metadata), citizenId })
                return true
            end
        end
    end
    return false
end

-- --- Finance & Banking Queries ---

--[[
    - REVENUE ---
]]
EditTable.Business.Queries.GetRevenue = function(jobName, days, offsetDays)
    if GetResourceState('snipe-banking') == 'started' then
        local query = [[
            SELECT SUM(amount) FROM banking_transactions
            WHERE unique_id = (SELECT unique_id FROM banking_users WHERE identifier = ? AND type = 'jobgang')
            AND transaction_type = 'deposit'
            AND created_at >= NOW() - INTERVAL ? DAY
        ]]
        local params = { jobName, days or 30 }

        if offsetDays and offsetDays > 0 then
            query = [[
                SELECT SUM(amount) FROM banking_transactions
                WHERE unique_id = (SELECT unique_id FROM banking_users WHERE identifier = ? AND type = 'jobgang')
                AND transaction_type = 'deposit'
                AND created_at >= NOW() - INTERVAL ? DAY AND created_at < NOW() - INTERVAL ? DAY
            ]]
            params = { jobName, days or 60, offsetDays }
        end

        local status, result = pcall(function()
            return MySQL.scalar.await(query, params)
        end)
        return status and tonumber(result) or 0
    end

    local query = [[
        SELECT SUM(amount) FROM bank_statements
        WHERE account_name = ? AND statement_type = 'deposit'
        AND date >= NOW() - INTERVAL ? DAY
    ]]
    local params = { jobName, days or 30 }

    if offsetDays and offsetDays > 0 then
        query = [[
            SELECT SUM(amount) FROM bank_statements
            WHERE account_name = ? AND statement_type = 'deposit'
            AND date >= NOW() - INTERVAL ? DAY AND date < NOW() - INTERVAL ? DAY
        ]]
        params = { jobName, days or 60, offsetDays }
    end

    local status, result = pcall(function()
        return MySQL.scalar.await(query, params)
    end)
    return status and tonumber(result) or 0
end

--[[
    - EXPENSES ---
]]
EditTable.Business.Queries.GetExpenses = function(jobName, days)
    if GetResourceState('snipe-banking') == 'started' then
        local status, result = pcall(function()
            return MySQL.scalar.await([[
                SELECT SUM(amount) FROM banking_transactions
                WHERE unique_id = (SELECT unique_id FROM banking_users WHERE identifier = ? AND type = 'jobgang')
                AND transaction_type = 'withdraw'
                AND created_at >= NOW() - INTERVAL ? DAY
            ]], { jobName, days or 30 })
        end)
        return status and tonumber(result) or 0
    end

    local status, result = pcall(function()
        return MySQL.scalar.await([[
            SELECT SUM(amount) FROM bank_statements
            WHERE account_name = ? AND statement_type = 'withdraw'
            AND date >= NOW() - INTERVAL ? DAY
        ]], { jobName, days or 30 })
    end)
    return status and tonumber(result) or 0
end

--[[
    - WEEKLY STATS (FOR CHART) ---
]]
EditTable.Business.Queries.GetWeeklyRevenue = function(jobName)
    if GetResourceState('snipe-banking') == 'started' then
        local status, result = pcall(function()
            return MySQL.query.await([[
                SELECT DATE(created_at) as date_day, SUM(amount) as total, DAYNAME(created_at) as day_name
                FROM banking_transactions
                WHERE unique_id = (SELECT unique_id FROM banking_users WHERE identifier = ? AND type = 'jobgang')
                AND transaction_type = 'deposit'
                AND created_at >= NOW() - INTERVAL 7 DAY
                GROUP BY DATE(created_at), DAYNAME(created_at)
                ORDER BY DATE(created_at) ASC
            ]], { jobName })
        end)
        return status and result or {}
    end

    local status, result = pcall(function()
        return MySQL.query.await([[
            SELECT DATE(date) as date_day, SUM(amount) as total, DAYNAME(date) as day_name
            FROM bank_statements
            WHERE account_name = ? AND statement_type = 'deposit'
            AND date >= NOW() - INTERVAL 7 DAY
            GROUP BY DATE(date), DAYNAME(date)
            ORDER BY DATE(date) ASC
        ]], { jobName })
    end)
    return status and result or {}
end

--[[
    - RECENT TRANSACTIONS ---
]]
EditTable.Business.Queries.GetRecentTransactions = function(jobName, limit)
    if GetResourceState('snipe-banking') == 'started' then
        local status, result = pcall(function()
            return MySQL.query.await([[
                SELECT id, amount, transaction_type as statement_type, memo as reason, created_at as date
                FROM banking_transactions
                WHERE unique_id = (SELECT unique_id FROM banking_users WHERE identifier = ? AND type = 'jobgang')
                ORDER BY created_at DESC LIMIT ?
            ]], { jobName, limit or 5 })
        end)
        return status and result or {}
    end

    local status, result = pcall(function()
        return MySQL.query.await([[
            SELECT * FROM bank_statements
            WHERE account_name = ?
            ORDER BY date DESC LIMIT ?
        ]], { jobName, limit or 5 })
    end)
    return status and result or {}
end

--[[
    - GET BUSINESS BALANCE ---
]]
EditTable.Business.Queries.GetBusinessBalance = function(jobName)
    return Bridge.Bank.GetBalance(jobName)
end

-- --- Global Helpers ---

--[[
    Handle bonus payment for a business employee (framework-agnostic)
    Called when a boss grants a bonus via MDT or direct export
]]
function Business_HandleBonus(employeeCitizenId, amount, businessName)
    local targetPlayer = Bridge.GetPlayerByCitizenId(employeeCitizenId)
    local bonus = tonumber(amount) or 0

    if targetPlayer then
        local targetSrc = Bridge.GetSource(targetPlayer)
        Bridge.AddMoney(targetSrc, 'bank', bonus)
        Bridge.Notify(targetSrc,
            string.format((Locales[Config.Language] or Locales['en']).business.bonus_received_notif, bonus, businessName),
            'success')
    else
        if Config.Framework == 'qb' or Config.Framework == 'qbox' then
            local player = MySQL.single.await('SELECT money FROM players WHERE citizenid = ?', { employeeCitizenId })
            if player then
                local money = json.decode(player.money)
                money.bank = (money.bank or 0) + bonus
                MySQL.update('UPDATE players SET money = ? WHERE citizenid = ?',
                    { json.encode(money), employeeCitizenId })
            end
        elseif Config.Framework == 'esx' then
            MySQL.update('UPDATE users SET bank = bank + ? WHERE identifier = ?', { bonus, employeeCitizenId })
        end
    end
end

-- --- Exports ---

exports('GiveBonus', function(citizenId, amount, businessName)
    Business_HandleBonus(citizenId, amount, businessName)
end)
