-- ============================================================
-- XR-MDT: Unified Item Controller (Editable)
-- Centralized registration and routing for all system items
-- ============================================================

-- ============================================================
-- TABLET OPEN LOGIC
-- ============================================================

local function OpenTablet(source)
    if Config.Debug then print("[XR-MDT] Requesting MDT opening for source: " .. source) end

    local player = Bridge.GetPlayer(source)
    if not player then
        if Config.Debug then print("^1[XR-MDT ERROR]^7 Player object not found for source: " .. source) end
        return
    end

    local job = Bridge.GetJob(source)
    if not job then
        if Config.Debug then print("^1[XR-MDT ERROR]^7 Job not found for player: " .. source) end
        return
    end

    if Config.Debug then
        print(string.format("[XR-MDT] Opening Tablet for Source: %s | Job: %s | Grade: %s",
            source, job.name, job.grade and (job.grade.name or job.grade.level) or "N/A"))
    end

    -- You can add additional permission checks here if needed
    TriggerClientEvent('xr-mdt:client:open', source, {
        type = job.name,
        permissions = Bridge.GetMetaData(player, 'mdt_perms') or nil
    })

    if Config.Debug then print("[XR-MDT] Signal sent to client successfully.") end
end

-- ============================================================
-- REGISTRATION LOOP
-- ============================================================

Citizen.CreateThread(function()
    -- Ensure bridge is ready
    Citizen.Wait(1500)

    if not Config.InventoryAutoRegister then
        if Config.Debug then
            print("^3[XR-MDT]^7 Automatic Item Registration is DISABLED (Config.InventoryAutoRegister = false)")
            print("^3[XR-MDT]^7 Use 'TriggerEvent(\"xr-mdt:server:use:ITEM_NAME\", source)' in your items.lua")
        end
        return
    end

    -- 2. Bodycam
    if Config.Items.bodycam then
        Bridge.RegisterUsableItem(Config.Items.bodycam, function(source)
            TriggerEvent('xr-mdt:server:toggle:bodycam', source)
        end)
    end

    -- 3. GPS
    if Config.Items.gps then
        Bridge.RegisterUsableItem(Config.Items.gps, function(source)
            TriggerClientEvent('xr-mdt:client:useGPSItem', source)
        end)
    end

    -- 4. Document
    if Config.Items.document then
        Bridge.RegisterUsableItem(Config.Items.document, function(source, item)
            if Config.Debug then print("^3[XR-MDT DEBUG]^7 Bridge.RegisterUsableItem callback for: " .. Config.Items.document .. " | Source: " .. tostring(source)) end
            TriggerEvent('xr-mdt:server:toggle:document', source, item)
        end)
    end

    -- 5. Tracking Band
    if Config.Items.tracking_band then
        Bridge.RegisterUsableItem(Config.Items.tracking_band, function(source)
            TriggerEvent('xr-mdt:server:toggle:tracking_band', source)
        end)
    end

    if Config.Debug then
        print("^2[XR-MDT] Unified Item Controller Initialized (AUTO-REGISTER)^7")
    end
end)

-- ============================================================
-- STANDARDIZED EXTERNAL EVENTS (Unified Toggle System)
-- ============================================================

RegisterNetEvent('xr-mdt:server:requestOpenMDT', function()
    OpenTablet(source)
end)

RegisterNetEvent('xr-mdt:server:toggle:bodycam', function(src)
    local target = source
    if type(src) == 'number' and src > 0 then target = src end
    TriggerEvent('xr-mdt:server:useItem:bodycam', target)
end)

RegisterNetEvent('xr-mdt:server:toggle:gps', function(src)
    local target = source
    if type(src) == 'number' and src > 0 then target = src end
    TriggerEvent('xr-mdt:server:useItem:gps', target)
end)

RegisterNetEvent('xr-mdt:server:toggle:tracking_band', function(src)
    local target = source
    if type(src) == 'number' and src > 0 then target = src end
    TriggerEvent('xr-mdt:server:useItem:tracking_band', target)
end)

RegisterNetEvent('xr-mdt:server:toggle:document', function(arg1, arg2)
    local target = source
    local item = arg1

    -- If triggered internally: TriggerEvent('event', source, item)
    -- arg1 (source) is number, arg2 (item) is table/string
    if type(arg1) == 'number' then
        target = arg1
        item = arg2
    end

    TriggerEvent('xr-mdt:server:useItem:document', target, item)
end)

-- ============================================================
-- EXPORTS FOR ITEM LINKING (e.g. ox_inventory)
-- ============================================================

local function ResolvePlayerSource(arg1, arg2, arg3)
    local src = source
    if not src or src == 0 then src = _G.source end

    if arg1 == 'usingItem' then
        if type(arg3) == 'number' then
            src = arg3
        elseif type(arg3) == 'table' and arg3.id then
            src = tonumber(arg3.id) or src
        end
    elseif type(arg1) == 'number' then
        src = arg1
    elseif type(arg1) == 'table' then
        if type(arg2) == 'number' then
            src = arg2
        elseif type(arg2) == 'table' and arg2.id then
            src = tonumber(arg2.id) or src
        end
        if not src or src == 0 or type(src) ~= 'number' then
            if type(arg1) == 'table' and arg1.id then
                src = tonumber(arg1.id) or src
            end
        end
    end

    if not src or src == 0 or type(src) ~= 'number' then
        if type(source) == 'number' and source > 0 then
            src = source
        elseif type(_G.source) == 'number' and _G.source > 0 then
            src = _G.source
        end
    end

    return src
end

exports('bodycam', function(arg1, arg2, arg3)
    local src = ResolvePlayerSource(arg1, arg2, arg3)
    if Config.Debug then
        print(string.format("[XR-MDT DEBUG] exports.bodycam called. arg1: %s, arg2: %s, arg3: %s, resolved src: %s",
            tostring(arg1), tostring(arg2), tostring(arg3), tostring(src)))
    end

    if not src or src == 0 then
        return false
    end

    local job = Bridge.GetJob(src)
    if not job then
        Bridge.Notify(src, {
            title = "Bodycam",
            description = (Locales[Config.Language] or Locales['en']).bodycam.not_authorized,
            type = "error",
            icon = "camera",
            iconColor = "#ef4444"
        })
        return false
    end

    local allowedJobs = (Config.Bodycam and Config.Bodycam.AllowedJobs) or { "police", "ambulance" }
    local isAllowed = false
    for _, j in ipairs(allowedJobs) do
        if job.name == j then
            isAllowed = true
            break
        end
    end

    if not isAllowed then
        Bridge.Notify(src, {
            title = "Bodycam",
            description = (Locales[Config.Language] or Locales['en']).bodycam.not_authorized,
            type = "error",
            icon = "camera",
            iconColor = "#ef4444"
        })
        return false
    end

    TriggerEvent('xr-mdt:server:useItem:bodycam', src)
    return false
end)

exports('gps', function(arg1, arg2, arg3)
    local src = ResolvePlayerSource(arg1, arg2, arg3)
    if Config.Debug then
        print(string.format("[XR-MDT DEBUG] exports.gps called. arg1: %s, arg2: %s, arg3: %s, resolved src: %s",
            tostring(arg1), tostring(arg2), tostring(arg3), tostring(src)))
    end

    if not src or src == 0 then
        return false
    end

    local job = Bridge.GetJob(src)
    if not job then
        local lang = Locales[Config.Language] or Locales['en']
        local msg = lang.gps.no_job or lang.gps.unauthorized or "GPS Error: No job assigned!"
        Bridge.Notify(src, {
            title = "GPS Tracker",
            description = msg,
            type = "error",
            icon = "wifi-slash",
            iconColor = "#ef4444"
        })
        return false
    end

    if not (Config.IsEnforcementJob(job.name) or Config.IsMedicalJob(job.name) or job.name == "doj") then
        local lang = Locales[Config.Language] or Locales['en']
        local msg = lang.gps.unauthorized or "Your profile is not authorized for the encrypted GPS network!"
        Bridge.Notify(src, {
            title = "GPS Tracker",
            description = msg,
            type = "error",
            icon = "shield-halved",
            iconColor = "#ef4444"
        })
        return false
    end

    TriggerEvent('xr-mdt:server:useItem:gps', src)
    return false
end)

exports('tracking_band', function(arg1, arg2, arg3)
    local src = ResolvePlayerSource(arg1, arg2, arg3)
    if Config.Debug then
        print(string.format("[XR-MDT DEBUG] exports.tracking_band called. arg1: %s, arg2: %s, arg3: %s, resolved src: %s",
            tostring(arg1), tostring(arg2), tostring(arg3), tostring(src)))
    end

    if not src or src == 0 then
        return false
    end

    local job = Bridge.GetJob(src)
    if not job then
        Bridge.Notify(src, {
            title = "Tracking Band",
            description = (Locales[Config.Language] or Locales['en']).tracking.only_officers,
            type = "error",
            icon = "shield-halved",
            iconColor = "#ef4444"
        })
        return false
    end

    if not (Config.IsEnforcementJob(job.name) or job.name == 'doj') then
        Bridge.Notify(src, {
            title = "Tracking Band",
            description = (Locales[Config.Language] or Locales['en']).tracking.only_officers,
            type = "error",
            icon = "shield-halved",
            iconColor = "#ef4444"
        })
        return false
    end

    TriggerEvent('xr-mdt:server:useItem:tracking_band', src)
    return false
end)

exports('document', function(arg1, arg2, arg3)
    local src = ResolvePlayerSource(arg1, arg2, arg3)
    local item = arg1
    if arg1 == 'usingItem' then
        item = arg2
    elseif type(arg1) == 'number' then
        item = arg2
    elseif type(arg1) == 'table' then
        item = arg1
    end

    if Config.Debug then 
        print(string.format("^3[XR-MDT DEBUG]^7 Export 'document' | Src: %s | Arg1: %s | ItemName: %s", tostring(src), tostring(arg1), (item and (type(item) == 'table' and item.name or tostring(item)) or "nil")))
    end
    
    if src and src > 0 then
        TriggerEvent('xr-mdt:server:useItem:document', src, item)
        return false
    else
        print("^1[XR-MDT ERROR]^7 Export 'document' failed! Source is still nil. ")
        print("^3[TIP]^7 Switch to CLIENT export in items.lua: client = { export = 'xr-mdt.document' }")
        return false
    end
end)

exports('tablet', function(source)
    local src = source
    if type(src) == 'string' or not src or src == 0 then src = _G.source end
    OpenTablet(src)
    return false
end)

-- ============================================================
-- ADMIN COMMANDS (Fallback & Testing)
-- ============================================================

-- /setbodycam [id]
Bridge.RegisterCommand('setbodycam', 'Toggle bodycam for a player', {
    { name = 'id', help = 'Player Server ID' }
}, true, function(source, args)
    local target = tonumber(args.id) or source
    if target == 0 then return end
    -- Bypass item check
    TriggerClientEvent('xr-mdt:client:toggleBodycam', target, true)
end)

-- /setgps [id]
Bridge.RegisterCommand('setgps', 'Toggle GPS for a player', {
    { name = 'id', help = 'Player Server ID' }
}, true, function(source, args)
    local target = tonumber(args.id) or source
    if target == 0 then return end
    TriggerEvent('xr-mdt:server:toggle:gps', target)
end)

-- ============================================================
-- ADDITIONAL UTILITY EXPORTS
-- ============================================================

exports('toggleBodycam', function(source)
    -- Bypass item check
    TriggerClientEvent('xr-mdt:client:toggleBodycam', source, true)
end)

exports('toggleGPS', function(source)
    TriggerEvent('xr-mdt:server:toggle:gps', source)
end)
