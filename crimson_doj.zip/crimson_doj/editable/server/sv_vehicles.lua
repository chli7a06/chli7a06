


-- Helper function to generate a random 12-digit VIN


local function GenerateUniqueVin()
    local vin
    local exists = true
    while exists do
        vin = EditTable.LSPD.Functions.GenerateVIN()
        local table = (Config.Framework == 'qb') and 'player_vehicles' or 'owned_vehicles'
        local count = MySQL.scalar.await('SELECT count(*) FROM ' .. table .. ' WHERE vin = ?', { vin })
        if not count or count == 0 then
            exists = false
        end
    end
    return vin
end

exports('GenerateVin', GenerateUniqueVin)

-- Helper to generate plate
local function GeneratePlate(job)
    if job == 'police' then
        return 'LSPD ' .. tostring(math.random(100, 999))
    elseif job == 'ambulance' then
        return 'EMS ' .. tostring(math.random(1000, 9999))
    else
        return tostring(math.random(10000000, 99999999))
    end
end

-- Function to add vehicle to database
local function AddVehicleToDatabase(source, targetId, vehicleModel, garage, financeData, ownerOverride)
    -- Resolve Target
    local citizenid = nil
    local license = nil
    local plateJob = nil

    -- Check if ownerOverride is a job name or special string
    if ownerOverride and (ownerOverride == 'police' or ownerOverride == 'ambulance') then
        citizenid = ownerOverride
        plateJob = ownerOverride
    else
        -- If override is a citizenID (string), use it directly?
        -- But logic below (lines 70-77) suggests override was just for Jobs?
        -- Original code: if ownerOverride then citizenid = ownerOverride ...
        -- If we passed a targetId, we try to get player.

        -- Let's stick to original flow but use Bridge
        if ownerOverride then
            citizenid = ownerOverride
            if citizenid == 'police' or citizenid == 'ambulance' then
                plateJob = citizenid
            end
        else
            local Player = Bridge.GetPlayer(targetId)
            if Player then
                citizenid = Bridge.GetCitizenIdFromObject(Player)
                local job = Bridge.GetJobFromObject(Player)
                plateJob = job and job.name or nil

                if Config.Framework == 'qb' or Config.Framework == 'qbox' then
                    license = Player.PlayerData.license
                elseif Config.Framework == 'esx' then
                    -- Fallback/Unused
                    license = citizenid
                end
            end
        end
    end

    if ownerOverride then
        citizenid = ownerOverride
        if citizenid == 'police' then
            plateJob = 'police'
        elseif citizenid == 'ambulance' then
            plateJob = 'ambulance'
        end

        if (Config.Framework == 'qb' or Config.Framework == 'qbox') and not license then
            local Buyer = Bridge.GetPlayer(source)
            if Buyer then
                license = Buyer.PlayerData.license
            end
        end
    end

    if not citizenid then return false, "No owner specified" end

    local vin = GenerateUniqueVin()
    local plate = GeneratePlate(plateJob)
    local hash = GetHashKey(vehicleModel)
    local state = 1

    if Config.Framework == 'qb' or Config.Framework == 'qbox' then
        -- QBCore Insert
        local mods = '{}'
        local fuel = 100
        local engine = 1000
        local body = 1000
        local status = financeData and 'financed' or 'owned'
        local balance = financeData and financeData.balance or 0
        local paymentamount = financeData and financeData.paymentamount or 0
        local paymentsleft = financeData and financeData.paymentsleft or 0
        local financetime = financeData and financeData.financetime or 0

        local insertId = MySQL.insert.await([[
            INSERT INTO `player_vehicles`
            (license, citizenid, vehicle, hash, mods, plate, fakeplate, garage, fuel, engine, body, state, depotprice, drivingdistance, status, balance, paymentamount, paymentsleft, financetime, vin)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ]], {
            license, citizenid, vehicleModel, hash, mods, plate, nil, garage, fuel, engine, body, state,
            0, 0, status, balance, paymentamount, paymentsleft, financetime, vin
        })

        return (insertId > 0), plate, vin
    elseif Config.Framework == 'esx' then
        -- ESX Insert (Standard owned_vehicles)
        -- vehicle col usually stores JSON model
        local vehicleProps = { model = hash, plate = plate }

        local insertId = MySQL.insert.await([[
            INSERT INTO `owned_vehicles`
            (owner, plate, vehicle, type, stored, parking, vin)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ]], {
            citizenid, plate, json.encode(vehicleProps), 'car', 1, garage, vin
        })

        return (insertId > 0), plate, vin
    end

    return false, "Invalid Framework"
end

exports('AddVehicle', AddVehicleToDatabase)

-- Command to give vehicle (Admin)
if Config.Framework == 'qb' or Config.Framework == 'qbox' then
    QBCore.Commands.Add('givevehicle', 'Give a vehicle to a player', {
        { name = 'id',     help = 'Player ID' },
        { name = 'model',  help = 'Vehicle Model' },
        { name = 'garage', help = 'Garage Name (Optional)' }
    }, true, function(source, args)
        local targetId = tonumber(args[1])
        local model = args[2]
        local garage = args[3] or 'pillboxgarage'

        local success, plate, vin = AddVehicleToDatabase(source, targetId, model, garage, nil, nil)

        if success then
            TriggerClientEvent('QBCore:Notify', source, "Vehicle given! Plate: " .. plate .. ", VIN: " .. vin, "success")
        else
            TriggerClientEvent('QBCore:Notify', source, "Failed to give vehicle.", "error")
        end
    end, 'admin')

    QBCore.Commands.Add('testvin', 'Test VIN Generation', {}, true, function(source, args)
        local vin = GenerateUniqueVin()
        TriggerClientEvent('QBCore:Notify', source, "Generated VIN: " .. vin, "success")
    end, 'admin')
elseif Config.Framework == 'esx' then
    ESX.RegisterCommand('givevehicle', 'admin', function(xPlayer, args, showError)
        local targetId = tonumber(args.playerId)
        local model = args.model
        local garage = args.garage or 'Central'

        local success, plate, vin = AddVehicleToDatabase(xPlayer.source, targetId, model, garage, nil, nil)

        if success then
            xPlayer.showNotification("Vehicle given! Plate: " .. plate .. ", VIN: " .. vin)
        else
            xPlayer.showNotification("Failed to give vehicle.")
        end
    end, true, {
        help = 'Give a vehicle',
        arguments = {
            { name = 'playerId', help = 'Player ID',         type = 'number' },
            { name = 'model',    help = 'Vehicle Model',     type = 'string' },
            { name = 'garage',   help = 'Garage (Optional)', type = 'string' }
        }
    })

    ESX.RegisterCommand('testvin', 'admin', function(xPlayer, args, showError)
        local vin = GenerateUniqueVin()
        xPlayer.showNotification("Generated VIN: " .. vin)
    end, true, { help = 'Test VIN Generation' })
end
