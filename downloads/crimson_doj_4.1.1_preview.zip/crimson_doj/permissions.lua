-- Explicit job access; businesses can still be inspected without entering MDT.
Config.MDTJobs = Config.MDTJobs or {doj=true,police=true,sheriff=true,ambulance=true}
Config.DojGrades = Config.DojGrades or {
 ['0'] = { label = 'DOJ Student', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = false, reports_view = true, reports_create = false, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = false, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['1'] = { label = 'Public Lawyer', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = false, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = false, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['2'] = { label = 'Public Defender', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = false, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['3'] = { label = 'Assitant Attorney', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = false, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = false, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['4'] = { label = 'FBI Academy Trainee', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = false, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = false, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['5'] = { label = 'Junior Special Agent', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['6'] = { label = 'Special Agent', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, business_view = true, business_manage = false, code_change = false } },
    ['7'] = { label = 'Senior Officer', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['8'] = { label = 'Assistant Special Agent in Charge', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['9'] = { label = 'Special Agent in Charge', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = false, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, business_view = true, business_manage = false, code_change = false } },
    ['10'] = { label = 'Deputy Director', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['11'] = { label = 'District Attorney', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['12'] = { label = 'General Attorney', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = false, business_view = true, business_manage = false, code_change = false } },
    ['13'] = { label = 'Director of the FBI', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, business_view = true, business_manage = true, code_change = true } },
    ['14'] = { label = 'Judge', permissions = { dashboard_view = true, profiles_view = true, profiles_edit = true, reports_view = true, reports_create = true, reports_delete = true, warrants_view = true, warrants_create = true, warrants_delete = true, vehicles_view = true, vehicles_edit = true, convictions_create = true, employees_view = true, employees_manage = true, business_view = true, business_manage = true, code_change = true } },
}
function CrimsonPermission(a,key,fallback)
 if a.permissions then return a.permissions[key]==true end
 return fallback==true
end
local modules={
 case={'reports_view','reports_create','reports_delete'},incident={'reports_view','reports_create','reports_delete'},
 document={'reports_view','reports_create','reports_delete'},recording={'reports_view','reports_create','reports_delete'},
 note={'profiles_view','profiles_edit','profiles_edit'},warrant={'warrants_view','warrants_create','warrants_delete'},
 vehicle_flag={'vehicles_view','vehicles_edit','vehicles_edit'},weapon={'vehicles_view','vehicles_edit','vehicles_edit'},
 business_license={'business_view','business_manage','business_manage'},business_note={'business_view','business_manage','business_manage'},
 dispatch={'reports_view','reports_create','reports_delete'},
}
function CrimsonModulePermission(a,kind,mode,fallback)
 if not a.permissions then return fallback==true end
 local keys=modules[kind]
 return keys and a.permissions[keys[mode]]==true or false
end

Config.ManagementMinGrade = Config.ManagementMinGrade or 10
Config.BadgeChiefMinGrade = Config.BadgeChiefMinGrade or 13
Config.DocumentImageHosts = Config.DocumentImageHosts or {['r2.fivemanage.com']=true}
function CrimsonManagement(a)
 return a.department~='doj' or (tonumber(a.grade) or 0)>=(Config.ManagementMinGrade or 10)
end
function CrimsonDocumentImage(value)
 if type(value)~='string' or #value>1000 or value:find('[%c%s]') then return end
 local host,path=value:match('^https://([%w%.%-]+)/(.+)$')
 if not host or not Config.DocumentImageHosts[host:lower()] then return end
 path=path:match('^[^?#]+') or ''
 local ext=path:lower():match('%.([a-z]+)$')
 if not ({jpg=true,jpeg=true,png=true,webp=true})[ext or ''] then return end
 return value
end
